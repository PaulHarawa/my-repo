<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Team - Details</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="../assets/img/favicon.png" rel="icon">
  <link href="../assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="../assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="../assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="../assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="../assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: MyResume - v4.7.0
  * Template URL: https://bootstrapmade.com/free-html-bootstrap-template-my-resume/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
  <style type="text/css">
    body{
      background-color: lightblue;
      font-family: verdana;
    }
  </style>
</head>

<body>

  <main id="main">

    <!-- ======= Portfolio Details Section ======= -->
    <section id="portfolio-details" class="portfolio-details">
      <div class="container">

        <div class="row gy-4">

          <div class="col-lg-4">
            <div class="portfolio-info">
              <h3>Employee Information</h3>
              <ul>
                <li><strong>Name</strong>: Mr. Murphy Kajumi </li>
                <li><strong>Position</strong>: Director</li>
                <li><strong>Education</strong>: Master of Arts (Economics) and Master of Policy Studies</li>
              </ul>
            </div>
            <div class="portfolio-description">
              <h2>Experience</h2>
              <p>
                He has 20 years of experience in the development field. This experience covers project analysis and management, knowledge management, monitoring and evaluation, rights based programming, governance (including demand side instruments design and implementation such as community scorecards and citizen report cards), advocacy and  process facilitation.<br><br>He is skilled in both qualitative and quantitative research designs, data collection and analysis.<br><br>He has served as Team Leader/Evaluator  for various programme reviews and evaluations. <br><br><b>Highlights of his advisory services include</b>: <br>Team Leader-Government of Malawi Ministry of Finance, Economic Planning and Development, Impact Assessment of the Malawi Flood Emergency Recovery Project Input for Assets Programme; Lead Consultant/Evaluator-The Government of Malawi Beneficiary  Impact Assessment of the Smallholder Irrigation and Value Addition Project (SIVAP), Co-Investigator, Beneficiary Impact Assessment of the Government of Malawi’s Higher Education, Science and Technology (HEST) Project, Social Scientist- Government of Malawi, Mid-term review of the Sustainable Rural Water and Sanitation Infrastructure for Improved Livelihoods and Health Project; Evaluator COMESA-Impact assessment of COMESA Trade Information Desks on women; Team Leader/Evaluator (with i-TEC) USAID Uganda -Mid-term review of the USAID funded  Livelihoods and Enterprises  for Agriculture Development (Uganda- the evaluation report was rated among 5 high quality evaluations undertaken in USAID globally between 2009 and 2011);  Monitoring and Evaluation Expert-Malawi National AIDS Commission- International Independent Review Team for the review of the Malawi National Response to HIV/AIDS from 2007-2016; Technical advisor to various World Bank funded Social Protection projects in Africa (Malawi, Botswana, Sudan, Tanzania, Uganda) and the Caribbean region (Jamaica and St. Lucia).
              </p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Portfolio Details Section -->

  </main><!-- End #main -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="../assets/vendor/purecounter/purecounter.js"></script>
  <script src="../assets/vendor/aos/aos.js"></script>
  <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="../assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="../assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="../assets/vendor/typed.js/typed.min.js"></script>
  <script src="../assets/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="../assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="../assets/js/main.js"></script>

</body>

</html>