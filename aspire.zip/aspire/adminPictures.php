<?php
    include"conn.php";
    session_start();
    $uname = $_SESSION['granted'];

    if(!$uname){
        header("Location: admin2001.php");
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <link href="icon.png" rel="icon">

    <title>Aspire Ltd.</title>

    <!-- Custom fonts for this template-->
    <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="assets/vendor/datatables/sb-admin-2.min.css" rel="stylesheet">

    <script src="assets/vendor/datatables/jquery.m.js"></script>

    <script src="assets/vendor/Sweetalert/dist/sweetalert2.min.js"></script>
    <link rel="stylesheet" href="assets/vendor/Sweetalert/dist/sweetalert2.min.css">

    <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">

    <style>
        .int{
        }
        .textt{
            width: 100%;
            height: 40px;
            border-radius: 10px;
        }
        .color1{
            background-color: #1ABB81;
        }
        .color2{
            background-color: #C54A3B;
        }
        .color3{
            background-color: #4E73B4;
        }
        .table1{
            margin: auto;
        }
        .tabledata1{
            padding: 20px;
        }
        .rborder{
            border: none;
            padding: 7px;
            border-radius: 10px;
            width: 100%;
        }
        .up{
            text-align: center;
        }
        .upb{
            width: 100%;
        }
        .floatx{
          float: left;
        }
        .fonty{
            font-size: 12px;
        }
        .opt{
            padding-top: 5px;
        }
        .bg-dark-all{
            background-color: #E9F6F1;
        }
        .bg-now{
            background-color: #283A5A;
            text-transform: uppercase;
        }

    </style>

</head>

<body id="page-top">
 
    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- End of Sidebar -->
<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">

    <!-- Main Content -->
    <div id="content">

         <!-- Topbar -->
         <nav class="navbar navbar-expand navbar-dark bg-now fixed-top" aria-label="Second navbar example">
            <div class="container-fluid">

              <div class="collapse navbar-collapse" id="navbarsExample02">
                <ul class="navbar-nav mr-auto">
                  <li class="nav-item">
                    <a class="nav-link" href="dashboard2001.php">Customers</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="adminProjects.php">Projects</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="adminPictures.php">Pictures</a>
                  </li>
                </ul>
                <form action="adminPictures.php" method="post" class="ml-auto">
                    <button class="btn btn-sm btn-warning" name="logout" type="submit">Log-Out</button>
                </form>
              </div>
            </div>
          </nav>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">
            <br>
            <br>
            <br>
            <br>
            
            <div class="card shadow mb-4 border-success bg-dark-all">
                <div class="card-header py-3 bg-success">
                    <h6 class="h5 m-0 font-weight-bold text-light text-center ">
                      IN-PICTURES</h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-12">
                            <form class="text-dark" action="adminPictures.php" method="POST" enctype="multipart/form-data">
                                <div class="form-group col-md-8 mx-auto">
                                    <label for="title" class="font-weight-bold">Caption</label>
                                    <input type="text" class="form-control" name="caption" id="subject" required>
                                </div>
                                <br>
                                <div class="form-group col-md-8 mx-auto">
                                    <label for="file" class="font-weight-bold">Project Image(s)</label>
                                    <p class="text-center text-danger">*Required</p>
                                    <input type="file" class="form-control p-1" name="file" id="subject" required>
                                    <div class="row">
                                        <div class="col-12 text-center">
                                            <p class="opt">*Optional</p>
                                        </div>
                                        <div class="col-md-6 p-1">
                                            <input type="file" class="form-control p-1" name="file1" id="subject">
                                        </div>
                                        <div class="col-md-6 p-1">
                                            <input type="file" class="form-control p-1" name="file2" id="subject">
                                        </div>
                                        <div class="col-md-6 p-1">
                                            <input type="file" class="form-control p-1" name="file3" id="subject">
                                        </div>
                                        <div class="col-md-6 p-1">
                                            <input type="file" class="form-control p-1" name="file4" id="subject">
                                        </div>
                                    </div>
                                </div>
                                
                                <br>
                                <div class="row justify-content-center mx-auto">
                                    <div class="form-group col-md-2">
                                      <button type="submit" name="update" class="btn btn-primary col-12 mx-auto">Update</button>
                                    </div>
                                </div>
                            </form>

                            <div class="col-12">

                                <?php

                                    $sql = "SELECT * FROM inpictures";
                                    $result = mysqli_query($conn,$sql);

                                    if(mysqli_num_rows($result)>0){
                                        echo"<br><hr><br><div class='col-12 text-center h4 text-uppercase text-dark'>Manage Pictures</div>";
                                        while($row=mysqli_fetch_array($result)){
                                            $id = $row['id'];
                                            $image = $row['image'];
                                            echo"
                                                <div class='col-md-3 floatx'>
                                                <br>
                                                    <img src='inpictures/$image' class='col-12 p-0' height='200'>
                                                    <form action='adminPictures.php' method='post' enctype='multipart/form-data'>
                                                        <button class='btn btn-sm btn-danger col-12' type='submit' name='delete'>Delete</button>
                                                        <input type='radio' name='imgid' value='$id' checked hidden>
                                                    </form>
                                                 </div>";

                                        }
                                    }
                                    else{
                                        echo"";
                                    }

                                ?>
                                <?php

                                if (isset($_POST['delete'])) {
                                    $imgid = $_POST['imgid'];
                                    $_SESSION['imgid'] = $imgid;
                                    echo "<script>
                                            Swal.fire({
                                                title: 'Admin',
                                                text: 'Delete this picture ?',
                                                icon: 'warning',
                                                showCancelButton: true,
                                                confirmButtonText: 'Yes',
                                                cancelButtonText: 'No',
                                                    }).then((result) => {
                                                if (result.isConfirmed) {
                                                     window.location.href='delete.php';
                                                }
                                            })
                                            </script>
                                        ";
                                }

                                ?>

                            <div>


                            <?php 

                            if(isset($_POST['update'])){
                                $filename = $_FILES['file']['name'];
                                $tempname = $_FILES['file']['tmp_name'];

                                $filename1 = $_FILES['file1']['name'];
                                $tempname1 = $_FILES['file1']['tmp_name'];

                                $filename2 = $_FILES['file2']['name'];
                                $tempname2 = $_FILES['file2']['tmp_name'];

                                $filename3 = $_FILES['file3']['name'];
                                $tempname3 = $_FILES['file3']['tmp_name'];

                                $filename4 = $_FILES['file4']['name'];
                                $tempname4 = $_FILES['file4']['tmp_name'];

                                $filesArray = array();
                                $tempsArray = array();
                                $destArray = array();

                                if(!empty($filename)){
                                    array_push($filesArray, $filename);
                                    array_push($tempsArray, $tempname);
                                    array_push($destArray,"inpictures/".$filename);

                                }
                                if(!empty($filename1)){
                                    array_push($filesArray, $filename1);
                                    array_push($tempsArray, $tempname1);
                                    array_push($destArray,"inpictures/".$filename1);
                                }
                                if(!empty($filename2)){
                                    array_push($filesArray, $filename2);
                                    array_push($tempsArray, $tempname2);
                                    array_push($destArray,"inpictures/".$filename2);
                                }
                                if(!empty($filename3)){
                                    array_push($filesArray, $filename3);
                                    array_push($tempsArray, $tempname3);
                                    array_push($destArray,"inpictures/".$filename3);
                                }
                                if(!empty($filename4)){
                                    array_push($filesArray, $filename4);
                                    array_push($tempsArray, $tempname4);
                                    array_push($destArray,"inpictures/".$filename4);
                                }

                                $countFiles = count($filesArray);

                                $caption = $_POST['caption'];

                                $start = 0;
                                while ($start < $countFiles) {
                                    $sql = "INSERT INTO inpictures(caption,image) VALUES('$caption','$filesArray[$start]')";
                                    $result = mysqli_query($conn,$sql);

                                    move_uploaded_file($tempsArray[$start], $destArray[$start]);

                                    $start++;
                                }

                                    echo "<script>
                                            Swal.fire({
                                                title: 'Admin',
                                                text: 'Pictures updated successfully',
                                                icon: 'success',
                                                confirmButtonText: 'OK',
                                                }).then((result) => {
                                                if (result.isConfirmed) {

                                                        window.location.href='adminPictures.php';
                                                            }
                                                        })
                                           </script>";
                                }

                            ?>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!-- /.container-fluid -->

    </div>
    <!-- End of Main Content -->

    <!-- Footer -->
    <footer class="sticky-footer">
        <div class="container my-auto">
            <div class="copyright text-center my-auto">
                &copy; Copyright <strong><span>ASPIRE</span></strong>. All Rights Reserved
            </div>
        </div>
        <br><br>
        <div class="text-secondary text-center fonty">
        Developed by <strong><span>Cyber DimenXion</span></strong>
      </div>
    </footer>
    <!-- End of Footer -->
    <?php
        if(isset($_POST['logout'])){
            echo "<script>
                    Swal.fire({
                        title: 'LOGOUT',
                        text: 'Proceed to logout now?',
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonText: 'Yes',
                        cancelButtonText: 'No',
                            }).then((result) => {
                        if (result.isConfirmed) {
                             window.location.href='logout.php';
                        }
                    })
                    </script>
                ";
                }

            ?>


</div>
<!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
<i class="fas fa-angle-up"></i>
</a>

<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-footer">
                    <form action="logout.php" method="post">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                        <button class="btn btn-primary" type="submit" name="logout">Logout</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

<!-- Bootstrap core JavaScript-->
<script src="assets/vendor/datatables/jquery.min.js"></script>
<script src="assets/vendor/datatables/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="assets/vendor/datatables/jquery.easing.min.js"></script>

<!-- Custom scripts for all pages-->
<script src="assets/vendor/datatables/sb-admin-2.min.js"></script>

<!-- Page level plugins -->
<script src="assets/vendor/datatables/jquery.dataTables.min.js"></script>
<script src="assets/vendor/datatables/dataTables.bootstrap4.min.js"></script>

<!-- Page level custom scripts -->
<script src="assets/vendor/datatables/datatables-demo.js"></script>

<script src="assets/vendor/glightbox/js/glightbox.min.js"></script>

<script type="text/javascript">
        $(document).ready(function(){
            $('#dataTableCUSTOMERS').DataTable({
                "order": [[0,"desc"]],"pageLength": 6
            });
            $('.dataTables_length').addClass('bs-select');

        });
</script>

<script type="text/javascript">
        $(document).ready(function(){
            $('#dataTableSUBSCRIBERS').DataTable({
                "order": [[0,"desc"]],"pageLength": 6
            });
            $('.dataTables_length').addClass('bs-select');

        });
</script>

</body>

</html>
