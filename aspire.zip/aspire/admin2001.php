<?php 

  include "conn.php";

?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.88.1">
    <title>Aspire Ltd.</title>
    <link href="icon.png" rel="icon">
    
    <script src="assets/vendor/Sweetalert/dist/sweetalert2.min.js"></script>
    <link rel="stylesheet" href="assets/vendor/Sweetalert/dist/sweetalert2.min.css">
    <!-- Bootstrap core CSS -->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>

    
    <!-- Custom styles for this template -->
    <link href="assets/css/signin.css" rel="stylesheet">
  </head>


  <body class="text-center">
    
    <main class="form-signin">
      <form action="admin2001.php" method="POST">

        <img class="mb-4" src="logo.png" alt="" width="150" height="70">
        <h1 class="h3 mb-3 fw-normal">Site Administrator</h1>

        <div class="form-floating">
          <input type="text" class="form-control" id="floatingInput" placeholder="name@example.com" name="username" required>
          <label for="floatingInput">User Name</label>
        </div>
        <div class="form-floating">
          <input type="password" class="form-control" id="floatingPassword" placeholder="Password" name="password" required>
          <label for="floatingPassword">Password</label>
        </div>

        <div>
          <br><br>
        </div>
        <button class="w-100 btn btn-lg btn-primary" type="submit" name="signin">Sign in</button>
        <p class="mt-5 mb-3 text-muted">&copy; Copyright <strong><span>ASPIRE</span></strong>. All Rights Reserved</p>
      </form>

        <?php 

            if(isset($_POST['signin'])){
              $username = $_POST['username'];
              $password = $_POST['password'];

              $enc = sha1($password);

              $sql = "SELECT * FROM admin WHERE username='$username' AND password='$enc'";
              $result = mysqli_query($conn, $sql);

              if(mysqli_num_rows($result)>0){
                session_start();
                $_SESSION['granted'] = $username;

                echo"<script>window.location.href='dashboard2001.php'</script>";
              }
              else{
                echo"

                      <script>
                        Swal.fire({
                            title: 'L O G I N',
                            text: 'Wrong Username and/or Password',
                            icon: 'error',
                            confirmButtonText: 'OK',
                              }).then((result) => {
                            if (result.isConfirmed) {
                              window.location.href='admin2001.php';
                                  }
                              })
                    </script>";
              }
            }

        ?>

    </main>


    <script src="assets/js/main.js"></script>

  </body>
</html>
