<?php
 
 include 'conn.php';

 session_start();

 if (!isset($_SESSION['login'])) {
   header("Location: login.php");
 }

 ?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>FeBytes</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/icon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Presento - v3.7.0
  * Template URL: https://bootstrapmade.com/presento-bootstrap-corporate-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
  <style type="text/css">
    #hero h2 {
      font-family: Brush Script MT;
    }
    .about .icon-boxes .icon-box .btn-template{
      font-size: 20px;
      font-weight: 700;
      background-color: transparent;
      border: none;
      color: #fff;
    }
    .about .icon-boxes .icon-box .btn-template:hover{
      color: #e03a3c;
      transition: 0.2s;
    }
    #hero .container .row .midpart{
      margin: auto;
      text-align: center;
    }
    #hero .container .row .midpart .input-w{
      width: 300px;
    }
    #hero .container .row .midpart .input-y{
      height: 30px;
    }
  </style>
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center">
      <h1 class="logo me-auto"><a href="dashboard.php">FeBytes<span></span></a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo me-auto"><img src="assets/img/logo.png" alt=""></a>-->

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto active" href="logout.php">Logout</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->
    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">

    <div class="container" data-aos="zoom-out" data-aos-delay="100">
      <div class="row">
        <div class="col-xl-6 midpart">
          <h1>Template</h1>
          <br>
          <form action="dashboard.php" method="POST" enctype="multipart/form-data">
            <input type="file" name="zip" title="zip file" class="input-w" required><br><br>
            <input type="text" name="name" placeholder="Name" class="input-w" required><br><br>
            <select name="category" class="input-w input-y" required>
              <option value="music">Music</option>
              <option value="education">Education</option>
              <option value="travel">Travel</option>
              <option value="management">Management System</option>
              <option value="ecommerce">Ecommerce</option>
              <option value="marketing">Marketing</option>
              <option value="other">Other</option>
            </select> <br><br>
            <input type="file" name="screenshot" title="screenshot file" class="input-w" required><br><br>
            <textarea class="input-w" name="description" required></textarea><br><br>

            <input type="submit" name="upload1" value="Upload" class="btn btn-success">
          </form>
          <?php
          
            if (isset($_POST['upload1'])) {
                $name = $_POST['name'];
                $category = $_POST['category'];
                $description = $_POST['description'];
                $date = date("y-m-d");

                $zipName = $_FILES['zip']['name'];
                $zipTempName = $_FILES['zip']['tmp_name'];
                $zipDest = "templates/".$zipName;

                $scName = $_FILES['screenshot']['name'];
                $scTempName = $_FILES['screenshot']['tmp_name'];
                $scDest = "templates/screenshots/".$scName;

                $sql = "INSERT INTO templates(name,zip,screenshot,category,date,description) VALUES('$name','$zipName','$scName','$category','$date','$description')";
                $result = mysqli_query($conn,$sql);

                if ($result) {
                  move_uploaded_file($zipTempName, $zipDest);
                  move_uploaded_file($scTempName, $scDest);
                  echo"<br><div class='col-12 text-center text-success'>Template Uploaded Successfully </div>";
                }
                else{
                  echo"<br><div class='col-12 text-center text-danger'>Failed to upload template </div>";
                }
            }

          ?>
        </div>
      </div>
    </div>

  </section><!-- End Hero -->


  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>