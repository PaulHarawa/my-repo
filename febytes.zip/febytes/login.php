<?php 

  include 'conn.php';

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>FeBytes</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/icon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Presento - v3.7.0
  * Template URL: https://bootstrapmade.com/presento-bootstrap-corporate-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
  <style type="text/css">
    #hero h2 {
      font-family: Brush Script MT;
    }
    .about .icon-boxes .icon-box .btn-template{
      font-size: 20px;
      font-weight: 700;
      background-color: transparent;
      border: none;
      color: #fff;
    }
    .about .icon-boxes .icon-box .btn-template:hover{
      color: #e03a3c;
      transition: 0.2s;
    }
    #hero .container .row .midpart{
      margin: auto;
      text-align: center;
    }
  </style>
</head>

<body>

  <!-- ======= Header ======= -->
  <!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">

    <div class="container" data-aos="zoom-out" data-aos-delay="100">
      <div class="row">
        <div class="col-xl-6 midpart">
          <h1>FeBytes</h1>
          <h2>A World At A Click</h2>
          <br>
          <form action="login.php" method="POST">
            <input type="text" name="username" class="input-fd" placeholder="Username"><br><br>
            <input type="password" name="password" class="input-fd" placeholder="Password"> <br><br>
            <input type="submit" name="login" class="btn btn-success" value="Login">
          </form>

    <?php 

      if(isset($_POST['login'])){
        $username = $_POST['username'];
        $password = $_POST['password'];

        $encpass = sha1($password);

        $sql = "SELECT * FROM admin WHERE username='$username' AND password='$encpass'";
        $result = mysqli_query($conn,$sql);

        if(mysqli_num_rows($result)>0){
          session_start();
          $_SESSION['login'] = 1;
          echo"<script>window.location.href='dashboard.php';</script>";
        }
        else{
          echo"<br><div class='col-12 text-center text-danger'>Wrong username and/or password </div>";
        }

      }

    ?>

        </div>
      </div>
    </div> 

  </section><!-- End Hero -->

  <!-- End Footer -->

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>