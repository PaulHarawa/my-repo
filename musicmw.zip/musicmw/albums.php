<?php 

  include 'conn.php';

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Music Mw</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/icon1.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Montserrat:300,400,500,700" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: BizPage - v5.8.0
  * Template URL: https://bootstrapmade.com/bizpage-bootstrap-business-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
  <style>
    
    .section-header-new h3 {
      color: #fff;
      text-transform: capitalize;
      font-size: 26px;
    }
    .section-header h3::after {
      content: "";
      position: absolute;
      display: block;
      width: 40px;
      height: 3px;
      background: #2423CF;
      bottom: 0;
      left: calc(50% - 20px);
    }
    .section-header-new p {
      color: #fff;
      font-family: verdana;
    }

    .border-link{
      border: none;
      color: #18D26E;
    }
    .border-link:hover{
      color: #18EC6E;
      transition: 0.4s;
    }
    .img{
      text-align: center;
    }
    .artwork{
      font-size: 32px;
      color: #2423CF;
    }
    .topten-col:hover .artwork{
      color: #18D26E;
      transition: 0.5s;
    }
    .topten-col:hover .caption{
      color: #18D26E;
      transition: 0.5s;
    }
    .caption{
      font-size: 14px;
      color: #2423CF;
    }
    .iconx{
      font-size: 15px;
      color: #18D26E;
    }

  </style>
</head>

<body class="bg-dark">

  <!-- ======= Header ======= -->
 <!-- End Header -->

  <!-- ======= hero Section ======= -->
  <!-- End Hero Section -->

  <main id="main">

    <!-- ======= Featured trending Section Section ======= -->
    <!-- End Featured trending Section -->

    <!-- ======= topten Us Section ======= -->
    <section id="topten">
      <div class="container" data-aos="fade-up">

        <header class="section-header section-header-new">
          <br>
          <h3>Albums</h3>
        </header>
        <br>

        <div class="row topten-cols">

            <br>
         
            <?php 

              $sqlII = "SELECT DISTINCT name FROM albums ORDER BY artist DESC";
              $resultII = mysqli_query($conn,$sqlII);

              while($rowII=mysqli_fetch_array($resultII)){
                $nameDistinct = $rowII['name'];

                $sql = "SELECT * FROM albums WHERE name = '$nameDistinct'";
                $result = mysqli_query($conn,$sql);

                $row = mysqli_fetch_array($result);

                $artist = $row['artist'];
                $name = $row['name'];
                $genre = $row['genre'];
                $nos = $row['nos'];
                
                $sqlb = "SELECT * FROM users WHERE id='$artist'";
                $resultb = mysqli_query($conn,$sqlb);

                $rowb = mysqli_fetch_array($resultb);
                  $artistName = $rowb['name'];

                echo"
                
                <div class='col-md-4' data-aos='fade-up' data-aos-delay='100'>
                  <div class='topten-col'>
                    <div class='img'>
                      <span class='img-fluid artwork bi bi-soundwave'></span>
                      <form action='albums-single.php' method='POST' enctype='multipart/form-data'>
                        <input type='radio' name='albumID' value='$name' checked hidden>
                        <input type='submit' class='bg-transparent border-link text-capitalize' value='$artistName - $name album' name='album'><span class='bi bi-play-circle iconx'></span>
                      </form>
                      <span class='caption text-capitalize'>$nos Songs</span><br>
                      <span class='caption text-capitalize'>$genre</span><br>
                    </div>
                  </div>
                  <br>
                </div>
                
                ";

              }
            
            ?>            


        </div>

      </div>

      <br><br>
        <div class="row bth-btn">
          <a href='index.php' class='col-8 col-md-5 btn btn-sm btn-primary mx-auto'>Back To Home</a>
        </div>
    </section><!-- End topten Us Section -->

    <!-- ======= trending Section ======= -->
    <!-- End trending Section -->

    <!-- ======= Call To Action Section ======= -->
    <!-- End Call To Action Section -->

    <!-- ======= Skills Section ======= -->
    <!-- End Skills Section -->

    <!-- ======= Facts Section ======= -->
    <!-- End Facts Section -->

    <!-- ======= Portfolio Section ======= -->
    <!-- End Portfolio Section -->

    <!-- ======= Our Clients Section ======= -->
    <!-- End Our Clients Section -->

    <!-- ======= Testimonials Section ======= -->
    <!-- End Testimonials Section -->

    <!-- ======= Team Section ======= -->
    <!-- End Team Section -->

    <!-- ======= Contact Section ======= -->
    <!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
  <!-- Uncomment below i you want to use a preloader -->
  <!-- <div id="preloader"></div> -->

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>