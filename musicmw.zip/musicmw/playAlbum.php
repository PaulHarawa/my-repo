<?php
 
    include "conn.php";

    session_start();
    $songID = $_SESSION['songID'];

    $sql = "SELECT * FROM albums WHERE id='$songID'";
    $result = mysqli_query($conn,$sql);

    $row = mysqli_fetch_array($result);
        $plays = $row['plays'];
        $newPlays = $plays + 1;
   
    $sql1 = "UPDATE albums SET plays='$newPlays' WHERE id='$songID'";
    $result1 = mysqli_query($conn,$sql1);  

    session_destroy();
    session_unset();

?>