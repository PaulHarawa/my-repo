
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title></title>
	<link rel="stylesheet" href="">
	<link href="assets/img/icon1.png" rel="icon">
	<link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-dark">

<?php 

	include 'conn.php';
	session_start();

	if(isset($_POST['register'])){
		$name = $_POST['name'];
		$pwd = sha1($_POST['password']);
		$genre = $_POST['genre'];
		$about = $_POST['about'];

		$profileName = $_FILES['profile']['name'];
		$profileFile = $_FILES['profile']['tmp_name'];
		$destination = "profile/".$profileName;

		$sql = "INSERT INTO users(name,pwd,about,picture,genre) VALUES('$name','$pwd','$about','$profileName','$genre')";
		$result = mysqli_query($conn,$sql);

		if($result){
			move_uploaded_file($profileFile, $destination);
			echo"<script>window.location.href='login.php'</script>";
		}
	}
                  
        if(isset($_POST['login'])){
          $username = $_POST['name'];
          $password = $_POST['password'];

          $encpass = sha1($password);

          $sql = "SELECT * FROM users WHERE name='$username' AND pwd='$encpass'";
          $result = mysqli_query($conn, $sql);

          if($result){
            if(mysqli_num_rows($result)>0){
              $row = mysqli_fetch_array($result);
              	$aid = $row['id'];
              $_SESSION['aid'] = $aid;
              $_SESSION['login'] = $username;
              echo"<script>window.location.href='dashboard.php';</script>";
             }
             else{
               echo"<br><br><br><div class='col-12 text-danger text-center bg-warning'>Wrong Username and/or Password</div> <br><br>

               		<div class='col-12 text-center'>

               			<a href='login.php' class='btn btn-success'>Try Again</a>
               			<br><br>
               			<a href='index.php' class='btn btn-success'>Go To Website</a>

               		</div>

               ";
                        }
                      }
                    }
                  
?>

</body>
</html>