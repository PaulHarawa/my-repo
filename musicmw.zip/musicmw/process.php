<?php
 
    include "conn.php";
    session_start();

    if(isset($_POST['artist'])){
        $artistID = $_POST['artistID'];
    
        $_SESSION['artistID'] = $artistID;

        echo "<script>window.location.href='artist.php'</script>";
      }
    
    

?>