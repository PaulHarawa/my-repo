<?php 

  include 'conn.php';
  session_start();

  $sid = session_id();

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Music Mw</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/icon1.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Montserrat:300,400,500,700" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  <link href="assets/player/music.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: BizPage - v5.8.0
  * Template URL: https://bootstrapmade.com/bizpage-bootstrap-business-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
  <style>
   .img-container{
     width: 70%;
     height: 50%;
     text-align: center;
     padding-bottom: 20px;
   }
   #player{
     text-align: center;
   }
   .topten-col{
     text-align: center;
   }
   .captionII{
     font-size: 14px;
   }
   .timeX{
     font-size: 15px;
   }
   #audioControl{
     margin-top: 10px;
   }
   .download{
    margin-top: 10px;
   }
   .tags-header{
     color: white;
     font-size: 17px;
   }
   .tags-link{
     background-color: transparent;
     border: none;
     color: #19AF54;
     font-size: 15px;
   }
   .tags-link:hover{
     background-color: transparent;
     border: none;
     color: #199454;
     font-size: 15px;
     transition: 0.4s;
   }
  
  </style>
</head>

<body class="bg-dark">

  <!-- ======= Header ======= -->
  <!-- End Header -->

  <!-- ======= hero Section ======= -->
  <!-- End Hero Section -->

  <main id="main">

    <!-- ======= Featured trending Section Section ======= -->
    <!-- End Featured trending Section -->

    <!-- ======= topten Us Section ======= -->
    <section id="topten">
      <div class="container" data-aos="fade-up">

        <div class="row topten-cols">

          <?php 

          if(isset($_POST['song'])){
            $songID = $_POST['songID'];

            $sql = "SELECT * FROM songs WHERE id='$songID'";
            $result = mysqli_query($conn,$sql);
            $row = mysqli_fetch_array($result);

              $id = $row['id'];
                $_SESSION['songID'] = $id;
              $song = $row['song'];
              $artwork = $row['artwork'];
              $downloads = $row['downloads'];
              $title = $row['title'];
              $plays = $row['plays'];
              $genre = $row['genre'];
              
              $genreName = $genre.'Songs';

              $playsTerm = "";
                  if($plays<=1){
                      $playsTerm = 'play';
                    }
                  else{
                      $playsTerm = 'plays';
                    }

              $downloadsTerm = "";
                  if($downloads<=1){
                      $downloadsTerm = 'download';
                    }
                  else{
                      $downloadsTerm = 'downloads';
                    }

            $aid = $row['artist'];
              $sql2 = "SELECT * FROM users WHERE id='$aid'";
              $result2 = mysqli_query($conn,$sql2);

              $row2 = mysqli_fetch_array($result2);
                $name = $row2['name'];
                $genre2 = $row2['genre'];

                $genre2Name = $genre2.'Artists';


            echo"
            <div class='col-md-5 mx-auto' data-aos='fade-up' data-aos-delay='100'>
              <div class='topten-col'>
                <div class='img img-container mx-auto'>
                <br>
                  <img src='artworks/$artwork' alt='' class='img-fluid' width='100%'>
                </div>
                <span class='caption text-white text-capitalize'>$name - $title<span>
                <h2 class='title'>
                  <div class='col-12'>
                    <canvas id='progress' height='7'></canvas>
                      <audio id='audio' ontimeupdate='updateBar()' src='songs/$song'>
                      </audio>
                      <br>
                      <span class='timeX'>
                        <span id='current-time'></span> /
                        <span id='duration'></span>
                      </span>
                      <br>
                      <button id='audioControl' onclick='togglePlaying()' class='btn btn-success btn-sm'>Play</button>

                      <span class='captionII'>
                        <button class='profile-detail' id='prevPlays' value='$plays' hidden></button>
                        <b><span id='playUpdate'>$plays</span></b> $playsTerm
                      </span>



                      <form action='download.php' method='post' enctype='multipart/form-data'>
                        <input type='radio' name='songID' value='$id' checked hidden>
                        <button type='submit' name='download' class='btn btn-sm btn-success download' onclick='updateDownloads()' id='downloadButton'>Download</button>

                        <span class='captionII'>
                          <button class='profile-detail' id='prevDownloads' value='$downloads' hidden></button>
                          <b><span id='downloadsUpdate'>$downloads</span></b> $downloadsTerm
                        </span>
                      </form>
                      <br>

                      <span class='tags'>
                       <span class='tags-header'><span class='bi bi-tags'></span> Tags </span>

                        <form action='artist.php' method='post' enctype='multipart/form-data'>
                          <input type='radio' name='artistID' value='$aid' checked hidden>
                          <button type='submit' name='artist' class='tags-link'><span class='bi bi-tag'></span> $name songs</button>
                        </form>

                        <form action='genre.php' method='post' enctype='multipart/form-data'>
                          <button type='submit' name='$genreName' class='tags-link'><span class='bi bi-tag'></span> $genre songs</button>
                        </form>

                        <form action='genre.php' method='post' enctype='multipart/form-data'>
                          <button type='submit' name='$genre2Name' class='tags-link'><span class='bi bi-tag'></span> $genre2 artists</button>
                        </form>
                        </span>

                      <br>
                      <a href='index.php' class='col-8 btn btn-sm btn-primary'>Back To Home</a>
                  </div>
                </h2>
              
              </div>
            </div>

            
            
            ";

          }

          
          ?>

        </div>

      </div>
    </section>
    
          <script>

            function updateDownloads(){              
              
              var prevDownloads = document.getElementById("prevDownloads").value;
              var newDownloads = parseInt(prevDownloads) + parseInt(1);

              document.getElementById("downloadsUpdate").innerHTML = newDownloads;

              document.getElementById("downloadButton").innerHTML = 'Downloading';

            }

          </script>
    
    
    
    <!-- End topten Us Section -->

    <!-- ======= trending Section ======= -->
    <!-- End trending Section -->

    <!-- ======= Call To Action Section ======= -->
    <!-- End Call To Action Section -->

    <!-- ======= Skills Section ======= -->
    <!-- End Skills Section -->

    <!-- ======= Facts Section ======= -->
    <!-- End Facts Section -->

    <!-- ======= Portfolio Section ======= -->
    <!-- End Portfolio Section -->

    <!-- ======= Our Clients Section ======= -->
    <!-- End Our Clients Section -->

    <!-- ======= Testimonials Section ======= -->
    <!-- End Testimonials Section -->

    <!-- ======= Team Section ======= -->
    <!-- End Team Section -->

    <!-- ======= Contact Section ======= -->
    <!-- End Contact Section -->

  </main><!-- End #main -->

 

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
  <!-- Uncomment below i you want to use a preloader -->
  <!-- <div id="preloader"></div> -->

  <!-- Vendor JS Files -->
  <script src="assets/player/play.js"></script>
  <script src="assets/vendor/purecounter/purecounter.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

  <script>
    function download(){
      window.location.href='../../download.php';
    }
  </script>


</body>

</html>