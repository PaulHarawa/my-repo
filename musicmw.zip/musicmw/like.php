<?php
 
    include "conn.php";

    session_start();
    $artistID = $_SESSION['likeAID'];

    $sql = "SELECT * FROM users WHERE id='$artistID'";
    $result = mysqli_query($conn,$sql);

        $row = mysqli_fetch_array($result);
        $likes = $row['likes'];
        $newLikes = $likes + 1;
        
    $sql1 = "UPDATE users SET likes='$newLikes' WHERE id='$artistID'";
    $result1 = mysqli_query($conn,$sql1);

?>