<?php
	include "conn.php";
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Cyber Dimenxion</title>
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/bootstrap-icons/bootstrap-icons.css">
	<link href="assets/boxicons/css/boxicons.min.css" rel="stylesheet">
	<link href="assets/fontawesome/css/all.min.css" rel="stylesheet" type="text/css">
	<link href="assets/img/icon.png" rel="icon">
	<script src="assets/Sweetalert/dist/sweetalert2.min.js"></script>
  	<link rel="stylesheet" href="assets/Sweetalert/dist/sweetalert2.min.css">
  	<link href="assets/aos/aos.css" rel="stylesheet">

	<style type="text/css">
		*{
			padding: 0px;
			margin: 0px;
			transition: ;
			font-family: verdana;
		}
		.navbar .nav-item .nav-link{
			color: white;
		}
		.navbar .nav-item .nav-link:hover{
			color: rgb(237, 193, 7);
		}
		.nav-menu a:hover, .nav-menu .active, .nav-menu .active:focus, .nav-menu li:hover > a {
  color: white;
  background: #0563bb;
}
		body{
			background-color: rgb(19, 30, 121);

		}
		.landing{
			background: linear-gradient(to right, rgba(0, 0, 0,0.7), rgba(0,0,0,0.1), rgba(0,0,0,0.1), rgba(0, 0, 0,0.7));
			height: 50vh;
			width: 100%;
			text-align: center;
			font-size: 20px;
		}
		.welcome{
			background: linear-gradient(to right, rgba(0, 0, 0,0.7), rgba(0,0,0,0.1), rgba(0,0,0,0.1), rgba(0, 0, 0,0.7));
			height: 50vh;
			width: 100%;
			text-align: center;
			font-size: 20px;
		}
		.typedx{
			font-family: monospace;
			letter-spacing: 2px;
		}
		.typedy{
			font-size: 22px;
		}
		.mobile-nav-toggle{
			color: white;
		}
		.cb{
			font-size: 40px;
		}
		.aw{
			font-family: Brush Script MT;
			font-size: 30px;
		}
		.about{
			min-height: 100vh;
			width: 100%;
			background: linear-gradient(to right, rgba(0, 0, 0,0.5), rgba(13, 110, 253, 0.2), rgba(13, 110, 253, 0.2), rgba(0, 0, 0,0.5));
			text-align: center;
		}
		.services{
			min-height: 100vh;
			width: 100%;
			background-color: rgb(19, 30, 121);
			text-align: center;
		}
		.portifolio{
			min-height: 100vh;
			width: 100%;
			background: linear-gradient( rgb(19, 30, 121), rgba(0, 0, 0,0.5));
			text-align: center;
		}
		.contact{
			min-height: 100vh;
			width: 100%;
			background: linear-gradient( rgba(0, 0, 0,0.5), rgb(19, 30, 121));
			text-align: center;
		}
		.heading{
			text-transform: uppercase;
			color: white;
			letter-spacing: 2px;
			font-weight: bold;
			position: relative;
			margin-bottom: 20px;
  			padding-bottom: 20px;
		}
		.about h3::before {
		  content: "";
		  position: absolute;
		  display: block;
		  width: 120px;
		  height: 1px;
		  background: #ddd;
		  bottom: 1px;
		  left: calc(50% - 60px);
		}
		.about h3::after {
		  content: "";
		  position: absolute;
		  display: block;
		  width: 40px;
		  height: 3px;
		  background: #111B6D;
		  bottom: 0;
		  left: calc(50% - 20px);
		}
		.services h3::before {
		  content: "";
		  position: absolute;
		  display: block;
		  width: 120px;
		  height: 1px;
		  background: #ddd;
		  bottom: 1px;
		  left: calc(50% - 60px);
		}
		.services h3::after {
		  content: "";
		  position: absolute;
		  display: block;
		  width: 40px;
		  height: 3px;
		  background: rgb(13, 110, 253);
		  bottom: 0;
		  left: calc(50% - 20px);
		}
		.portifolio h3::before {
		  content: "";
		  position: absolute;
		  display: block;
		  width: 120px;
		  height: 1px;
		  background: #ddd;
		  bottom: 1px;
		  left: calc(50% - 60px);
		}
		.portifolio h3::after {
		  content: "";
		  position: absolute;
		  display: block;
		  width: 40px;
		  height: 3px;
		  background: rgb(13, 110, 253);
		  bottom: 0;
		  left: calc(50% - 20px);
		}
		.contact h3::before {
		  content: "";
		  position: absolute;
		  display: block;
		  width: 120px;
		  height: 1px;
		  background: #ddd;
		  bottom: 1px;
		  left: calc(50% - 60px);
		}
		.contact h3::after {
		  content: "";
		  position: absolute;
		  display: block;
		  width: 40px;
		  height: 3px;
		  background: rgb(13, 110, 253);
		  bottom: 0;
		  left: calc(50% - 20px);
		}
		.text-size{
			font-size: 18px;
		}
		.bicon{
			color: lightpink;
			font-size: 25px;
		}
		.small-text{
			font-size: 15px;
		}
		.standard-font{
			font-size: 18px;
		}
		.service1{
			background-color: goldenrod;
			height: 400px;
			margin-top: 30px;
			border-radius: 50px;
			box-shadow: 8px 10px rgba(0, 0, 0, 0.3);
			text-align: left;
		}
		.service1:hover{
			transform: translateY(-12px);
			transition: 0.4s;
		}
		.service2:hover{
			transform: translateY(-12px);
			transition: 0.4s;
		}
		.service3:hover{
			transform: translateY(-12px);
			transition: 0.4s;
		}
		.service2{
			background-color: silver;
			height: 400px;
			margin-top: 30px;
			border-radius: 50px;
			box-shadow: 8px 10px rgba(0, 0, 0, 0.3);
			text-align: left;
		}
		.service3{
			background-color: rgba(0, 0, 0, 0.7);
			height: 400px;
			margin-top: 30px;
			border-radius: 50px;
			box-shadow: 8px 10px rgba(0, 0, 0, 0.3);
			text-align: left;
		}
		.portifolio-item{
			height: 200px;
			background: linear-gradient(rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.2)), url("assets/img/portifolio-2.png");
			background-size: contain;
			background-position: center;
			background-repeat: no-repeat;
			margin-top: 30px;
		}
		.portifolio-item:hover{
			transform: scale(1.1);
			transition: 0.4s;
		}
		.package-title{
			font-family: monospace;
			font-weight: bold;
			border-bottom: 2px solid #111B6D;
			padding-bottom: 12px;
			text-align: center;
		}
		.bicon-service{
			font-size: 20px;
			color: #111B6D;
			padding-left: 20px;
		}
		.service-text{
			font-size: 17px;
			padding-left: 10px;
		}
		.portifolio-text{
			font-family: monospace;
		}
		.portifolio-link{
			text-decoration: none;
			color: rgb(13, 110, 253);
			font-size: 15px;
		}
		.portifolio-link:hover{
			color: rgba(13, 110, 253,0.7);
			transition: 0.4s;
		}
		.portifolio-link:active{
			color: rgb(13, 110, 253);
		}
		.contact-form{
			background-color: rgba(255, 255, 255, 0.9);
			height: 400px;
			margin-top: 30px;
			border-radius: 20px;
			text-align: left;
			padding-left: 30px;
			border-top: 5px solid cornflowerblue;
			border-bottom: 5px solid cornflowerblue;
		}
		.bicon-contact{
			color: cornflowerblue;
			font-size: 23px;
			background-color: rgba(100, 149, 237,0.4);
			padding: 15px 18px 15px 18px;
			border-radius: 50%;
		}
		.contact-term{
			color: cornflowerblue;
			font-size: 18px;
			font-weight: bold;
			padding: 5px;
		}
		.contact-term2{
			padding-left: 70px;
			font-size: 15px;
			color: darkblue;
		}
		.bicon-contact:hover{
			color: white;
			background-color: cornflowerblue;
			transition: 0.6s;
		}
		.contact-term:hover{
			color: darkblue;
			transition: 0.6s;
		}
		.contact-term2:hover{
			color: cornflowerblue;
			transition: 0.6s;
		}
		.send-a-message{
			color: cornflowerblue;
			font-size: 22px;
			font-weight: bold;
		}
		.text-input{
			width: 90%;
			height: 43px;
			border: 1px solid cornflowerblue;
			background-color: rgba(100, 149, 237,0.4);
			padding-left: 10px;
		}
		.footer{
			text-align: center;
			padding: 7px;
			font-size: 15px;
		}
		.text-cont{
			text-align: left;
		}
		.text-one{
			text-align: center;
			font-size: 17px;
		}
		.button-one{
			text-align: center;
		}
		.button-onea{
			text-align: center;
		}
		.stars-align{
			padding-left: 57px;
		}
		.bicon-service1{
			color: rgba(17, 27, 109,0.7);
			padding-left: 2px;
		}

	</style>
</head>

<body>
	<i class="bi bi-list mobile-nav-toggle d-xl-none"></i>
	  <!-- ======= Header ======= -->
	  <header id="header" class="d-flex flex-column justify-content-center">

	    <nav id="navbar" class="navbar nav-menu">
	      <ul>
	        <li><a href="#heroy" class="nav-link scrollto"><i class="bx bx-home"></i> <span>Home</span></a></li>
	        <li><a href="#abouty" class="nav-link scrollto"><i class="bx bx-user"></i> <span>About</span></a></li>
	        <li><a href="#servicesy" class="nav-link scrollto"><i class="bx bx-server"></i> <span>Services</span></a></li>
	        <li><a href="#portifolioy" class="nav-link scrollto"><i class="bx bx-book-content"></i> <span>Portfolio</span></a></li>
	        <li><a href="#contacty" class="nav-link scrollto"><i class="bx bx-envelope"></i> <span>Contact Us</span></a></li>
	      </ul>
	    </nav><!-- .nav-menu -->

	  </header><!-- End Header -->
	 <div id="heroy" class="row">
	  <div class="landing text-light">
	  	<br><br><br><br>
	  	<span class="cb">Cyber Dimension</span><br>
	  	<span class="aw">a world at a click.</span><br>
	  </div>
	  <div class="welcome text-light">
	  	<p><span class="typedy">We Develop Websites For</span> <br> <span class="typed typedx text-uppercase" data-typed-items="Bloggers, Institutions, Businesses"></span></p>
	  	<br><br>
	  	<a href="#contacty" class="btn btn-primary btn-lg">Order Yours Now</a>
	  </div>
	</div>

	<div class="row">
	  <div class="about" id="abouty">
	  	<br>
	  	<br>
	  	<h3 class="heading">About</h3>
	  	<br>
	  	<div class="row text-light">
	  		<div class="col-10 mx-auto text-cont">

	  			<p class="small-text col-lg-9 mx-auto">
	  			<i class="bi bi-code-square bicon"></i> We develop mobile first front-end and back-end websites that utilize the latest web technologies.
	  			<br><br>
	  			<i class="bi bi-globe bicon"></i> We use world wide allowed web standards that are recognized by the international community.
	  			<br><br>
	  			<i class="bi bi-people bicon"></i> Our employees have vast knowledge and experience in the field of web development.
	  			<br><br>
	  			<i class="bi bi-geo-alt bicon"></i> We are based in the city of Mzuzu (Malawi) but available online from anywhere across the globe.
	  			<br><br>
	  			<i class="bi bi-question-octagon bicon"></i> Why wait, work with us today!<br><br>
	  			
	  			</p>
	  		</div>	
	  		<div class="col-12 button-onea">
	  			<a href="#contacty" class="btn btn-primary btn-lg button-one mx-auto">Get Started</a>
	  		</div> 
	  		<div class="col-12">
	  				&nbsp;
	  		</div> 		
	  	</div>
	  </div>
	</div>
	<div class="row">
	  <div class="services" id="servicesy">
	  	<br>
	  	<br>
	  	<h3 class="heading">Services</h3>
	  	<br>
	  	<div class="text-light">
	  		<p class="standard-font">We offer three main packages </p><br>
	  	</div>
	  	<div class="row justify-content-center">
	  		<div class="col-10 col-sm-8 col-md-8 col-lg-3 service1 mx-4">
	  			<br>
	  			<h4 class="package-title">The Gold Package</h4>
	  			<br>	  	
	  			<br>
	  			<i class="bi bi-check-circle-fill bicon-service"></i> <span class="service-text">Website Development</span>
	  			<br>
	  			<br>
	  			<i class="bi bi-check-circle-fill bicon-service"></i> <span class="service-text">Website Deployment</span>
	  			<br>
	  			<br>
	  			<i class="bi bi-check-circle-fill bicon-service"></i> <span class="service-text">Website Management</span>
	  			<br>
	  			<br>
	  			<i class="bi bi-check-circle-fill bicon-service"></i> <span class="service-text">Website Maintanance</span>
	  			<br><br>
	  			<div class="col-12">
	  				<p class="stars-align">
	  					<i class="bi bi-star-fill bicon-service1"></i><i class="bi bi-star-fill bicon-service1"></i><i class="bi bi-star-fill bicon-service1"></i><i class="bi bi-star-fill bicon-service1"></i><i class="bi bi-star-fill bicon-service1"></i><i class="bi bi-star-fill bicon-service1"></i><i class="bi bi-star-fill bicon-service1"></i><i class="bi bi-star-fill bicon-service1"></i><i class="bi bi-star-fill bicon-service1"></i><i class="bi bi-star-fill bicon-service1"></i>
	  				</p>
	  			</div>	  			
	  		</div>
	  		<div class="col-10 col-sm-8 col-md-8 col-lg-3 service2 mx-4">
	  			<br>
	  			<h4 class="package-title">The Silver Package</h4>
	  			<br>
	  			<br>
	  			<i class="bi bi-check-circle-fill bicon-service"></i> <span class="service-text">Website Development</span>
	  			<br>
	  			<br>
	  			<i class="bi bi-check-circle-fill bicon-service"></i> <span class="service-text">Website Deployment</span>	
	  			<br><br>
	  			<div class="col-12">
	  				<p class="stars-align">
	  					<i class="bi bi-star-fill bicon-service1"></i><i class="bi bi-star-fill bicon-service1"></i><i class="bi bi-star-fill bicon-service1"></i><i class="bi bi-star-fill bicon-service1"></i><i class="bi bi-star-fill bicon-service1"></i><i class="bi bi-star-fill bicon-service1"></i><i class="bi bi-star-fill bicon-service1"></i>
	  				</p>
	  			</div>  			
	  		</div>
	  		<div class="col-10 col-sm-8 col-md-8 col-lg-3 service3 mx-4">
	  			<br>
	  			<h4 class="package-title text-light">The Bronze Package</h4>
	  			<br>	
	  			<br>
	  			<i class="bi bi-check-circle-fill bicon-service"></i> <span class="service-text text-light">Website Development</span>  
	  			<br><br>
	  			<div class="col-12">
	  				<p class="stars-align">
	  					<i class="bi bi-star-fill bicon-service1"></i><i class="bi bi-star-fill bicon-service1"></i><i class="bi bi-star-fill bicon-service1"></i><i class="bi bi-star-fill bicon-service1"></i>
	  				</p>
	  			</div>			
	  		</div>	
	  		<div class="col-12">
	  			<br><br>
	  			<a href="#contacty" class="btn btn-lg btn-primary">Start Now</a>
	  			<br><br>
	  		</div>  		
	  	</div>
	  	
	  </div>
	</div>

	<div class="row">
	  <div class="portifolio" id="portifolioy">
	  	<br>
	  	<br>
	  	<h3 class="heading">Portifolio</h3>
	  	<br>
	  	<div class="row justify-content-center">
	  		<div class="col-12">
	  			<p class="text-light standard-font">
	  				Below are some of our most recent projects.
	  			</p>
	  			<br>
	  		</div>
	  		<div class="col-10 col-sm-8 col-md-8 col-lg-3 mx-4 portifolio-item">
	  			<br>
	  			<br>
	  			<span class="text-light portifolio-text">Consultancy Agency Website</span>
	  			<br><br>
	  			<a href="#" class="portifolio-link">www.aspireltd.com</a>
	  		</div>
	  		<div class="col-10 col-sm-8 col-md-8 col-lg-3 mx-4 portifolio-item">
	  			<br>
	  			<br>
	  			<span class="text-light portifolio-text">Music Services Website</span>
	  			<br><br>
	  			<a href="#" class="portifolio-link">www.pablosounds.com</a>
	  		</div>
	  		<div class="col-10 col-sm-8 col-md-8 col-lg-3 mx-4 portifolio-item">
	  			<br>
	  			<br>
	  			<span class="text-light portifolio-text">Online Tutoring Website</span>
	  			<br><br>
	  			<a href="#" class="portifolio-link">www.onlineclassesmw.com</a>
	  		</div>
	  	</div>
	  	<br><br>
	  </div>
	</div>

	<div class="row">
		<div class="contact" id="contacty">
			<br>
		  	<br>
		  	<h3 class="heading">Contact Us</h3>
		  	<br>
			<div class="row justify-content-center">
				<div class="col-10 col-sm-8 col-md-8 col-lg-4 mx-4 contact-form">
					<br>
					<i class="bi bi-geo-alt-fill bicon-contact"></i> <span class="contact-term">Location</span><br> <span class="contact-term2">Mzuzu City, Malawi</span>
					<br><br>
					<i class="bi bi-envelope-fill bicon-contact"></i> <span class="contact-term">Email</span><br><span class="contact-term2">info@cyberdimension.com</span>
					<br><br>
					<i class="bi bi-telephone-fill bicon-contact"></i> <span class="contact-term">Call</span><br> <span class="contact-term2">+265 999 358 339</span>
					<br><br>
					<i class="bi bi-whatsapp bicon-contact"></i> <span class="contact-term">Whatsapp</span><br> <span class="contact-term2">+265 999 358 339</span>
				</div>

				<div class="col-10 col-sm-8 col-md-8 col-lg-5 mx-4 contact-form">
					<br>
					<h4 class="send-a-message">Send a message</h4>
					<form action="index.php" method="POST">
					<input type="text" name="name" placeholder="Name" class="text-input" required>
					<br><br>
					<input type="text" name="email" placeholder="Email" class="text-input" required>
					<br><br>
					<input type="text" name="number" placeholder="Phone Number" class="text-input" required>
					<br><br>
					<input type="text" name="subject" placeholder="Subject" class="text-input" required>
					<br><br>
					<button class="btn btn-primary" name="send">Send</button>
					</form>
				</div>			
			</div>	
			<br><br>
		</div>
	</div>

	<div class="row">
		<div class="footer col-12 bg-primary">
			2022 &copy;Cyber Dimension
		</div>
	</div>
	<?php

		if (isset($_POST['send'])) {
			$name = $_POST['name'];
			$email = $_POST['email'];
			$number = $_POST['number'];
			$subject = $_POST['subject'];

			$sql = "INSERT INTO messages(name,email,number,subject) values('$name','$email','$number','$subject')";
			$result = mysqli_query($conn, $sql);

			if($result){
                  echo"

                      <script>
                        Swal.fire({
                            title: 'Message',
                            text: 'Message Sent Successfully',
                            icon: 'success',
                            confirmButtonText: 'OK',
                              }).then((result) => {
                            if (result.isConfirmed) {
                              window.location.href='index.php';
                                  }
                              })
                    </script>";
                }
                else{
                  echo"

                      <script>
                        Swal.fire({
                            title: 'Message',
                            text: 'Failed To Send Message',
                            icon: 'error',
                            confirmButtonText: 'OK',
                              }).then((result) => {
                            if (result.isConfirmed) {
                              window.location.href='index.php';
                                  }
                              })
                    </script>";
                }
		}

	?>
	
</body>

<script type="text/javascript" src="assets/js/bootstrap.bundle.min.js"></script>
<script src="assets/typed.js/typed.min.js"></script>
<script src="assets/js/main.js"></script>
<script src="assets/aos/aos.js"></script>
</html>