<?php

        session_start();
        session_unset();
        header("Location: admin2001.php");

 ?>
