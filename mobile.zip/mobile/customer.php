<?php

  include "conn.php";

?>

<!doctype html>
<html>
<head>
  <meta charset=utf-8>
  <title>customer</title>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <link href="fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="ext/css/bootstrap.min.css" rel="stylesheet">

  <script src="sa/sweetalert2.min.js"></script>
  <link rel="stylesheet" href="sa/sweetalert2.min.css">
  <script src="ext/jquery-3.6.0.min.js"></script>

  <style media="screen">
    .center{
      margin: auto;
    }
    .title{
      font-size: 40px;
    }
    .color1{
        background-color: #1ABB81;
    }
    .color2{
        background-color: #C54A3B;
    }
    .autoi{
        margin: auto;
    }
    .new1{
        color:#1ABB81;
        text-decoration: none;
    }
    .new1:hover{
        text-decoration:none;

    }
    .new1:active{
        color: orange;
        text-decoration:none;

    }
    .hoverc:hover{
        transform:scale(1.1);
    }
    *{
      transition:0.5s;
    }
    body{
      background-color: #519285;
    }
    .h20{
      text-align: center;
      color: white;
    }
    .floatl{
      float: left;
    }
    .floatr{
      float: right;
    }
    .clear{
      clear: both;
    }
  </style>

</head>
<body>

  <br>

    <?php

    session_start();

    $_SESSION['clicked'] = "";
    $_SESSION['clicked1'] = "";

    if (isset($_SESSION['userida'])) {

      $userid = $_SESSION['userida'];

      $sql = "SELECT * FROM users WHERE id = '$userid'";
      $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_array($result);
          $fname = $row['fname'];
          $lname = $row['lname'];
          $balance = $row['balance'];

        echo"

        <div class='floatl text-white'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Balance: MWK $balance</div>

        <form method='post' action='customer.php' class='floatr'>

          <div class='row'>
            <div class='col-12 alignx'>
                <i class='text-white'>$fname $lname</i> &nbsp;&nbsp;&nbsp;
                <button class='btn btn-warning' type='submit' name='logout'>Logout</button>&nbsp;&nbsp;&nbsp;
            </div>
          </div>

        </form>


        <br><br>

        <hr class='clear'>

        ";

      }
    ?>

  <h2 class="h20"><b>SANKO MOBILE BANKING SERVICES</b></h2>

<br><br>

<div class="row">
  <div class="col-xl-3 col-md-6 mb-4 center">
     <div class="card shadow h-100 py-2 hoverc">
         <div class="card-body">
             <div class="row no-gutters align-items-center">
                 <div class="col mr-2">
                     <div class="text-md font-weight-bold text-success text-uppercase mb-1">
                        <form action="customer.php" method="post">
                          <input type="submit" name="send" value="Send Money" class="btn btn-success">
                        </form>
                      </div>
                 </div>
                 <div class="col-auto">
                     <i class="fas fa-money-bill fa-2x text-success"></i>
                 </div>
             </div>
         </div>
     </div>
   </div>
 </div>

 <div class="row">

    <div class="col-xl-3 col-md-6 mb-4 center">
        <div class="card shadow h-100 py-2 hoverc">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-md font-weight-bold text-success text-uppercase mb-1">
                          <form action="customer.php" method="post">
                            <input type="submit" name="withdraw" value="Withdraw Money" class="btn btn-success">
                          </form>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-money-bill-wave fa-2x text-success"></i>
                    </div>
                </div>
            </div>
        </div>
 </div>

</div>


<div class="row">

   <div class="col-xl-3 col-md-6 mb-4 center">
       <div class="card shadow h-100 py-2 hoverc">
           <div class="card-body">
               <div class="row no-gutters align-items-center">
                   <div class="col mr-2">
                       <div class="text-md font-weight-bold text-success text-uppercase mb-1">
                         <form action="customer.php" method="post">
                           <input type="submit" name="buy" value="Buy Credit" class="btn btn-success">
                         </form>
                       </div>
                   </div>
                   <div class="col-auto">
                       <i class="fas fa-money-bill fa-2x text-success"></i>
                   </div>
               </div>
           </div>
       </div>
</div>

</div>

</div>

</body>
</html>

<?php

  if(isset($_POST['send'])){

      if(isset($_SESSION['userida'])){
        echo "<br><form action='customer.php' method='post'>

          <div class='row'>
            <div class='col-12'>
              <div class='text-white col-6 autoi text-center'>

                <span class='fa fa-money-bill fa-4x hoverc'></span>
                <h2><i>send money</i></h2>
                <br>
                <p><i>Phone Number </i><input type='text' name='pnumber' required></p>
                <p><i>Amount &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i><input type='text' name='amount' required></p>
                <button type='submit' class='btn btn-success' name='send1'><i>Send</i></button>
              </div>
            </div>
          </div>

        </form>

        <br><br><br>

        ";
        if(isset($_SESSION['send'])){
          unset($_SESSION['send']);
        }
        if(isset($_SESSION['withdraw'])){
          unset($_SESSION['withdraw']);
        }
        if(isset($_SESSION['buy'])){
          unset($_SESSION['buy']);
        }
      }
      else {

        $active = 1;
        $_SESSION['choice'] = $active;
        $_SESSION['send'] = " ";

      echo "<br><form action='customer.php' method='post'>

        <div class='row'>
          <div class='col-12'>
            <div class='text-white col-6 autoi text-center'>

              <span class='fa fa-user-circle fa-4x hoverc'></span>
              <h2><i>Sign in</i></h2>
              <br>
              <p><i>Phone Number </i><input type='text' name='cnumber' required></p>
              <p><i>Pin Code &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i><input type='password' name='cpin' required></p>
              <button type='submit' class='btn btn-success' name='login'><i>login</i></button>
            </div>
          </div>
        </div>

      </form>

      <br><br><br>

      ";
    }
  }

?>

<?php

  if(isset($_POST['withdraw'])){

    if(isset($_SESSION['userida'])){
      echo "<br><form action='customer.php' method='post'>

        <div class='row'>
          <div class='col-12'>
            <div class='text-white col-6 autoi text-center'>

              <span class='fa fa-money-bill fa-4x hoverc'></span>
              <h2><i>withdraw money</i></h2>
              <br>
              <p><i>Agent Code &nbsp;</i><input type='text' name='acode' required></p>
              <p><i>Amount&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i><input type='text' name='amount' required></p>
              <button type='submit' class='btn btn-success' name='withdraw1'><i>Withdraw</i></button>
            </div>
          </div>
        </div>

      </form>

      <br><br><br>

      ";

      if(isset($_SESSION['send'])){
        unset($_SESSION['send']);
      }
      if(isset($_SESSION['withdraw'])){
        unset($_SESSION['withdraw']);
      }
      if(isset($_SESSION['buy'])){
        unset($_SESSION['buy']);
      }
    }
    else {

      $active = 2;
      $_SESSION['choice'] = $active;
      $_SESSION['withdraw'] = " ";

    echo "<br><form action='customer.php' method='post'>

      <div class='row'>
        <div class='col-12'>
          <div class='text-white col-6 autoi text-center'>

            <span class='fa fa-user-circle fa-4x hoverc'></span>
            <h2><i>Sign in</i></h2>
            <br>
            <p><i>Phone Number </i><input type='text' name='cnumber' required></p>
            <p><i>Pin Code &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i><input type='password' name='cpin' required></p>
            <button type='submit' class='btn btn-success' name='login'><i>login</i></button>
          </div>
        </div>
      </div>

    </form>

    <br><br><br>

    ";
  }
}

?>

<?php

  if(isset($_POST['buy'])){

    if(isset($_SESSION['userida'])){
      echo "<br><form action='customer.php' method='post'>

        <div class='row'>
          <div class='col-12'>
            <div class='text-white col-6 autoi text-center'>

              <span class='fa fa-money-bill fa-4x hoverc'></span>
              <h2><i>Buy Credit</i></h2>
              <br>
              <p><i>Phone Number&nbsp;</i><input type='text' name='pnumber' required></p>
              <p><i>Amount&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i><input type='text' name='amount' required></p>
              <button type='submit' class='btn btn-success' name='buy1'><i>Buy</i></button>
            </div>
          </div>
        </div>

      </form>

      <br><br><br>

      ";

      if(isset($_SESSION['send'])){
        unset($_SESSION['send']);
      }
      if(isset($_SESSION['withdraw'])){
        unset($_SESSION['withdraw']);
      }
      if(isset($_SESSION['buy'])){
        unset($_SESSION['buy']);
      }
    }
    else {

      $active = 3;
      $_SESSION['choice'] = $active;
      $_SESSION['buy'] = " ";

    echo "<br><form action='customer.php' method='post'>

      <div class='row'>
        <div class='col-12'>
          <div class='text-white col-6 autoi text-center'>

            <span class='fa fa-user-circle fa-4x hoverc'></span>
            <h2><i>Sign in</i></h2>
            <br>
            <p><i>Phone Number </i><input type='text' name='cnumber' required></p>
            <p><i>Pin Code &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i><input type='password' name='cpin' required></p>
            <button type='submit' class='btn btn-success' name='login'><i>login</i></button>
          </div>
        </div>
      </div>

    </form>

    <br><br><br>

    ";
  }
}

?>


<?php

  if(isset($_POST['send1'])){
    $to = $_POST['pnumber'];
    $amount = $_POST['amount'];

    $ucid = $_SESSION['userida'];

    $sql = "SELECT * FROM users WHERE id='$ucid'";
    $result = mysqli_query($conn,$sql);

    $row=mysqli_fetch_array($result);
    $balance = $row['balance'];

    if($balance <= $amount){
      echo "<script>
              Swal.fire({
                          title: 'Transaction Failed',
                          text: 'Balance is low than the amount',
                          icon: 'error',
                          confirmButtonText: 'OK',
                              }).then((result) => {
                          if (result.isConfirmed) {
                              window.location.href='customer.php';
                          }
                      })
             </script>";
    }
    else {

      if(isset($_SESSION['send'])){
        unset($_SESSION['send']);
      }
      if(isset($_SESSION['withdraw'])){
        unset($_SESSION['withdraw']);
      }
      if(isset($_SESSION['buy'])){
        unset($_SESSION['buy']);
      }

      $_SESSION['balance'] = $balance;
      $_SESSION['amount'] = $amount;
      $_SESSION['to'] = $to;

      $sqlsecu = "SELECT * FROM security WHERE cuid = '$ucid' order by rand()";
      $resultsecu = mysqli_query($conn,$sqlsecu);

      $rowsecu = mysqli_fetch_array($resultsecu);
        $secq = $rowsecu['sq'];
        $seca = $rowsecu['sa'];

        $_SESSION['seca'] = $seca;

        echo "<br><form action='customer.php' method='post'>

          <div class='row'>
            <div class='col-12'>
              <div class='text-white col-6 autoi text-center'>

                <span class='fa fa-lock fa-4x hoverc'></span>
                <h2><i>send money</i></h2>
                <br>
                <p><i>Security Question </i>$secq</p>
                <p><i>Answer </i><input type='text' name='seca' required></p>
                <button type='submit' class='btn btn-success' name='answer'><i>Answer</i></button>
              </div>
            </div>
          </div>

        </form>

        <br><br><br>

        ";
    }
  }

?>

<?php

  if(isset($_POST['buy1'])){
    $pnumber = $_POST['pnumber'];
    $amount = $_POST['amount'];

    $ucid = $_SESSION['userida'];

    $sql = "SELECT * FROM users WHERE id='$ucid'";
    $result = mysqli_query($conn,$sql);

    $row=mysqli_fetch_array($result);
    $balance = $row['balance'];

    if($balance <= $amount){
      echo "<script>
              Swal.fire({
                          title: 'Transaction Failed',
                          text: 'Balance is low than the amount',
                          icon: 'error',
                          confirmButtonText: 'OK',
                              }).then((result) => {
                          if (result.isConfirmed) {
                              window.location.href='customer.php';
                          }
                      })
             </script>";
    }
    else {

      if(isset($_SESSION['send'])){
        unset($_SESSION['send']);
      }
      if(isset($_SESSION['withdraw'])){
        unset($_SESSION['withdraw']);
      }
      if(isset($_SESSION['buy'])){
        unset($_SESSION['buy']);
      }

      $_SESSION['balance'] = $balance;
      $_SESSION['amount'] = $amount;
      $_SESSION['pnumber'] = $pnumber;

      $sqlsecu = "SELECT * FROM security WHERE cuid = '$ucid' order by rand()";
      $resultsecu = mysqli_query($conn,$sqlsecu);

      $rowsecu = mysqli_fetch_array($resultsecu);
        $secq = $rowsecu['sq'];
        $seca = $rowsecu['sa'];

        $_SESSION['seca'] = $seca;

        echo "<br><form action='customer.php' method='post'>

          <div class='row'>
            <div class='col-12'>
              <div class='text-white col-6 autoi text-center'>

                <span class='fa fa-lock fa-4x hoverc'></span>
                <h2><i>send money</i></h2>
                <br>
                <p><i>Security Question </i>$secq</p>
                <p><i>Answer </i><input type='text' name='seca' required></p>
                <button type='submit' class='btn btn-success' name='answer2'><i>Answer</i></button>
              </div>
            </div>
          </div>

        </form>

        <br><br><br>

        ";
    }
  }

?>


<?php

  if(isset($_POST['withdraw1'])){
    $acode = $_POST['acode'];
    $amount = $_POST['amount'];

    $ucid = $_SESSION['userida'];

    $sql = "SELECT * FROM users WHERE id='$ucid'";
    $result = mysqli_query($conn,$sql);

    $row=mysqli_fetch_array($result);
    $balance = $row['balance'];

    if($balance <= $amount){
      echo "<script>
              Swal.fire({
                          title: 'Transaction Failed',
                          text: 'Balance is low than the amount',
                          icon: 'error',
                          confirmButtonText: 'OK',
                              }).then((result) => {
                          if (result.isConfirmed) {
                              window.location.href='customer.php';
                          }
                      })
             </script>";
    }
    else {

      if(isset($_SESSION['send'])){
        unset($_SESSION['send']);
      }
      if(isset($_SESSION['withdraw'])){
        unset($_SESSION['withdraw']);
      }
      if(isset($_SESSION['buy'])){
        unset($_SESSION['buy']);
      }

      $_SESSION['balance'] = $balance;
      $_SESSION['amount'] = $amount;
      $_SESSION['acode'] = $acode;

      $sqlsecu = "SELECT * FROM security WHERE cuid = '$ucid' order by rand()";
      $resultsecu = mysqli_query($conn,$sqlsecu);

      $rowsecu = mysqli_fetch_array($resultsecu);
        $secq = $rowsecu['sq'];
        $seca = $rowsecu['sa'];

        $_SESSION['seca'] = $seca;

        echo "<br><form action='customer.php' method='post'>

          <div class='row'>
            <div class='col-12'>
              <div class='text-white col-6 autoi text-center'>

                <span class='fa fa-lock fa-4x hoverc'></span>
                <h2><i>send money</i></h2>
                <br>
                <p><i>Security Question </i>$secq</p>
                <p><i>Answer </i><input type='text' name='seca' required></p>
                <button type='submit' class='btn btn-success' name='answer1'><i>Answer</i></button>
              </div>
            </div>
          </div>

        </form>

        <br><br><br>

        ";
    }
  }

?>

<?php

if(isset($_POST['answer'])){

  $answer = $_POST['seca'];
  $seca = $_SESSION['seca'];
  $balance = $_SESSION['balance'];
  $amount = $_SESSION['amount'];
  $to = $_SESSION['to'];
  $ucid = $_SESSION['userida'];

  if($answer==$seca){

    $sqlag = "SELECT * FROM users WHERE pnumber='$to'";
    $resultag = mysqli_query($conn,$sqlag);

    if(mysqli_num_rows($resultag)>0){

      $rowag = mysqli_fetch_array($resultag);
        $idag = $rowag['id'];
        $balanceag = $rowag['balance'];

        $ogb = $balance - $amount;

      $sql1 = "SELECT * FROM users WHERE id='$ucid'";
      $result1 = mysqli_query($conn,$sql1);

      if(mysqli_num_rows($result1)>0){
          $row1 = mysqli_fetch_array($result1);
            $uzerid = $row1['id'];
            $uzerb = $row1['balance'];

            $today = date("y-m-d");

            $newb = $balanceag + $amount;

            $sql2 = "UPDATE users SET balance='$ogb' WHERE id='$uzerid'";
            $result2 = mysqli_query($conn,$sql2);

            $sql22 = "UPDATE users SET balance='$newb' WHERE id='$idag'";
            $result22 = mysqli_query($conn,$sql22);

            $sql3 = "INSERT INTO trans(cid,initial,final,date,agent) VALUES('$uzerid','$uzerb','$ogb','$today','$ucid')";
            $result3 = mysqli_query($conn,$sql3);

            $sql3 = "INSERT INTO trans(cid,initial,final,date,agent) VALUES('$idag','$balanceag','$newb','$today','$ucid')";
            $result3 = mysqli_query($conn,$sql3);

            if($result3){
              if(isset($_SESSION['send'])){
                unset($_SESSION['send']);
              }
              if(isset($_SESSION['withdraw'])){
                unset($_SESSION['withdraw']);
              }
              if(isset($_SESSION['buy'])){
                unset($_SESSION['buy']);
              }

              $sqlreset3 = "UPDATE attempts SET noa='0' WHERE cuid='$ucid'";
              $resultreset3 = mysqli_query($conn,$sqlreset3);

              echo "<script>
                      Swal.fire({
                                  title: 'Transaction Completed',
                                  text: 'Money sent successfully',
                                  icon: 'success',
                                  confirmButtonText: 'OK',
                                      }).then((result) => {
                                  if (result.isConfirmed) {
                                      window.location.href='customer.php';
                                  }
                              })
                     </script>";
            }
            else {
              echo "<script>
                      Swal.fire({
                                  title: 'Transaction Failed',
                                  text: 'Transaction not processed',
                                  icon: 'error',
                                  confirmButtonText: 'OK',
                                      }).then((result) => {
                                  if (result.isConfirmed) {
                                      window.location.href='customer.php';
                                  }
                              })
                     </script>";
            }
      }
      else {
        echo "<script>
                Swal.fire({
                            title: 'Transaction Failed',
                            text: 'Receipient not registered',
                            icon: 'error',
                            confirmButtonText: 'OK',
                                }).then((result) => {
                            if (result.isConfirmed) {
                                window.location.href='customer.php';
                            }
                        })
               </script>";
      }
      }
    else {
      echo "<script>
              Swal.fire({
                          title: 'Transaction Failed',
                          text: 'Phone number not correct',
                          icon: 'error',
                          confirmButtonText: 'OK',
                              }).then((result) => {
                          if (result.isConfirmed) {
                              window.location.href='customer.php';
                          }
                      })
             </script>";
    }

  }
  else {
           $sqlf = "SELECT * FROM attempts WHERE cuid = '$ucid'";
           $resultf = mysqli_query($conn,$sqlf);

           if(mysqli_num_rows($resultf)>0){
             $rowf = mysqli_fetch_array($resultf);
             $noaf = $rowf['noa'];

             $noaf1 = $noaf + 1;

              $sqlf1 = "UPDATE attempts SET noa ='$noaf1' WHERE cuid='$ucid'";
              $resultf1 = mysqli_query($conn,$sqlf1);

              if($noaf1>2){
                session_unset();
                echo "<script>
                      Swal.fire({
                             title: 'Security Authentication',
                             text: 'Maximum security questions attempts reached.',
                             icon: 'error',
                             confirmButtonText: 'Ok',
                                 }).then((result) => {
                             if (result.isConfirmed) {
                                  window.location.href='customer.php';
                             }
                         })
                         </script>

              ";
              }
              else{
                echo "<script>
                        Swal.fire({
                                    title: 'Security Authentication',
                                    text: 'Incorrect Answer, $noaf1/3 attempts',
                                    icon: 'error',
                                    confirmButtonText: 'OK',
                                        }).then((result) => {
                                    if (result.isConfirmed) {
                                        window.location.href='customer.php';
                                    }
                                })
                       </script>";
                  }
           }
           else {
             $sqlx = "INSERT INTO attempts(cuid,noa)VALUES('$ucid','1')";
             $resultx = mysqli_query($conn,$sqlx);


               echo "<script>
                       Swal.fire({
                                   title: 'Security Authentication',
                                   text: 'Incorrect Answer, 1/3 attempts',
                                   icon: 'error',
                                   confirmButtonText: 'OK',
                                       }).then((result) => {
                                   if (result.isConfirmed) {
                                       window.location.href='customer.php';
                                   }
                               })
                      </script>";
           }

  }
}

?>


<?php

if(isset($_POST['answer1'])){

  $answer = $_POST['seca'];
  $seca = $_SESSION['seca'];
  $balance = $_SESSION['balance'];
  $amount = $_SESSION['amount'];
  $acode = $_SESSION['acode'];
  $ucid = $_SESSION['userida'];

  if($answer==$seca){

    $sqlag = "SELECT * FROM agents WHERE acode='$acode'";
    $resultag = mysqli_query($conn,$sqlag);

    if(mysqli_num_rows($resultag)>0){

      $ogb = $balance - $amount;

      $sql1 = "SELECT * FROM users WHERE id='$ucid'";
      $result1 = mysqli_query($conn,$sql1);

      if(mysqli_num_rows($result1)>0){
          $row1 = mysqli_fetch_array($result1);
            $uzerid = $row1['id'];
            $uzerb = $row1['balance'];

            $today = date("y-m-d");

            $newb = $ogb;

            $sql2 = "UPDATE users SET balance='$newb' WHERE id='$uzerid'";
            $result2 = mysqli_query($conn,$sql2);

            $sql3 = "INSERT INTO trans(cid,initial,final,date,agent) VALUES('$uzerid','$uzerb','$newb','$today','$acode')";
            $result3 = mysqli_query($conn,$sql3);

            if($result3){
              if(isset($_SESSION['send'])){
                unset($_SESSION['send']);
              }
              if(isset($_SESSION['withdraw'])){
                unset($_SESSION['withdraw']);
              }
              if(isset($_SESSION['buy'])){
                unset($_SESSION['buy']);
              }

              $sqlreset2 = "UPDATE attempts SET noa='0' WHERE cuid='$ucid'";
              $resultreset2 = mysqli_query($conn,$sqlreset2);

              echo "<script>
                      Swal.fire({
                                  title: 'Transaction Completed',
                                  text: 'Money withdrawn successfully',
                                  icon: 'success',
                                  confirmButtonText: 'OK',
                                      }).then((result) => {
                                  if (result.isConfirmed) {
                                      window.location.href='customer.php';
                                  }
                              })
                     </script>";
            }
            else {
              echo "<script>
                      Swal.fire({
                                  title: 'Transaction Failed',
                                  text: 'Transaction not processed',
                                  icon: 'error',
                                  confirmButtonText: 'OK',
                                      }).then((result) => {
                                  if (result.isConfirmed) {
                                      window.location.href='customer.php';
                                  }
                              })
                     </script>";
            }
      }
      else {
        echo "<script>
                Swal.fire({
                            title: 'Transaction Failed',
                            text: 'Receipient not registered',
                            icon: 'error',
                            confirmButtonText: 'OK',
                                }).then((result) => {
                            if (result.isConfirmed) {
                                window.location.href='customer.php';
                            }
                        })
               </script>";
      }
      }
    else {
      echo "<script>
              Swal.fire({
                          title: 'Transaction Failed',
                          text: 'Agent code not correct',
                          icon: 'error',
                          confirmButtonText: 'OK',
                              }).then((result) => {
                          if (result.isConfirmed) {
                              window.location.href='customer.php';
                          }
                      })
             </script>";
    }

  }
  else {
           $sqlf = "SELECT * FROM attempts WHERE cuid = '$ucid'";
           $resultf = mysqli_query($conn,$sqlf);

           if(mysqli_num_rows($resultf)>0){
             $rowf = mysqli_fetch_array($resultf);
             $noaf = $rowf['noa'];

             $noaf1 = $noaf + 1;

              $sqlf1 = "UPDATE attempts SET noa ='$noaf1' WHERE cuid='$ucid'";
              $resultf1 = mysqli_query($conn,$sqlf1);

              if($noaf1>2){
                session_unset();
                echo "<script>
                      Swal.fire({
                             title: 'Security Authentication',
                             text: 'Maximum security questions attempts reached.',
                             icon: 'error',
                             confirmButtonText: 'Ok',
                                 }).then((result) => {
                             if (result.isConfirmed) {
                                  window.location.href='customer.php';
                             }
                         })
                         </script>

              ";
              }
              else{
                echo "<script>
                        Swal.fire({
                                    title: 'Security Authentication',
                                    text: 'Incorrect Answer, $noaf1/3 attempts',
                                    icon: 'error',
                                    confirmButtonText: 'OK',
                                        }).then((result) => {
                                    if (result.isConfirmed) {
                                        window.location.href='customer.php';
                                    }
                                })
                       </script>";
                  }
           }
           else {
             $sqlx = "INSERT INTO attempts(cuid,noa)VALUES('$ucid','1')";
             $resultx = mysqli_query($conn,$sqlx);


               echo "<script>
                       Swal.fire({
                                   title: 'Security Authentication',
                                   text: 'Incorrect Answer, 1/3 attempts',
                                   icon: 'error',
                                   confirmButtonText: 'OK',
                                       }).then((result) => {
                                   if (result.isConfirmed) {
                                       window.location.href='customer.php';
                                   }
                               })
                      </script>";
           }

  }
}

?>


<?php

if(isset($_POST['answer2'])){

  $answer = $_POST['seca'];
  $seca = $_SESSION['seca'];
  $balance = $_SESSION['balance'];
  $amount = $_SESSION['amount'];
  $pnumber = $_SESSION['pnumber'];
  $ucid = $_SESSION['userida'];

  if($answer==$seca){

      $ogb = $balance - $amount;

      $sql1 = "SELECT * FROM users WHERE id='$ucid'";
      $result1 = mysqli_query($conn,$sql1);

      if(mysqli_num_rows($result1)>0){
          $row1 = mysqli_fetch_array($result1);
            $uzerid = $row1['id'];
            $uzerb = $row1['balance'];

            $today = date("y-m-d");

            $newb = $ogb;

            $sql2 = "UPDATE users SET balance='$newb' WHERE id='$uzerid'";
            $result2 = mysqli_query($conn,$sql2);

            $sql3 = "INSERT INTO trans(cid,initial,final,date,agent) VALUES('$uzerid','$uzerb','$newb','$today','$ucid')";
            $result3 = mysqli_query($conn,$sql3);

            if($result3){
              if(isset($_SESSION['send'])){
                unset($_SESSION['send']);
              }
              if(isset($_SESSION['withdraw'])){
                unset($_SESSION['withdraw']);
              }
              if(isset($_SESSION['buy'])){
                unset($_SESSION['buy']);
              }

              $sqlreset1 = "UPDATE attempts SET noa='0' WHERE cuid='$ucid'";
              $resultreset1 = mysqli_query($conn,$sqlreset1);

              echo "<script>
                      Swal.fire({
                                  title: 'Transaction Completed',
                                  text: 'Credit bought successfully',
                                  icon: 'success',
                                  confirmButtonText: 'OK',
                                      }).then((result) => {
                                  if (result.isConfirmed) {
                                      window.location.href='customer.php';
                                  }
                              })
                     </script>";
            }
            else {
              echo "<script>
                      Swal.fire({
                                  title: 'Transaction Failed',
                                  text: 'Transaction not processed',
                                  icon: 'error',
                                  confirmButtonText: 'OK',
                                      }).then((result) => {
                                  if (result.isConfirmed) {
                                      window.location.href='customer.php';
                                  }
                              })
                     </script>";
            }
      }
      else {
        echo "<script>
                Swal.fire({
                            title: 'Transaction Failed',
                            text: 'Receipient not registered',
                            icon: 'error',
                            confirmButtonText: 'OK',
                                }).then((result) => {
                            if (result.isConfirmed) {
                                window.location.href='customer.php';
                            }
                        })
               </script>";
      }

  }
  else {
           $sqlf = "SELECT * FROM attempts WHERE cuid = '$ucid'";
           $resultf = mysqli_query($conn,$sqlf);

           if(mysqli_num_rows($resultf)>0){
             $rowf = mysqli_fetch_array($resultf);
             $noaf = $rowf['noa'];

             $noaf1 = $noaf + 1;

              $sqlf1 = "UPDATE attempts SET noa ='$noaf1' WHERE cuid='$ucid'";
              $resultf1 = mysqli_query($conn,$sqlf1);

              if($noaf1>2){
                session_unset();
                echo "<script>
                      Swal.fire({
                             title: 'Security Authentication',
                             text: 'Maximum security questions attempts reached.',
                             icon: 'error',
                             confirmButtonText: 'Ok',
                                 }).then((result) => {
                             if (result.isConfirmed) {
                                  window.location.href='customer.php';
                             }
                         })
                         </script>

              ";
              }
              else{
                echo "<script>
                        Swal.fire({
                                    title: 'Security Authentication',
                                    text: 'Incorrect Answer, $noaf1/3 attempts',
                                    icon: 'error',
                                    confirmButtonText: 'OK',
                                        }).then((result) => {
                                    if (result.isConfirmed) {
                                        window.location.href='customer.php';
                                    }
                                })
                       </script>";
                  }
           }
           else {
             $sqlx = "INSERT INTO attempts(cuid,noa)VALUES('$ucid','1')";
             $resultx = mysqli_query($conn,$sqlx);


               echo "<script>
                       Swal.fire({
                                   title: 'Security Authentication',
                                   text: 'Incorrect Answer, 1/3 attempts',
                                   icon: 'error',
                                   confirmButtonText: 'OK',
                                       }).then((result) => {
                                   if (result.isConfirmed) {
                                       window.location.href='customer.php';
                                   }
                               })
                      </script>";
           }

  }
}

?>

<?php

    if(isset($_POST['login'])){
      $cnumber  = $_POST['cnumber'];
      $cpin   = sha1($_POST['cpin']);

      $sql = "SELECT * FROM users WHERE pnumber='$cnumber' AND pcode='$cpin'";
      $result = mysqli_query($conn,$sql);

      if(mysqli_num_rows($result)>0){
        $row = mysqli_fetch_array($result);
          $id    = $row['id'];
          $fname = $row['fname'];
          $lname = $row['lname'];

          $onoa = 0;

        $sqlgate = "SELECT * FROM attempts WHERE cuid='$id'";
        $resultgate = mysqli_query($conn,$sqlgate);

        if(mysqli_num_rows($resultgate)>0){

          $rowgate = mysqli_fetch_array($resultgate);

          $onoa = $rowgate['noa'];
        }

        if($onoa>2){
          echo "<script>
                  Swal.fire({
                              title: 'Failed To Login',
                              text: 'Login attempts exceeded maximum, visit our nearest offices and get help.',
                              icon: 'error',
                              confirmButtonText: 'OK',
                                  }).then((result) => {
                              if (result.isConfirmed) {
                                  window.location.href='customer.php';
                              }
                          })
                 </script>";
        }
        else {

        $_SESSION['userida'] = $id;

        $sqlc = "SELECT * FROM security WHERE cuid='$id'";
        $resultc = mysqli_query($conn,$sqlc);
        $numrows = mysqli_num_rows($resultc);

          if($cpin == sha1('1234') OR $numrows<1){
            echo "<script>
                    Swal.fire({
                                title: 'Failed To Login',
                                text: 'Change default password and/or add security questions',
                                icon: 'error',
                                confirmButtonText: 'OK',
                                    }).then((result) => {
                                if (result.isConfirmed) {
                                    window.location.href='security.php';
                                }
                            })
                   </script>";

          }
          else {
            $sqlreset = "UPDATE attempts SET noa='0' WHERE cuid='$id'";
            $resultreset = mysqli_query($conn,$sqlreset);

            echo "<script>window.location.href='customer.php';</script>";

            $_SESSION['send'] = "<br><form action='customer.php' method='post'>

              <div class='row'>
                <div class='col-12'>
                  <div class='text-white col-6 autoi text-center'>

                    <span class='fa fa-money-bill fa-4x hoverc'></span>
                    <h2><i>send money</i></h2>
                    <br>
                    <p><i>Phone Number </i><input type='text' name='pnumber' required></p>
                    <p><i>Amount &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i><input type='text' name='amount' required></p>
                    <button type='submit' class='btn btn-success' name='send1'><i>Send</i></button>
                  </div>
                </div>
              </div>

            </form>

            <br><br><br>

            ";

            $_SESSION['withdraw'] = "<br><form action='customer.php' method='post'>

              <div class='row'>
                <div class='col-12'>
                  <div class='text-white col-6 autoi text-center'>

                    <span class='fa fa-money-bill fa-4x hoverc'></span>
                    <h2><i>withdraw money</i></h2>
                    <br>
                    <p><i>Agent Code &nbsp;</i><input type='text' name='acode' required></p>
                    <p><i>Amount&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i><input type='text' name='amount' required></p>
                    <button type='submit' class='btn btn-success' name='withdraw1'><i>Withdraw</i></button>
                  </div>
                </div>
              </div>

            </form>

            <br><br><br>

            ";

            $_SESSION['buy'] = "<br><form action='customer.php' method='post'>

              <div class='row'>
                <div class='col-12'>
                  <div class='text-white col-6 autoi text-center'>

                  <span class='fa fa-money-bill fa-4x hoverc'></span>
                  <h2><i>Buy Credit</i></h2>
                  <br>
                  <p><i>Phone Number&nbsp;</i><input type='text' name='pnumber' required></p>
                  <p><i>Amount&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i><input type='text' name='amount' required></p>
                  <button type='submit' class='btn btn-success' name='buy1'><i>Buy</i></button>
                  </div>
                </div>
              </div>

            </form>

            <br><br><br>

            ";
          }
        }
        }

      else {
            $sqlcheck = "SELECT * FROM users WHERE pnumber='$cnumber'";
            $resultcheck = mysqli_query($conn,$sqlcheck);

            if(mysqli_num_rows($resultcheck)>0){
              $rowcheck = mysqli_fetch_array($resultcheck);
              $regid = $rowcheck['id'];

              $sqla = "SELECT * FROM attempts WHERE cuid='$regid'";
              $resulta = mysqli_query($conn,$sqla);

              if(mysqli_num_rows($resulta)>0){
                $rowa = mysqli_fetch_array($resulta);
                $noa = $rowa['noa'];
                $noa1 = $noa + 1;

                $sqla2 = "UPDATE attempts SET noa='$noa1' WHERE cuid='$regid'";
                $resulta2 = mysqli_query($conn,$sqla2);

                if($noa1>3){
                  echo "<script>
                          Swal.fire({
                                      title: 'Failed To Login',
                                      text: 'Login attempts exceeded maximum, visit our nearest offices and get help.',
                                      icon: 'error',
                                      confirmButtonText: 'OK',
                                          }).then((result) => {
                                      if (result.isConfirmed) {

                                          window.location.href='customer.php';
                                      }
                                  })
                         </script>";
                }
                else{

                echo "<script>
                        Swal.fire({
                                    title: 'Failed To Login',
                                    text: 'Wrong username and/or password, $noa1/3 attempts',
                                    icon: 'error',
                                    confirmButtonText: 'OK',
                                        }).then((result) => {
                                    if (result.isConfirmed) {

                                        window.location.href='customer.php';
                                    }
                                })
                       </script>";
                     }
              }
              else {
                $sqli = "INSERT INTO attempts(cuid,noa) VALUES('$regid','1')";
                $resulti = mysqli_query($conn,$sqli);

                echo "<script>
                        Swal.fire({
                                    title: 'Failed To Login',
                                    text: 'Wrong username and/or password, 1/3 attempts',
                                    icon: 'error',
                                    confirmButtonText: 'OK',
                                        }).then((result) => {
                                    if (result.isConfirmed) {

                                        window.location.href='customer.php';
                                    }
                                })
                       </script>";
              }

            }
            else {

              echo "<script>
                      Swal.fire({
                                  title: 'Failed To Login',
                                  text: 'Wrong username and/or password',
                                  icon: 'error',
                                  confirmButtonText: 'OK',
                                      }).then((result) => {
                                  if (result.isConfirmed) {

                                      window.location.href='customer.php';
                                  }
                              })
                     </script>";
            }


      }
    }

?>

<?php

  if(isset($_SESSION['choice'])){
    $choice = $_SESSION['choice'];
    $part = 1;
    $part2 = 2;
    $part3 = 3;

    if($choice == $part){
      if(isset($_SESSION['send'])){
          echo $_SESSION['send'];
        }
    }
    elseif($choice == $part2){
      if(isset($_SESSION['withdraw'])){
        echo $_SESSION['withdraw'];
      }
    }
    elseif($choice == $part3){
      if(isset($_SESSION['buy'])){
        echo $_SESSION['buy'];
      }
    }
}

?>

<?php

  if (isset($_POST['logout'])) {
    echo "
      <script>
            Swal.fire({
                   title: 'LOGOUT',
                   text: 'Proceed to logout now?',
                   icon: 'warning',
                   showCancelButton: true,
                   confirmButtonText: 'Yes',
                   cancelButtonText: 'No',
                       }).then((result) => {
                   if (result.isConfirmed) {
                        window.location.href='logout.php';
                   }
               })
               </script>

    ";
  }

?>
