<?php

  include "conn.php";

?>

<!doctype html>
<html>
<head>
  <meta charset=utf-8>
  <title>customer - security</title>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <link href="fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="ext/css/bootstrap.min.css" rel="stylesheet">

  <script src="sa/sweetalert2.min.js"></script>
  <link rel="stylesheet" href="sa/sweetalert2.min.css">
  <script src="ext/jquery-3.6.0.min.js"></script>

  <style media="screen">
    .center{
      margin: auto;
    }
    .title{
      font-size: 40px;
    }
    .color1{
        background-color: #1ABB81;
    }
    .color2{
        background-color: #C54A3B;
    }
    .autoi{
        margin: auto;
    }
    .new1{
        color:#1ABB81;
        text-decoration: none;
    }
    .new1:hover{
        text-decoration:none;

    }
    .new1:active{
        color: orange;
        text-decoration:none;

    }
    .hoverc:hover{
        transform:scale(1.1);
    }
    *{
      transition:0.5s;
    }
    body{
      background-color: #519285;
    }
    .h20{
      text-align: center;
      color: white;
    }
    .floatl{
      float: left;
    }
    .floatr{
      float: right;
    }
    .clear{
      clear: both;
    }
  </style>

</head>
<body>

  <br>

    <?php

    session_start();

    if (isset($_SESSION['userida'])) {

      $userid = $_SESSION['userida'];

      $sql = "SELECT * FROM users WHERE id = '$userid'";
      $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_array($result);
          $fname = $row['fname'];
          $lname = $row['lname'];

        echo"<form method='post' action='security.php' class='floatr'>

          <div class='row'>
            <div class='col-12 alignx'>
                <i class='text-white'>$fname $lname</i> &nbsp;&nbsp;&nbsp;
                <button class='btn btn-warning' type='submit' name='logout'>Logout</button>&nbsp;&nbsp;&nbsp;
            </div>
          </div>

        </form>


        <br><br>

        <hr class='clear'>

        ";

      }
    ?>

  <h2 class="h20"><b>SANKO MOBILE BANKING SERVICES</b></h2>

<br><br>

<div class="row">
  <div class="col-xl-3 col-md-6 mb-4 center">
     <div class="card shadow h-100 py-2 hoverc">
         <div class="card-body">
             <div class="row no-gutters align-items-center">
                 <div class="col mr-2">
                     <div class="text-md font-weight-bold text-success text-uppercase mb-1">
                        <form action="security.php" method="post">
                          <input type="submit" name="pwd" value="Change Password" class="btn btn-success">
                        </form>
                      </div>
                 </div>
                 <div class="col-auto">
                     <i class="fas fa-lock fa-2x text-success"></i>
                 </div>
             </div>
         </div>
     </div>
   </div>
 </div>

 <div class="row">

    <div class="col-xl-3 col-md-6 mb-4 center">
        <div class="card shadow h-100 py-2 hoverc">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-md font-weight-bold text-success text-uppercase mb-1">
                          <form action="security.php" method="post">
                            <input type="submit" name="secq" value="Security Questions" class="btn btn-success">
                          </form>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-question fa-2x text-success"></i>
                    </div>
                </div>
            </div>
        </div>
 </div>

</div>

</div>

</body>
</html>

<?php

  if(isset($_POST['pwd'])){

        echo "<br><form action='security.php' method='post'>

          <div class='row'>
            <div class='col-12'>
              <div class='text-white col-6 autoi text-center'>

                <span class='fa fa-user fa-4x hoverc'></span>
                <h2><i>change password</i></h2>
                <br>
                <p><i>New Password &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </i><input type='password' name='pwd1' required></p>
                <p><i>Retype New Password </i><input type='password' name='pwd2' required></p>
                <button type='submit' class='btn btn-success' name='cpwd'><i>Change</i></button>
              </div>
            </div>
          </div>

        </form>

        <br><br><br>

        ";
      }
?>


<?php

  if(isset($_POST['secq'])){

        echo "<br><form action='security.php' method='post'>

          <div class='row'>
            <div class='col-12'>
              <div class='text-white col-6 autoi text-center'>

                <span class='fa fa-user fa-4x hoverc'></span>
                <h2><i>security questions</i></h2>
                <br>
                <p><select name='sq1'>
                  <option value='Which city were you born in?'>Which city were you born in?</option>
                  <option value='What was your first pets name?'>What was your first pet's name?</option>
                  <option value='Your mother's maiden name is?'>Your mother's maiden name is?</option>
                  <option value='What is your favourite color?'>What is your favourite color?</option>
                  <option value='Your childhood nickname was?'>Your childhood nickname was?</option>
                </select>&nbsp;&nbsp;<input type='text' size='15' name='sa1' required></p>
                <p><select name='sq2'>
                  <option value='Which city were you born in?'>Which city were you born in?</option>
                  <option value='What was your first pets name?'>What was your first pet's name?</option>
                  <option value='Your mother's maiden name is?'>Your mother's maiden name is?</option>
                  <option value='What is your favourite color?'>What is your favourite color?</option>
                  <option value='Your childhood nickname was?'>Your childhood nickname was?</option>
                </select>&nbsp;&nbsp;<input type='text' size='15' name='sa2' required></p>
                <p><select name='sq3'>
                  <option value='Which city were you born in?'>Which city were you born in?</option>
                  <option value='What was your first pets name?'>What was your first pet's name?</option>
                  <option value='Your mother's maiden name is?'>Your mother's maiden name is?</option>
                  <option value='What is your favourite color?'>What is your favourite color?</option>
                  <option value='Your childhood nickname was?'>Your childhood nickname was?</option>
                </select>&nbsp;&nbsp;<input type='text' size='15' name='sa3' required></p>
                <button type='submit' class='btn btn-success' name='sqs'><i>Submit</i></button>
              </div>
            </div>
          </div>

        </form>

        <br><br><br>

        ";
      }
?>


<?php

  if(isset($_POST['cpwd'])){
    $newp = $_POST['pwd1'];
    $newp2 = $_POST['pwd2'];

    if($newp != $newp2){
      echo "<script>
              Swal.fire({
                          title: 'Change password',
                          text: 'Passwords do not match',
                          icon: 'warning',
                          confirmButtonText: 'OK',
                              }).then((result) => {
                          if (result.isConfirmed) {

                              window.location.href='security.php';
                          }
                      })
             </script>";
    }
    else {

      $uzid = $_SESSION['userida'];

      $encpwd = sha1($newp);

      $sql1 = "UPDATE users SET pcode = '$encpwd' WHERE id='$uzid'";
      $result1 = mysqli_query($conn,$sql1);

          if($result1){
            echo "<script>
                    Swal.fire({
                                title: 'change password',
                                text: 'Password changed successfully',
                                icon: 'success',
                                confirmButtonText: 'OK',
                                    }).then((result) => {
                                if (result.isConfirmed) {

                                    window.location.href='security.php';
                                }
                            })
                   </script>";
          }
      }
  }

?>

<?php

  if(isset($_POST['sqs'])){
    $sq1 = $_POST['sq1'];
    $sa1 = $_POST['sa1'];

    $sq2 = $_POST['sq2'];
    $sa2 = $_POST['sa2'];

    $sq3 = $_POST['sq3'];
    $sa3 = $_POST['sa3'];

    $uxid = $_SESSION['userida'];

    $sqlsq = "INSERT INTO security (cuid,sq,sa) VALUES ('$uxid','$sq1','$sa1'),('$uxid','$sq2','$sa2'),('$uxid','$sq3','$sa3')";
    $resultsq = mysqli_query($conn,$sqlsq);

    if($resultsq){
      echo "<script>
              Swal.fire({
                          title: 'security questions',
                          text: 'Security questions registered successfully',
                          icon: 'success',
                          confirmButtonText: 'OK',
                              }).then((result) => {
                          if (result.isConfirmed) {

                              window.location.href='customer.php';
                          }
                      })
             </script>";
    }
    else {
      echo "<script>
              Swal.fire({
                          title: 'security questions',
                          text: 'Security questions failed to be registered',
                          icon: 'warning',
                          confirmButtonText: 'OK',
                              }).then((result) => {
                          if (result.isConfirmed) {

                              window.location.href='security.php';
                          }
                      })
             </script>";
    }

  }

?>

<?php

  if (isset($_POST['logout'])) {
    echo "
      <script>
            Swal.fire({
                   title: 'LOGOUT',
                   text: 'Proceed to logout now?',
                   icon: 'warning',
                   showCancelButton: true,
                   confirmButtonText: 'Yes',
                   cancelButtonText: 'No',
                       }).then((result) => {
                   if (result.isConfirmed) {
                        window.location.href='logout.php';
                   }
               })
               </script>

    ";
  }

?>
