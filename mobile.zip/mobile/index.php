<!doctype html>
<html>
<head>
  <meta charset=utf-8>
  <title>SMBS</title>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <link href="fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="ext/css/bootstrap.min.css" rel="stylesheet">

  <script src="sa/sweetalert2.min.js"></script>
  <link rel="stylesheet" href="sa/sweetalert2.min.css">
  <script src="ext/jquery-3.6.0.min.js"></script>

  <style media="screen">
    .center{
      margin: auto;
    }
    .title{
      font-size: 40px;
    }
    .color1{
        background-color: #1ABB81;
    }
    .color2{
        background-color: #C54A3B;
    }
    .autoi{
        margin: auto;
    }
    .new1{
        color:#1ABB81;
        text-decoration: none;
    }
    .new1:hover{
        text-decoration:none;

    }
    .new1:active{
        color: orange;
        text-decoration:none;

    }
    .hoverc:hover{
        transform:scale(1.1);
    }
    *{
      transition:0.5s;
    }
    body{
      background-color: #519285;
    }
    .h20{
      text-align: center;
      color: white;
    }
  </style>

</head>
<body>

<br><br>

  <h2 class="h20"><b>SANKO MOBILE BANKING SERVICES</b></h2>

<br><br><br>

<div class="row">
  <div class="col-xl-3 col-md-6 mb-4 center">
     <div class="card shadow h-100 py-2 hoverc">
         <div class="card-body">
             <div class="row no-gutters align-items-center">
                 <div class="col mr-2">
                     <div class="text-md font-weight-bold text-success text-uppercase mb-1">
                        <form action="index.php" method="post">
                          <input type="submit" name="agent" value="AGENT" class="btn btn-success">
                        </form>
                      </div>
                 </div>
                 <div class="col-auto">
                     <i class="fas fa-user fa-2x text-success"></i>
                 </div>
             </div>
         </div>
     </div>
   </div>
 </div>

 <div class="row">

    <div class="col-xl-3 col-md-6 mb-4 center">
        <div class="card shadow h-100 py-2 hoverc">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-md font-weight-bold text-success text-uppercase mb-1">
                          <form action="index.php" method="post">
                            <input type="submit" name="customer" value="CUSTOMER" class="btn btn-success">
                          </form>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-user-friends fa-2x text-success"></i>
                    </div>
                </div>
            </div>
        </div>
 </div>

</div>

<div class="row">

   <div class="col-xl-3 col-md-6 mb-4 center">
       <div class="card shadow h-100 py-2 hoverc">
           <div class="card-body">
               <div class="row no-gutters align-items-center">
                   <div class="col mr-2">
                       <div class="text-md font-weight-bold text-success text-uppercase mb-1">
                         <form action="index.php" method="post">
                           <input type="submit" name="admin" value="SYSTEM ADMIN" class="btn btn-success">
                         </form>
                       </div>
                   </div>
                   <div class="col-auto">
                       <i class="fas fa-user-tie fa-2x text-success"></i>
                   </div>
               </div>
           </div>
       </div>
</div>

</div>

</div>

</body>
</html>

<?php

  if(isset($_POST['agent'])){
      header("Location: agent.php");
  }

  if(isset($_POST['admin'])){
    header("Location: admin.php");
  }
  if(isset($_POST['customer'])){
    header("Location: customer.php");
  }

?>
