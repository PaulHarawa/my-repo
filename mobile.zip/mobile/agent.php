<?php

  include "conn.php";

?>

<!doctype html>
<html>
<head>
  <meta charset=utf-8>
  <title>agent</title>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <link href="fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="ext/css/bootstrap.min.css" rel="stylesheet">

  <script src="sa/sweetalert2.min.js"></script>
  <link rel="stylesheet" href="sa/sweetalert2.min.css">
  <script src="ext/jquery-3.6.0.min.js"></script>

  <style media="screen">
    .center{
      margin: auto;
    }
    .title{
      font-size: 40px;
    }
    .color1{
        background-color: #1ABB81;
    }
    .color2{
        background-color: #C54A3B;
    }
    .autoi{
        margin: auto;
    }
    .new1{
        color:#1ABB81;
        text-decoration: none;
    }
    .new1:hover{
        text-decoration:none;

    }
    .new1:active{
        color: orange;
        text-decoration:none;

    }
    .hoverc:hover{
        transform:scale(1.1);
    }
    *{
      transition:0.5s;
    }
    body{
      background-color: #519285;
    }
    .h20{
      text-align: center;
      color: white;
    }
    .floatl{
      float: left;
    }
    .floatr{
      float: right;
    }
    .clear{
      clear: both;
    }
  </style>

</head>
<body>

  <br>

    <?php

    session_start();

    if (isset($_SESSION['userida'])) {

      $userid = $_SESSION['userida'];

      $sql = "SELECT * FROM agents WHERE id = '$userid'";
      $result = mysqli_query($conn, $sql);
        $row = mysqli_fetch_array($result);
          $fname = $row['fname'];
          $lname = $row['lname'];

        echo"<form method='post' action='agent.php' class='floatr'>

          <div class='row'>
            <div class='col-12 alignx'>
                <i class='text-white'>$fname $lname</i> &nbsp;&nbsp;&nbsp;
                <button class='btn btn-warning' type='submit' name='logout'>Logout</button>&nbsp;&nbsp;&nbsp;
            </div>
          </div>

        </form>


        <br><br>

        <hr class='clear'>

        ";

      }
    ?>

  <h2 class="h20"><b>SANKO MOBILE BANKING SERVICES</b></h2>

<br><br>

<div class="row">
  <div class="col-xl-3 col-md-6 mb-4 center">
     <div class="card shadow h-100 py-2 hoverc">
         <div class="card-body">
             <div class="row no-gutters align-items-center">
                 <div class="col mr-2">
                     <div class="text-md font-weight-bold text-success text-uppercase mb-1">
                        <form action="agent.php" method="post">
                          <input type="submit" name="register" value="Register" class="btn btn-success">
                        </form>
                      </div>
                 </div>
                 <div class="col-auto">
                     <i class="fas fa-user-plus fa-2x text-success"></i>
                 </div>
             </div>
         </div>
     </div>
   </div>
 </div>

 <div class="row">

    <div class="col-xl-3 col-md-6 mb-4 center">
        <div class="card shadow h-100 py-2 hoverc">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-md font-weight-bold text-success text-uppercase mb-1">
                          <form action="agent.php" method="post">
                            <input type="submit" name="deposit" value="Deposit" class="btn btn-success">
                          </form>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-money-bill-wave fa-2x text-success"></i>
                    </div>
                </div>
            </div>
        </div>
 </div>

</div>

</div>

</body>
</html>

<?php

  if(isset($_POST['register'])){

      if(isset($_SESSION['userida'])){
          echo "<script>window.location.href='adduser.php';</script>";
      }
      else {

      echo "<br><form action='agent.php' method='post'>

        <div class='row'>
          <div class='col-12'>
            <div class='text-white col-6 autoi text-center'>

              <span class='fa fa-user-circle fa-4x hoverc'></span>
              <h2><i>Sign in</i></h2>
              <br>
              <p><i>Agent Code </i><input type='text' name='acode' required></p>
              <p><i>Agent Pin &nbsp;&nbsp;&nbsp;</i><input type='password' name='apin' required></p>
              <button type='submit' class='btn btn-success' name='login'><i>login</i></button>
            </div>
          </div>
        </div>

      </form>

      <br><br><br>

      ";
    }
  }

?>

<?php

  if(isset($_POST['deposit'])){

    if(isset($_SESSION['userida'])){
        echo "<br><form action='agent.php' method='post'>

          <div class='row'>
            <div class='col-12'>
              <div class='text-white col-6 autoi text-center'>

                <span class='fa fa-money-bill fa-4x hoverc'></span>
                <h2><i>deposit</i></h2>
                <br>
                <p><i>Phone Number </i><input type='text' name='pnumber' required></p>
                <p><i>Amount &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i><input type='text' name='amount' required></p>
                <button type='submit' class='btn btn-success' name='dep'><i>deposit</i></button>
              </div>
            </div>
          </div>

        </form>

        <br><br><br>

        ";
    }
    else {

    echo "<br><form action='agent.php' method='post'>

      <div class='row'>
        <div class='col-12'>
          <div class='text-white col-6 autoi text-center'>

            <span class='fa fa-user-circle fa-4x hoverc'></span>
            <h2><i>Sign in</i></h2>
            <br>
            <p><i>Agent Code </i><input type='text' name='acode' required></p>
            <p><i>Agent Pin &nbsp;&nbsp;&nbsp;</i><input type='password' name='apin' required></p>
            <button type='submit' class='btn btn-success' name='login1'><i>login</i></button>
          </div>
        </div>
      </div>

    </form>

    <br><br><br>

    ";
  }

  }

?>

<?php

    if(isset($_POST['login'])){
      $acode  = $_POST['acode'];
      $apin   = sha1($_POST['apin']);

      $sql = "SELECT * FROM agents WHERE acode='$acode' AND apin='$apin'";
      $result = mysqli_query($conn,$sql);

      if(mysqli_num_rows($result)>0){
        $row = mysqli_fetch_array($result);
          $id    = $row['id'];
          $fname = $row['fname'];
          $lname = $row['lname'];
          $acode = $row['acode'];

        $_SESSION['userida'] = $id;
        echo "<script>window.location.href='adduser.php';</script>";
        }

      else {
        echo "<script>
                Swal.fire({
                            title: 'Failed To Login',
                            text: 'Wrong username and/or password',
                            icon: 'error',
                            confirmButtonText: 'OK',
                                }).then((result) => {
                            if (result.isConfirmed) {

                                window.location.href='agent.php';
                            }
                        })
               </script>";
      }
    }

?>

<?php

    if(isset($_POST['login1'])){
      $acode  = $_POST['acode'];
      $apin   = sha1($_POST['apin']);

      $sql = "SELECT * FROM agents WHERE acode='$acode' AND apin='$apin'";
      $result = mysqli_query($conn,$sql);

      if(mysqli_num_rows($result)>0){
        $row = mysqli_fetch_array($result);
          $id    = $row['id'];
          $fname = $row['fname'];
          $lname = $row['lname'];
          $acode = $row['acode'];

        $_SESSION['userida'] = $id;
        echo "<br><form action='agent.php' method='post'>

          <div class='row'>
            <div class='col-12'>
              <div class='text-white col-6 autoi text-center'>

                <span class='fa fa-money-bill fa-4x hoverc'></span>
                <h2><i>deposit</i></h2>
                <br>
                <p><i>Phone Number </i><input type='text' name='pnumber1' required></p>
                <p><i>Amount &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i><input type='text' name='amount1' required></p>
                <button type='submit' class='btn btn-success' name='dep1'><i>deposit</i></button>
              </div>
            </div>
          </div>

        </form>

        <br><br><br>";
        }

      else {
        echo "<script>
                Swal.fire({
                            title: 'Failed To Login',
                            text: 'Wrong username and/or password',
                            icon: 'error',
                            confirmButtonText: 'OK',
                                }).then((result) => {
                            if (result.isConfirmed) {

                                window.location.href='agent.php';
                            }
                        })
               </script>";
      }
    }

?>
<?php

  if(isset($_POST['dep'])){
    $pnumber = $_POST['pnumber'];
    $amount = $_POST['amount'];
    $sql = "SELECT * FROM users WHERE pnumber='$pnumber'";
    $result = mysqli_query($conn,$sql);
      if(mysqli_num_rows($result) > 0){
          $row = mysqli_fetch_array($result);
            $uid = $row['id'];
            $balance = $row['balance'];

          $cid = $uid;
          $initial = $balance;
          $final = $initial + $amount;
          $date = date("y-m-d");

          $agent = $_SESSION['userida'];

          $sql1 = "UPDATE users SET balance='$final' WHERE id='$cid'";
          $result1 = mysqli_query($conn,$sql1);

          $sql2 = "INSERT INTO trans(cid,initial,final,date,agent) VALUES('$cid','$initial','$final','$date','$agent')";
          $result2 = mysqli_query($conn,$sql2);

          if($result2){
            echo "<script>
                    Swal.fire({
                                title: 'Deposit',
                                text: 'Deposit was successfull',
                                icon: 'success',
                                confirmButtonText: 'OK',
                                    }).then((result) => {
                                if (result.isConfirmed) {

                                    window.location.href='agent.php';
                                }
                            })
                   </script>";
          }
      }
      else {
        echo "<script>
                Swal.fire({
                            title: 'Deposit',
                            text: 'Failed to deposit',
                            icon: 'error',
                            confirmButtonText: 'OK',
                                }).then((result) => {
                            if (result.isConfirmed) {

                                window.location.href='agent.php';
                            }
                        })
               </script>";
      }

  }

?>

<?php

  if(isset($_POST['dep1'])){
    $pnumber = $_POST['pnumber1'];
    $amount = $_POST['amount1'];
    $sql = "SELECT * FROM users WHERE pnumber='$pnumber'";
    $result = mysqli_query($conn,$sql);
      if(mysqli_num_rows($result) > 0){
          $row = mysqli_fetch_array($result);
            $uid = $row['id'];
            $balance = $row['balance'];

          $cid = $uid;
          $initial = $balance;
          $final = $initial + $amount;
          $date = date("y-m-d");

          $agent = $_SESSION['userida'];

          $sql1 = "UPDATE users SET balance='$final' WHERE id='$cid'";
          $result1 = mysqli_query($conn,$sql1);

          $sql2 = "INSERT INTO trans(cid,initial,final,date,agent) VALUES('$cid','$initial','$final','$date','$agent')";
          $result2 = mysqli_query($conn,$sql2);

          if($result2){
            echo "<script>
                    Swal.fire({
                                title: 'Deposit',
                                text: 'Deposit was successfull',
                                icon: 'success',
                                confirmButtonText: 'OK',
                                    }).then((result) => {
                                if (result.isConfirmed) {

                                    window.location.href='agent.php';
                                }
                            })
                   </script>";
          }
      }
      else {
        echo "<script>
                Swal.fire({
                            title: 'Deposit',
                            text: 'Failed to deposit',
                            icon: 'error',
                            confirmButtonText: 'OK',
                                }).then((result) => {
                            if (result.isConfirmed) {

                                window.location.href='agent.php';
                            }
                        })
               </script>";
      }

  }

?>

<?php

  if (isset($_POST['logout'])) {
    echo "
      <script>
            Swal.fire({
                   title: 'LOGOUT',
                   text: 'Proceed to logout now?',
                   icon: 'warning',
                   showCancelButton: true,
                   confirmButtonText: 'Yes',
                   cancelButtonText: 'No',
                       }).then((result) => {
                   if (result.isConfirmed) {
                        window.location.href='logout.php';
                   }
               })
               </script>

    ";
  }

?>
