-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 11, 2022 at 10:08 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aspire`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(2, 'AspireLtd', '97939c18032b7d37150c3e6015001ef81ffa9151');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `phone` varchar(200) NOT NULL,
  `subject` varchar(700) NOT NULL,
  `message` varchar(3000) NOT NULL,
  `date` varchar(200) NOT NULL,
  `time` varchar(200) NOT NULL,
  `status` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `name`, `email`, `phone`, `subject`, `message`, `date`, `time`, `status`) VALUES
(11, 'Pabo', 'pabloharawa@gmail.com', '0999358339', 'Need consultancy', 'Pablo', '22-01-10', '08:48', 1),
(12, 'Harawa', 'pabloharawa@gmail.com', '0999358339', 'Need consultancy Exmple', 'Endline evaluation of the Mainstreaming Disability in Nutrition and Food Security Project in TA Champiti, Ntcheu District. Prepared End of Evaluation Report for the Hunger Project.', '22-01-10', '08:49', 0),
(13, 'pabloharawa@gmail.com', 'pabloharawa@gmail.com', '0999358339', 'What Up Gangsta', 'hhhh', '22-01-10', '08:53', 0);

-- --------------------------------------------------------

--
-- Table structure for table `inpictures`
--

CREATE TABLE `inpictures` (
  `id` int(200) NOT NULL,
  `caption` varchar(1000) NOT NULL,
  `image` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `inpictures`
--

INSERT INTO `inpictures` (`id`, `caption`, `image`) VALUES
(46, 'Endline evaluation of the Mainstreaming Disability in Nutrition and Food Security Project in TA Champiti, Ntcheu District', 'IMG-20220108-WA0005.jpg'),
(47, 'Impact Assessment of the Malawi Emergency Floods Recovery Project Input for Assets Public Works Program (PWP)', 'IMG-20220108-WA0001.jpg'),
(48, 'End-line Evaluation of the Malawi Lake Basin Program', 'IMG-20220108-WA0008.jpg'),
(49, 'Value for Money Assessment for the CARE International-Malawi Women Empowerment Project', 'IMG-20220108-WA0003.jpg'),
(50, 'Value for Money Assessment for the CARE International-Malawi Women Empowerment Project', 'IMG-20220108-WA0009.jpg'),
(51, 'Outcomes Survey of the Accelerated Sanitation and Hygiene (ASH) Project', 'IMG-20220108-WA0004.jpg'),
(52, 'A qualitative assessment of the Trade & Information Desks on Women Cross-border traders', 'IMG-20220108-WA0006.jpg'),
(53, 'A qualitative assessment of the Trade & Information Desks on Women Cross-border traders', 'IMG-20220108-WA0002.jpg'),
(54, 'A qualitative assessment of the Trade & Information Desks on Women Cross-border traders', 'IMG-20220108-WA0003.jpg'),
(55, 'A qualitative assessment of the Trade & Information Desks on Women Cross-border traders', 'IMG-20220108-WA0005.jpg'),
(56, 'A qualitative assessment of the Trade & Information Desks on Women Cross-border traders', 'IMG-20220108-WA0008.jpg'),
(57, 'Outcomes Survey of the Accelerated Sanitation and Hygiene (ASH) Project', 'IMG-20220108-WA0002.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` int(200) NOT NULL,
  `title` varchar(500) NOT NULL,
  `client` varchar(200) NOT NULL,
  `duration` varchar(200) NOT NULL,
  `staff` varchar(1000) NOT NULL,
  `image` varchar(500) NOT NULL,
  `image1` varchar(500) NOT NULL,
  `image2` varchar(500) NOT NULL,
  `description` varchar(5000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `title`, `client`, `duration`, `staff`, `image`, `image1`, `image2`, `description`) VALUES
(41, 'Annual Outcomes Survey of the Microloan Foundation Programmes in Kasungu, Ntchisi Districts', 'Microloan Foundation, Kasungu, Malawi', '2008 - 2012', 'Murphy Kajumi; Isaac Mambo (PhD)', 'IMG-20220108-WA0000.jpg', 'IMG-20220108-WA0000.jpg', 'IMG-20220108-WA0000.jpg', 'Annual Outcomes Survey of the Microloan Foundation Programmes in Kasungu, Ntchisi Districts'),
(42, 'A qualitative assessment of the Trade & Information Desks on Women Cross-border traders', 'Common Market for Southern and Eastern Africa, Lusaka, Zambia', 'August - October, 2013', 'Murphy Kajumi - Evaluator; Cliff Phiri - Gender Expert', 'IMG-20220108-WA0001.jpg', 'IMG-20220108-WA0001.jpg', 'IMG-20220108-WA0001.jpg', 'A qualitative assessment of the Trade & Information Desks on Women Cross-border traders. Assignment outputs: methodology for carrying out assignment, inception report, end of term evaluation report'),
(43, 'End of Term Evaluation for the Farmers Club Project', 'Development AID from People to People (DAPP)', 'December 2013 - January 2014', 'Murphy Kajumi - Team Leader; Hastings Chiwasa - Field Operations Coordinator', 'IMG-20220108-WA0002.jpg', 'IMG-20220108-WA0002.jpg', 'IMG-20220108-WA0002.jpg', 'End of Term Evaluation for the Farmers Club Project. Assignment outputs: methodology for carrying out assignment, inception report, prepared end of term evaluation report'),
(44, 'Outcomes Survey of the Accelerated Sanitation and Hygiene (ASH) Project', 'Plan International - Malawi, Malawi', 'October 2013 - January 2014', 'Murphy Kajumi - Team Leader; Moses Chikowi - M&E Expert; Michael Chimaliza - Sanitation Expert', 'IMG-20220108-WA0003.jpg', 'IMG-20220108-WA0003.jpg', 'IMG-20220108-WA0003.jpg', 'Outcomes Survey of the Accelerated Sanitation and Hygiene (ASH) Project. outcomes survey for the ASH Project. Assignment outputs: methodology for carrying out assignment, inception report, end of term evaluation report'),
(45, 'Willingness to Pay  Study for the Lilongwe Water Board customers', 'Economics Consultancy Associates/TM Associates', 'May - July 2014', 'Murphy Kajumi - Socio-Economist; Hector Malaidza - Data Management Expert', 'IMG-20220108-WA0004.jpg', 'IMG-20220108-WA0004.jpg', 'IMG-20220108-WA0004.jpg', 'Willingness to Pay  Study for the Lilongwe Water Board customers, including customer satisfaction assessment. Assignment outputs: methodology for carrying out assignment, inception report, Prepared socio-economic survey report of the Willingness to Pay Survey '),
(47, 'Value for Money Assessment for the CARE International-Malawi Women Empowerment Project', 'CARE International-Malawi, Malawi', 'January - March, 2016', 'Murphy Kajumi-Team Leader Isaac Mambo (PhD)-Livelihoods Expert', 'IMG-20220108-WA0006.jpg', 'IMG-20220108-WA0006.jpg', 'IMG-20220108-WA0006.jpg', 'Value for Money Assessment for the CARE International-Malawi Women Empowerment Project. Main deliverables were methodology for the assignment, an inception report and final report of the value for money assessment for the Project. Assignment outputs: methodology for carrying out assignment, inception report, preparation of end of term evaluation report'),
(48, 'End-line Evaluation of the Malawi Lake Basin Program', 'We-Effect Malawi, Malawi', 'March 31 - May 30, 2019', 'Murphy Kajumi - Team Leader; James Chima - Institutional Development Expert; Kenneth Matekenya - Agriculture Systems and Food Security Expert; Wezi Moyo - Gender Expert; Griffin Zgambo - Financial Inclusion Expert', 'IMG-20220108-WA0008.jpg', 'IMG-20220108-WA0008.jpg', 'IMG-20220108-WA0008.jpg', 'End-line Evaluation of the Malawi Lake Basin Program. Prepared the End-line Evaluation Report of the Malawi Lake Basin Program'),
(49, 'Impact Assessment of the Malawi Emergency Floods Recovery Project Input for Assets Public Works Program (PWP)', 'Ministry of Economic Planning and Development, Malawi', 'June 20 - September, 2019', 'Murphy Kajumi - Team Leade;, Prisca Kutengule - Gender and Social Safeguards Expert; Vincent Msadala (PhD) - Infrastructure Engineer;  Thokozani Sambakunsi - Statistician & Informatics Expert', 'IMG-20220108-WA0009.jpg', 'IMG-20220108-WA0009.jpg', 'IMG-20220108-WA0009.jpg', 'Impact Assessment of the Malawi Emergency Floods Recovery Project Input for Assets Public Works Program (PWP). Prepared the Impact Assessment Report of the Malawi Floods Emergency Recovery Project.'),
(50, 'Endline evaluation of the Mainstreaming Disability in Nutrition and Food Security Project', 'The Hunger Project, Malawi', 'December 6, 2019 - January 30, 2020', 'Murphy Kajumi - Team Leader; David Mtekateka - Agriculture Specialist; Lwana Kamanga - Social Scientist', 'IMG-20220108-WA0000.jpg', 'IMG-20220108-WA0001.jpg', 'IMG-20220108-WA0004.jpg', 'Endline evaluation of the Mainstreaming Disability in Nutrition and Food Security Project in TA Champiti, Ntcheu District. Prepared End of Evaluation Report for the Hunger Project.'),
(52, 'Baseline Study for the Microventures Project', 'Microventures Project, Kasungu', 'July - August 2015', 'Murphy Kajumi - Team Leader', 'IMG-20220108-WA0005.jpg', 'IMG-20220108-WA0005.jpg', 'IMG-20220108-WA0005.jpg', 'Baseline Study for the Microventures Project');

-- --------------------------------------------------------

--
-- Table structure for table `subscribers`
--

CREATE TABLE `subscribers` (
  `id` int(200) NOT NULL,
  `date` varchar(200) NOT NULL,
  `email` varchar(400) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subscribers`
--

INSERT INTO `subscribers` (`id`, `date`, `email`) VALUES
(9, '22-01-10', 'pabloharawa@gmail.com'),
(10, '22-01-10', 'cyberqave1999@gmail.com'),
(11, '22-01-10', 'cis-002-17@must.ac.mw');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inpictures`
--
ALTER TABLE `inpictures`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscribers`
--
ALTER TABLE `subscribers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `inpictures`
--
ALTER TABLE `inpictures`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `subscribers`
--
ALTER TABLE `subscribers`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
