<?php

        include "conn.php";

        session_start();
        $pjid = $_SESSION['pjid'];

        $sql = "DELETE FROM projects WHERE id='$pjid'";
        $result = mysqli_query($conn,$sql);

        header("Location: adminProjects.php");

 ?>
