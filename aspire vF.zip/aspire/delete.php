<?php

        include "conn.php";

        session_start();
        $imgid = $_SESSION['imgid'];

        $sql = "DELETE FROM inpictures WHERE id='$imgid'";
        $result = mysqli_query($conn,$sql);

        header("Location: adminPictures.php");

 ?>
