<?php 

  include "conn.php";

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Aspire Ltd.</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="icon.png" rel="icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Jost:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/carousel.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/css/projects.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <script src="assets/vendor/Sweetalert/dist/sweetalert2.min.js"></script>
  <link rel="stylesheet" href="assets/vendor/Sweetalert/dist/sweetalert2.min.css">

  <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  <link href="assets/css/newstyle.css" rel="stylesheet">

  <style type="text/css">
    .bg-dark-all{
      background-color: #E9F6F1;
    }
    .bg-dark-all-x{
      background-color: #263754;
    }
    #footer .bg-dark-all-xy{
      background-color: #263754;
      color: rgb(195, 195, 195);
    }
    .bg-dark-all-1{
      background-color: #003B00;
    }
    .bg-dark-all-two{
      background-color: #BEE1BD;
    }
    .bg-dark-all-three{
      background-color: rgba(0, 0, 0, 0.7);
    }
    .font-family-all{
      font-family: verdana;
    }
    .font-family-new{
      font-family: monospace;
    }
    .img-all{
      width: 100%;
      height: 300px;
      border-radius: 10px;
      opacity: 0.8;
    }
    .caption-all{
      background-color: rgb(40, 58, 90, 0.9);
      font-style: italic;
      margin: 0 auto 15px auto;
      position: absolute;
      bottom: 2%;
      width: 100%;
      z-index: 3;
    }
    .bg-green{
      background-color: lightgreen;
    }
    .bg-green-xx{
      background: linear-gradient(rgb(38, 55, 84), rgb(0, 59, 0));
    }
    #header .logo a {
      color: rgb(144, 205, 79);
    }

    #why-us .animation {
     animation: up-down 2s ease-in-out infinite alternate-reverse both;
    }
    .services .bg-green-all {
      background-color: lightblue;
    }
    .cta .text-warning-all{
      color: #47b2e4;
    }
    #portfolio {
      background-color: #A7F1A7;
      background-size: cover;
      color: black;
    }
    .border-all{
      border: 2px solid #47b2e4;
    }
    .list-all li{
      letter-spacing: 1px;
      word-spacing: 1px;
      font-size: 18px;
      padding-bottom: 20px;
    }
    .try-c{
      font-family: cursive;
    }
    .border-none{
      background-color: rgb(55, 81, 126);
      border: 2px solid rgb(55, 81, 126);
    }
    #hero {
      background: lightblue;
    }
    .text-123{
      color: rgb(195, 195, 195);
    }
    .abt-us{
      color: rgb(195, 195, 195);
    }
    .section-title1 h2 {
      font-size: 32px;
      font-weight: bold;
      text-transform: uppercase;
      margin-bottom: 20px;
      padding-bottom: 20px;
      position: relative;
      color: #319AC4;
    }
    .section-title1 h2::after {
      content: "";
      position: absolute;
      display: block;
      width: 40px;
      height: 3px;
      background: #319AC4;
      bottom: 0;
      left: calc(50% - 20px);
    }
    .section-title2 h2::before {
      content: "";
      position: absolute;
      display: block;
      width: 120px;
      height: 1px;
      background: #ddd;
      bottom: 1px;
      left: calc(50% - 60px);
    }
    .section-title2 h2::after {
      content: "";
      position: absolute;
      display: block;
      width: 40px;
      height: 3px;
      background: #37517E;
      bottom: 0;
      left: calc(50% - 20px);
    }
    .section-title3 h2 {
      font-size: 32px;
      font-weight: bold;
      text-transform: uppercase;
      margin-bottom: 20px;
      padding-bottom: 20px;
      position: relative;
      color: #319AC4;
    }
    .section-title6 h2::after {
      content: "";
      position: absolute;
      display: block;
      width: 40px;
      height: 3px;
      background: #37517E;
      bottom: 0;
      left: calc(50% - 20px);
    }

    .img-all-1{
      height: 270px;
    }
    .bg-new-all{
      background-color: lightblue;
    }
    #header {
      background: rgb(40, 58, 90);
    }
    #why-us .new-white{
      color: rgb(195, 195, 195);
    }
    #team .bg-last{
      background-color: rgb(245, 245, 245);
    }
    #footer .footer-newsletter h4 {
      color: #319AC4;
    }
    .dimenxion{
      background-color: #37517E;
      font-style: italic;
    }
    .small-text{
      font-size: 14px;
    }
  </style>

  <!-- =======================================================
  * Template Name: Arsha - v4.7.0
  * Template URL: https://bootstrapmade.com/arsha-free-bootstrap-html-template-corporate/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top ">
    <div class="container d-flex align-items-center">
      <h1 class="logo me-auto"><a href="index.php"><strong>Aspire</strong></a></h1>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
          <li><a class="nav-link scrollto" href="#about">About</a></li>
          <li><a class="nav-link scrollto" href="#services">Services</a></li>
          <li><a class="nav-link scrollto" href="#portfolio">Portfolio</a></li>
          <li><a data-glightbox="type: external" class="portfolio-lightbox preview-link nav-link" href="pictures.php">In Pictures</a></li>       
          <li><a class="nav-link scrollto" href="#team">Team</a></li>
          <li><a class="nav-link scrollto" href="#contact">Contact Us</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">

    <div class="container">
      <div class="row">
        <div class="col-lg-6 d-flex flex-column justify-content-center pt-4 pt-lg-0 order-2 order-lg-1" data-aos="fade-up" data-aos-delay="200">
            
            <div class="testimonials-slider swiper col-12" data-aos="fade-up" data-aos-delay="100">
              <div class="swiper-wrapper">
                <?php

                      $sql = "SELECT * FROM inpictures ORDER BY id DESC";
                      $result = mysqli_query($conn,$sql);

                      $count = 1;

                      if(mysqli_num_rows($result)>0){

                      while($count<=5){
                        $row=mysqli_fetch_array($result);
                        $id = $row['id'];
                        $caption = $row['caption'];
                        $image = $row['image'];

                        echo"<div class='swiper-slide'>
                                <div class='testimonial-item'>
                                  <img src='inpictures/$image' class='testimonial-img img-all'><br>
                                  <p class='text-light caption-all font-family-all p-2 text-center text-lowercase'>$caption</p>
                                </div>
                              </div>";

                          $count++;
                      }}
                      else{

                      }

                      ?>
              </div>
            </div>
        </div>
        <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="zoom-in" data-aos-delay="200">
          <img src="logo.png" class="img-fluid animated" alt="">
        </div>
      </div>
    </div>

  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= About Us Section ======= -->
    <section id="about" class="about bg-dark-all-x font-family-all">
      <br>
      <div class="container" data-aos="fade-up">

        <div class="section-title section-title3">
          <h2>About Us</h2>
        </div>

        <div class="row content">
          <div class="col-lg-6 abt-us">
            <p class="text-uppercase h5"><b>who we are</b></p>
            <p>
              ASPIRE Consulting Associates Limited</span>is a young but fast growing consulting firm bringing together a range of skills and experience in development.<br>We are registered in Malawi (registration <span class="font-family-new">#1010699</span>, TPIN <span class="font-family-new">#31000293</span>) but have a continental foot print as  our staff have provided services in several countries in East, Southern and West Africa. <br><br><span class="h5 text-uppercase"><b>We have extensive experience in</b></span>
            </p>
            <ul>
              <li><i class="ri-check-double-line"></i> Project financing</li>
              <li><i class="ri-check-double-line"></i> Design and management of infrastructure projects</li>
              <li><i class="ri-check-double-line"></i> Feasibility studies</li>
              <li><i class="ri-check-double-line"></i> Implementation management</li>
              <li><i class="ri-check-double-line"></i> Conducting impact evaluations and performance evaluation</li>
              <li><i class="ri-check-double-line"></i> Database design and management</li>
              <li><i class="ri-check-double-line"></i> Feasibility studies</li>
              <li><i class="ri-check-double-line"></i> Geographic Information Systems and Remote Sensing</li>
            </ul>
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0">
            <p class="text-uppercase h5 abt-us"><b>research</b></p>
            <p class="abt-us">
              ASPIRE conducts research on the socio-economic aspects of public health and agriculture. <br>ASPIRE conceives and conducts innovative cross-disciplinary research to influence public  policy and practice in Malawi, with a particular emphasis on  research that informs public policy decision-making and implementation.
              <br><br><br>
              <span class="text-uppercase">We have provided technical assistance to development partners in Malawi and in the region</span>.
            </p>
            <a href="#portfolio" class="btn btn-primary scrollto">Check Our Portfolio</a>
          </div>
        </div>

      </div>
    </section><!-- End About Us Section -->

    <!-- ======= Why Us Section ======= -->
    <section id="why-us" class="why-us section-bg bg-green-xx">
      <div class="container-fluid" data-aos="fade-up">

        <div class="row">

          <div class="col-lg-7 d-flex flex-column justify-content-center align-items-stretch  order-1 mx-auto">

            <div class="content text-center">
              <h3 class="new-white">Why Choose <strong>ASPIRE?</strong></h3>
            </div>

            <div class="accordion-list">
              <ul>
                <li>
                  <a data-bs-toggle="collapse" class="collapse" data-bs-target="#accordion-list-1"><span>01</span> a whole team of <b>EXPERTS</b> <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                  <div id="accordion-list-1" class="collapse show" data-bs-parent=".accordion-list">
                    <p class="font-family-all">
                      We have a pool of experienced consultants and associates that can be drawn upon to meet the requirements of our clients. Expertise spans a wide range of fields, including economics, health, informatics, development communication, policy analysis, livelihoods analysis water and sanitation, environmental and social impact assessments.
                    </p>
                  </div>
                </li>

                <li>
                  <a data-bs-toggle="collapse" data-bs-target="#accordion-list-2" class="collapsed"><span>02</span> cutting edge <b>TECHNOLOGY</b><i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                  <div id="accordion-list-2" class="collapse" data-bs-parent=".accordion-list">
                    <p class="font-family-all">
                      We have competencies in data collection using electronic devices and cloud based databases in platforms such as ODK Collect and Kobo that will be useful in data management under the assignment. Specifically, we are able to use various software programmes, including STATA, SPSS, CS pro, and Ms Excel.
                    </p>
                  </div>
                </li>

                <li>
                  <a data-bs-toggle="collapse" data-bs-target="#accordion-list-3" class="collapsed"><span>03</span> Everyone needs <b>EXPERIENCED</b> consultants <i class="bx bx-chevron-down icon-show"></i><i class="bx bx-chevron-up icon-close"></i></a>
                  <div id="accordion-list-3" class="collapse" data-bs-parent=".accordion-list">
                    <p class="font-family-all">
                      Apart from their extensive experience in the field  of  socio-economic development, all team members have previously worked  with government and donor funded programs. The Team has a successful history of working on individual and joint consultancy assignments with firms and research institutes in Malawi and internationally.
                    </p>
                  </div>
                </li>

              </ul>
            </div>

          </div>
        </div>

      </div>
    </section><!-- End Why Us Section -->


    <!-- ======= Services Section ======= -->
    <section id="services" class="services section-bg bg-dark-all-1">
      <br>
      <div class="container" data-aos="fade-up">

        <div class="section-title section-title1">
          <h2>Services</h2>
          <div class="row">
            <div class="col-12 text-123">
              <p class="col-md-10 mx-auto text-uppercase h5 font-family-all"><b>We offer a suite of skills and competencies to comprehensively address the needs of our clients</b></p><br>
              <p class="col-md-10 mx-auto font-family-all">
              We work from a systems approach, combining political, ecological and social dimensions of phenomena that allows us to approach development challenges in a comprehensive fashion.  Our approach is always focused on understanding the big picture, while observing how elements within systems and subsystems change over time, the circular nature of complex cause-and-effect relationships and attendant impacts. Critical to this understanding is the exposure of assumptions (explicit and hidden) of transitions.</p>
              <br>
              <p class="col-md-10 mx-auto text-uppercase h6 font-family-all">Below are the services that we offer</p>
            </div>
          </div>
        </div>

        <div class="row">
          <div class="col-xl-4 col-md-6 d-flex align-items-stretch mt-4" data-aos="zoom-in" data-aos-delay="100">
            <div class="icon-box bg-green-all">
              <div class="icon"><i class="fa fa-universal-access"></i></div>
              <h5 class="font-family-all">Project Design, Financing, and Management</h5> <br><br><br><br><br>
              <a href="services/s1.php" data-glightbox="type: external" class="portfolio-lightbox preview-link" title="details"><button class="btn btn-primary">Details</button></i></a>
            </div>
          </div>

          <div class="col-xl-4 col-md-6 d-flex align-items-stretch mt-4" data-aos="zoom-in" data-aos-delay="300">
            <div class="icon-box bg-green-all">
              <div class="icon"><i class="fa fa-briefcase"></i></div>
              <h5 class="font-family-all">Project Management, Monitoring and Evaluation, including Performance Evaluation, Policy and Program Analysis</h5><br><br>
              <a href="services/s3.php" data-glightbox="type: external" class="portfolio-lightbox preview-link" title="details"><button class="btn btn-primary">Details</button></i></a>
            </div>
          </div>

          <div class="col-xl-4 col-md-6 d-flex align-items-stretch mt-4" data-aos="zoom-in" data-aos-delay="400">
            <div class="icon-box bg-green-all">
              <div class="icon"><i class="fa fa-globe-africa"></i></div>
              <h5 class="font-family-all">Environmental and Social Impact Assessments, Resettlement Action Planning and Implementation</h5><br><br><br>
              <a href="services/s4.php" data-glightbox="type: external" class="portfolio-lightbox preview-link" title="details"><button class="btn btn-primary">Details</button></i></a>
            </div>
          </div>

          <div class="col-xl-4 col-md-6 d-flex align-items-stretch mt-4" data-aos="zoom-in" data-aos-delay="400">
            <div class="icon-box bg-green-all">
              <div class="icon"><i class="fa fa-water"></i></div>
              <h5 class="font-family-all">Design and Management of Water and Sanitation Infrastructure</h5><br><br><br><br><br>
              <a href="services/s5.php" data-glightbox="type: external" class="portfolio-lightbox preview-link" title="details"><button class="btn btn-primary">Details</button></i></a>
            </div>
          </div>

          <div class="col-xl-4 col-md-6 d-flex align-items-stretch mt-4" data-aos="zoom-in" data-aos-delay="400">
            <div class="icon-box bg-green-all">
              <div class="icon"><i class="fa fa-laptop-code"></i></div>
              <h5 class="font-family-all"> Information, Communication and Technology</h5><br><br><br><br><br><br>
              <a href="services/s6.php" data-glightbox="type: external" class="portfolio-lightbox preview-link" title="details"><button class="btn btn-primary">Details</button></i></a>
            </div>
          </div>

          <div class="col-xl-4 col-md-6 d-flex align-items-stretch mt-4" data-aos="zoom-in" data-aos-delay="200">
            <div class="icon-box bg-green-all">
              <div class="icon"><i class="fa fa-chalkboard"></i></div>
              <h5 class="font-family-all">Training</h5>
              <h5 class="invisible">Project Design, Financing, Management, Management</h5>
              <br><br><br><br><br>
              <a href="services/s2.php" data-glightbox="type: external" class="portfolio-lightbox preview-link" title="details"><button class="btn btn-primary">Details</button></i></a>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Services Section -->

    <!-- ======= Cta Section ======= -->
    <section id="cta" class="cta font-family-all">
      <div class="container" data-aos="zoom-in">

        <div class="row">
          <div class="col-lg-9 text-lg-start">
            <h3>DO BUSINESS WITH US TODAY</h3>
            <p class="text-capitalize text-warning-all"> Our work can be organized into the following broad themes

              <ul class="text-light list-unstyled font-family-new list-all">
                <li><span class="fa fa-check-circle text-primary"></span> Integrated Climate Resilience.</li>
                <li><span class="fa fa-check-circle text-primary"></span> Project Management.</li>
                <li><span class="fa fa-check-circle text-primary"></span> Performance and Impact Evaluations.</li>
                <li><span class="fa fa-check-circle text-primary"></span> Research and Training.</li>
                <li><i class="fa fa-check-circle text-primary"></i> Environmental and Social Impact Analysis.</li>
                <li><span class="fa fa-check-circle text-primary"></span> Livelihoods Analysis.</li>
              </ul>

            </p>
          </div>
          <div class="col-lg-3 cta-btn-container text-center">
            <a class="cta-btn align-middle scrollto" href="#contact">CONTACT US</a>
          </div>
        </div>

      </div>
    </section><!-- End Cta Section -->

        <!-- ======= Testimonials Section ======= -->
        <section id="portfolio" class="testimonials section-bg font-family-all">
          <br>
          <div class="container" data-aos="fade-up">

            <div class="section-title section-title2">
              <h2 class="title-all">Portfolio</h2>
              <div class="row">
                <div class="col-12">
                  <p class="col-md-10 mx-auto text-uppercase h5 font-family-all text-light-all"><b>Our clients and partners include Governments, non-governmental organizations and donor agencies</b></p><br>
                  <p class="col-md-10 mx-auto font-family-all">Our staff have provided advisory services to Government projects, the World Bank, UNICEF, UNFPA, African Development Bank, World Health Organization, Plan International, Care International and Microloan Foundation. <br><br><span class="col-md-10 mx-auto text-uppercase h6 font-family-all">Below are some of the projects that we have worked on recently</span>
                  </p>
                </div>
              </div>
            </div>

            <div class='album py-5 bg-transparent'>
                <div class='container'>
                  <div class='row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3'>

                      <?php

                      $sql = "SELECT * FROM projects ORDER BY id DESC";
                      $result = mysqli_query($conn,$sql);

                      $count = 1;

                      if(mysqli_num_rows($result)>0){

                      while($count<=4){
                        $row=mysqli_fetch_array($result);
                        $id = $row['id'];
                        $title = $row['title'];
                        $client =$row['client'];
                        $duration = $row['duration'];
                        $staff = $row['staff'];
                        $image = $row['image'];
                        $description = $row['description'];

                        echo"
            
                  
                    <div class='col-md-6 alb-all'>
                      <div class='card shadow-sm border-none'>
                        <img src='projects/$image' class='img-all-1'>

                        <div class='card-body'>
      
                          <div class='d-flex justify-content-between align-items-center'>
                            <p class='card-text text-light small-text'>
                              <span class='font-family-all feel'>$title</span>
                                <br><br>
                              <i class='fa fa-dot-circle fa-sm'></i> <span class='font-family-all'>Client</span><br><span class='font-family-all feel'>$client</span>
                                <br><br>
                              <i class='fa fa-dot-circle fa-sm'></i> <span class='font-family-all'>Duration</span><br><span class='font-family-all feel'>$duration</span></p>
                          </div>
                        </div>
                      </div>
                    </div>
                

                        ";

                          $count++;
                      }
                    }
                    else{

                    }

                      ?>
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-12">
                <div class="col-4 col-md-3 col-lg-2 mx-auto">
                  <a href="projects.php" data-glightbox="type: external" class="portfolio-lightbox preview-link" class="col-12 mx-auto"><button class="btn btn-primary col-12">All Projects</button></a>
                </div>
              </div>
            </div>

          </div>
        </section><!-- End Testimonials Section -->
      

    <!-- ======= Team Section ======= -->
    <section id="team" class="team section-bg bg-new-all">
      <br>
      <div class="container" data-aos="fade-up">

        <div class="section-title section-title6">
          <h2>Team</h2>
          <p class="col-md-10 mx-auto text-uppercase h5 font-family-all"><b>Meet the brilliant team behing our agency</b></p><br>
          <p class="font-family-all"><br>The following staff are available within ASPIRE Consulting Associates, and demonstrate our competence and skill set.</p>
        </div>

        <div class="row">

          <div class="col-lg-6">
            <div class="member d-flex align-items-start bg-last" data-aos="zoom-in" data-aos-delay="100">
              <div class="pic"><img src="assets/img/team/team-1.jpg" class="img-fluid" alt=""></div>
              <div class="member-info">
                <h4>Mr. Murphy Kajumi</h4>
                <span class="try-c">Director</span>
                <p>Holds a Master of Arts  (Economics) and Master of Policy Studies.</p>
                
                  <a href="team/t1.php" data-glightbox="type: external" class="portfolio-lightbox preview-link" title="details"><button class="btn btn-sm btn-outline-primary"><i>experience</i></button></i></a>
                
              </div>
            </div>
          </div>

          <div class="col-lg-6 mt-4 mt-lg-0">
            <div class="member d-flex align-items-start bg-last" data-aos="zoom-in" data-aos-delay="200">
              <div class="pic"><img src="assets/img/team/team-2.jpg" class="img-fluid" alt=""></div>
              <div class="member-info">
                <h4>Mr. Thokozani Sambakunsi</h4>
                <span class="try-c">Senior Associate</span>
                <p>Statistician & Management & Information Systems post- graduate (MSc) from the University of Manchester (UK).</p>
                <a href="team/t2.php" data-glightbox="type: external" class="portfolio-lightbox preview-link" title="details"><button class="btn btn-sm btn-outline-primary"><i>experience</i></button></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-6 mt-4">
            <div class="member d-flex align-items-start bg-last" data-aos="zoom-in" data-aos-delay="300">
              <div class="pic"><img src="assets/img/team/team-3.jpg" class="img-fluid" alt=""></div>
              <div class="member-info">
                <h4>Ms. Chisomo Nayeja</h4>
                <span class="try-c">Senior Associate</span>
                <p>An FCCA Fellowship admission, is a Chartered Certified Accountant (associate member) and a Bachelor of Science (Hons) in Applied Accounting.</p>
                <a href="team/t3.php" data-glightbox="type: external" class="portfolio-lightbox preview-link" title="details"><button class="btn btn-sm btn-outline-primary"><i>experience</i></button></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-6 mt-4">
            <div class="member d-flex align-items-start bg-last" data-aos="zoom-in" data-aos-delay="400">
              <div class="pic"><img src="assets/img/team/team-4.jpg" class="img-fluid" alt=""></div>
              <div class="member-info">
                <h4>Ms Chisomo Gunda</h4>
                <span class="try-c">Senior Associate</span>
                <p>A trained Environmental Scientist to a Masters Degree (2001) level and specialized in Community Based Environmental Management.</p>
                <a href="team/t4.php" data-glightbox="type: external" class="portfolio-lightbox preview-link" title="details"><button class="btn btn-sm btn-outline-primary"><i>experience</i></button></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-6 mt-4">
            <div class="member d-flex align-items-start bg-last" data-aos="zoom-in" data-aos-delay="400">
              <div class="pic"><img src="assets/img/team/team-4.jpg" class="img-fluid" alt=""></div>
              <div class="member-info">
                <h4>Ms Enert Nyando Chindevu</h4>
                <span class="try-c">Senior Associate</span>
                <p>Holds a Master of Policy Studies (MPS) Degree.</p>
                <a href="team/t5.php" data-glightbox="type: external" class="portfolio-lightbox preview-link" title="details"><button class="btn btn-sm btn-outline-primary"><i>experience</i></button></i></a>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Team Section -->

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact bg-dark-all-x">
      <br>
      <div class="container" data-aos="fade-up">

        <div class="section-title section-title3">
          <h2>Contact Us</h2>
          <p class="abt-us">For more information, Get in touch with us <b>NOW!</b></p>
        </div>

        <div class="row">

          <div class="col-lg-5 d-flex align-items-stretch">
            <div class="info">
              <div class="address">
                <i class="bi bi-geo-alt"></i>
                <h4>Location:</h4>
                <p>Lilongwe, Malawi.</p>
              </div>

              <div class="email">
                <i class="bi bi-envelope"></i>
                <h4>Email:</h4>
                <p>aspire@gmail.com</p>
              </div>

              <div class="phone">
                <i class="bi bi-phone"></i>
                <h4>Call:</h4>
                <p>+256 999 358 339</p>
              </div>

              <div class="phone">
                <i class="bi bi-whatsapp"></i>
                <h4>WhatsApp:</h4>
                <p>+256 999 358 339</p>
              </div>
            </div>

          </div>

          <div class="col-lg-7 mt-5 mt-lg-0 d-flex align-items-stretch">

            <form action="index.php" method="post" class="my-email">
              <div class="row">
                <div class="form-group col-md-6">
                  <label for="name">Your Name</label>
                  <input type="text" name="name" class="form-control" id="name" required>
                </div>
                <div class="form-group col-md-6">
                  <label for="name">Your Email Address</label>
                  <input type="email" class="form-control" name="email" id="email" required>
                </div>
              </div>
               <div class="form-group">
                <label for="name">Your Phone Number</label>
                <input type="text" class="form-control" name="phone" id="subject" required>
              </div>
              <div class="form-group">
                <label for="name">Subject</label>
                <input type="text" class="form-control" name="subject" id="subject" required>
              </div>
              <div class="form-group">
                <label for="name">Message</label>
                <textarea class="form-control" name="message" rows="10" required></textarea>
              </div>
              <div class="text-center"><button type="submit" name="send">Send Message</button></div>
            </form>

            <?php 

                if (isset($_POST['send'])) {

                  $name = $_POST['name'];
                  $email = $_POST['email'];
                  $phone = $_POST['phone'];
                  $subject = $_POST['subject'];
                  $message = $_POST['message'];

                  $todayDate = date("y-m-d");
                  $todayTime = date("h:i");

                  $sql = "INSERT INTO customers(name,email,phone,subject,message,date,time,status) VALUES('$name','$email','$phone','$subject','$message','$todayDate','$todayTime','1')";
                  $result = mysqli_query($conn,$sql);

                  if($result){
                    echo"

                      <script>
                        Swal.fire({
                            title: 'M E S S A G E',
                            text: 'Message Sent Successfully',
                            icon: 'success',
                            confirmButtonText: 'OK',
                              }).then((result) => {
                            if (result.isConfirmed) {
                              window.location.href='index.php';
                                  }
                              })
                    </script>";
                  }
                  else {
                    echo"

                      <script>
                        Swal.fire({
                            title: 'M E S S A G E',
                            text: 'Message Not Sent',
                            icon: 'error',
                            confirmButtonText: 'OK',
                              }).then((result) => {
                            if (result.isConfirmed) {
                              window.location.href='index.php';
                                  }
                              })
                    </script>";
                  }
                }

            ?>
          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="footer-newsletter bg-dark-all-xy">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-6">
            <h4 class="what">Join Our Newsletter</h4>
            <p>Register your Email address to receive our newsletter.</p>
            <form action="index.php" method="post">
              <input type="email" name="emailx" required><input type="submit" value="Subscribe" name="subscribe">
            </form>

            <?php 

              if (isset($_POST['subscribe'])) {
                $email = $_POST['emailx'];
                $date = date('y-m-d');
                $sql = "INSERT INTO subscribers(date, email) VALUES('$date','$email')";
                $result = mysqli_query($conn,$sql);

                if($result){
                  echo"

                      <script>
                        Swal.fire({
                            title: 'S U B S C R I B E',
                            text: 'Subscription Done Successfully',
                            icon: 'success',
                            confirmButtonText: 'OK',
                              }).then((result) => {
                            if (result.isConfirmed) {
                              window.location.href='index.php';
                                  }
                              })
                    </script>";
                }
                else{
                  echo"

                      <script>
                        Swal.fire({
                            title: 'S U B S C R I B E',
                            text: 'Failed To Subscribe',
                            icon: 'error',
                            confirmButtonText: 'OK',
                              }).then((result) => {
                            if (result.isConfirmed) {
                              window.location.href='index.php';
                                  }
                              })
                    </script>";
                }
              }

            ?>
          </div>
        </div>
      </div>
    </div>

    <div class="container footer-bottom clearfix">
      <div class="copyright">
        &copy; Copyright <strong><span>ASPIRE</span></strong>. All Rights Reserved
      </div>

      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/arsha-free-bootstrap-html-template-corporate/ -->
        Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
      </div>
    </div>
    <div class="dimenxion text-light text-center">
        developed by <strong><span>Cyber DimenXion</span></strong>
      </div>
  </footer><!-- End Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  <script src="assets/js/projects.js"></script>

</body>

</html>