<?php

	include "conn.php";

    session_start();
    $uname = $_SESSION['name'];
    $userid = $_SESSION['id'];

        $sqluser = "SELECT * FROM users WHERE id = '$userid'";
        $resultuser = mysqli_query($conn,$sqluser);
            $rowuser = mysqli_fetch_array($resultuser);
                $usernameID = $rowuser['firstname'];
                $lastnameID = $rowuser['lastname'];

	$actsumid = $_SESSION['actsumid'];

    if(!$uname){
        header("Location: login.php");}
		
?>


<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
	<title>Summary of activity report</title>

  <script src="graphs/zingchart.min.js"></script>
  <link href="css/sb-admin-2.min.css" rel="stylesheet">

  	<link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="ext/js/bootstrap.min.js"></script>
		<script src="ext/jquery-3.6.0.min.js"></script>
	
  <style>
	  body{
		  height: 100vh;
		  width: 100%;
	  }
	  
    #myChart {
      height: 400px;
      min-width: 100px;
      max-width: 50%;
	  	margin: auto;
    }
	  #myChart1 {
      height: 400px;
      min-width: 100px;
      max-width: 50%;
	  	margin: auto;
    }
	  #myChart2 {
      height: 400px;
      min-width: 100px;
      max-width: 70%;
	  	margin: auto;
    }
	  #myChart3 {
      height: 400px;
      min-width: 100px;
      max-width: 70%;
	  	margin: auto;
    }
	  #summary {
      width: 100%;
	  margin: 10px;
      clear: both;
	  text-align: center;
	  color: black;
    }
	  .okr{
	  text-align: center;
	  color: black;
	  }
	  .bgr{
		  background-color: #EDEEF1;
	  }
	  .tbl{
		  font-size: 15px;
		  text-align: center;
		  margin: auto;
		  border: 1px solid #1ABB81;
		  
	  }
	  .bdr{
		  border-bottom: 1px solid #1ABB81;
		  padding: 8px;
	  }
	  .mini{
		  font-size: 18px;
	  }
	  .font{
	  	font-size: 13px;
	  	color: #797979;
	  }
	  .color1{
            background-color: #1ABB81;
        }
        .autoi{
            margin: auto;
        }
  </style>
</head>

<body class="bgr">

	<nav class="navbar navbar-fixed-top okr text-white color1">
  <div class="container-fluid">
    <div class="navbar-header">
      <h1 class="mini"><b>SUMMARY AND GRAPHS FOR ACTIVITY REPORT</b>: 
					<?php $sql = "SELECT * FROM activity WHERE id='$actsumid'";
					$result=mysqli_query($conn,$sql);
					$row = mysqli_fetch_array($result);
					$actname =  $row['rname'];
					echo"<i> $actname</i>";
					?>
			</h1>
    </div>
  </div>
</nav>

	<div class="row">
		<div class="col-12">&nbsp;</div>
	</div>
	<div class="row">
		<div class="col-12">&nbsp;</div>
	</div>

	<br><br><br>
	
	<div class="row">

		<div class="col-12">
  		<div id='myChart' class="card shadow-lg col-5"></div>
  	</div>

  					<div class="col-12">
							<div class="col-12"><br><br></div>
						</div>

  	<div class="col-12">
  		<div id='myChart1' class="card shadow-lg col-6"></div>
  	</div>

  					<div class="col-12">
							<div class="col-12"><br><br></div>
						</div>

		<div id='myChart2' class="card shadow-lg col-12"></div>

						<div class="col-12">
							<div class="col-12"><br><br></div>
						</div>

		<div id='myChart3' class="card shadow-lg col-12"></div>
	</div>
	
	<div id='summary' class="text-dark">
		<br><br>
		<h1>N U M B E R S</h1>
		<br><br>
		
		<table class="tbl">
		
			<th class="bdr">Total participants</th>
			<th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
			<th class="bdr">
				<?php 
				
					$sql = "SELECT * FROM gender WHERE rid='$actsumid'";
							$result=mysqli_query($conn,$sql);
							
							$male = 0;
							$female = 0;
				
							while($row =mysqli_fetch_array($result)){
								$gender = $row['gender'];
								$number = $row['number'];

								if($gender=='male'){
									$male = $number;
								}
								elseif($gender=='female'){
									$female = $number;
								}
							}

						   $total = $male + $female;
						echo"$total";
				?>
			</th>
			
			<tr>
				<td class="bdr">Male</td>
				<td>&nbsp;</td>
				<td class="bdr">
					<?php 
				
					$sql = "SELECT * FROM gender WHERE rid='$actsumid'";
							$result=mysqli_query($conn,$sql);
							
							$male = 0;
							$female = 0;
				
							while($row =mysqli_fetch_array($result)){
								$gender = $row['gender'];
								$number = $row['number'];

								if($gender=='male'){
									$male = $number;
								}
								elseif($gender=='female'){
									$female = $number;
								}
							}

						   $total = $male + $female;
						echo"$male";
					?>
				</td>
			</tr>
			
			<tr>
				<td class="bdr">Female</td>
				<td>&nbsp;</td>
				<td class="bdr">
					<?php
					$sql = "SELECT * FROM gender WHERE rid='$actsumid'";
							$result=mysqli_query($conn,$sql);
							
							$male = 0;
							$female = 0;
				
							while($row =mysqli_fetch_array($result)){
								$gender = $row['gender'];
								$number = $row['number'];

								if($gender=='male'){
									$male = $number;
								}
								elseif($gender=='female'){
									$female = $number;
								}
							}

						   $total = $male + $female;
						echo"$female";
					?>
				</td>
			</tr>
			
			<tr>
				<td class="bdr">Children</td>
				<td>&nbsp;</td>
				<td class="bdr">
					<?php
					$sql = "SELECT * FROM age WHERE rid='$actsumid'";
							$result=mysqli_query($conn,$sql);
							
							$child = 0;
							$youth = 0;
				
							while($row =mysqli_fetch_array($result)){
								$age = $row['age'];
								$number = $row['number'];

								if($age=='children'){
									$child = $number;
								}
								elseif($age=='youth'){
									$youth = $number;
								}
							}

						   $total = $child + $youth;
						echo"$child";
					?>
				</td>
			</tr>
			
			<tr>
				<td class="bdr">Youth</td>
				<td>&nbsp;</td>
				<td class="bdr">
					<?php
					$sql = "SELECT * FROM age WHERE rid='$actsumid'";
							$result=mysqli_query($conn,$sql);
							
							$child = 0;
							$youth = 0;
				
							while($row =mysqli_fetch_array($result)){
								$age = $row['age'];
								$number = $row['number'];

								if($age=='children'){
									$child = $number;
								}
								elseif($age=='youth'){
									$youth = $number;
								}
							}

						   $total = $child + $youth;
						echo"$youth";
					?>
				</td>
			</tr>
		
		</table>
	</div>
	<br><br><br><br><br>
                            <div class="row">
                            <form action="summary.php" method="post" class="col-2 autoi">
                                <button type="submit" class="btn btn-danger col-12" name="close">Close Page</button>
                            </form>
                            </div>

                        

	<br><br><br><br><br><br>

	<?php


                if (isset($_POST['close'])) {
                    echo"<script>window.close();</script>";
                }


       ?>
	
		<script>
			
												
			var myData = [<?php
								$sql = "SELECT * FROM age WHERE rid='$actsumid'";
								$result=mysqli_query($conn,$sql);

								while($row = mysqli_fetch_array($result)){

									  echo $row[ 'number' ].',';	
								}
				
						  ?>];

			var myConfig = {
			  "graphset": [{
				"type": "bar",
				  "plot":{
					  'background-color': "#3BA281", 'bar-width': "70%"
				  },
				"title": {
				  "text": "Age of Participants","color": "#5A5C69"
				},
				"scale-x": {
				  "labels": [<?php
								$sql = "SELECT * FROM age WHERE rid='$actsumid'";
								$result=mysqli_query($conn,$sql);

								while($row = mysqli_fetch_array($result)){

									  echo '"'.$row[ 'age' ].'",';	
								}
				
						  ?>]
				},
				"series": [{
				  "values": myData
				}]
			  }]
			};

			zingchart.render({
			  id: 'myChart',
			  data: myConfig,
			  height: "100%",
			  width: "100%"
			});
				
		
  		</script>
	

	
		<script>
			
												
			var myData = [<?php
								$sql = "SELECT * FROM gender WHERE rid='$actsumid'";
								$result=mysqli_query($conn,$sql);

								while($row = mysqli_fetch_array($result)){

									  echo $row[ 'number' ].',';	
								}
				
						  ?>];

			var myConfig = {
			  "graphset": [{
				"type": "bar",
				  "plot":{
					  'background-color': "#3BA281", 'bar-width': "70%"
				  },
				"title": {
				  "text": "Gender of Participants","color": "#5A5C69"
				},
				"scale-x": {
				  "labels": [<?php
								$sql = "SELECT * FROM gender WHERE rid='$actsumid'";
								$result=mysqli_query($conn,$sql);

								while($row = mysqli_fetch_array($result)){

									  echo '"'.$row[ 'gender' ].'",';	
								}
				
						  ?>]
				},
				"series": [{
				  "values": myData
				}]
			  }]
			};

			zingchart.render({
			  id: 'myChart1',
			  data: myConfig,
			  height: "100%",
			  width: "100%"
			});
				
			
  		</script>
			
	
		<script>
			
												
			var myData = [<?php
								$sql = "SELECT * FROM location WHERE rid='$actsumid'";
								$result=mysqli_query($conn,$sql);

								while($row = mysqli_fetch_array($result)){

									  echo $row[ 'number' ].',';	
								}
				
						  ?>];

			var myConfig = {
			  "graphset": [{
				"type": "bar",
				  "plot":{
					  'background-color': "#3BA281", 'bar-width': "70%"
				  },
				"title": {
				  "text": "Location of Participants","color": "#5A5C69"
				},
				"scale-x": {
				  "labels": [<?php
								$sql = "SELECT * FROM location WHERE rid='$actsumid'";
								$result=mysqli_query($conn,$sql);

								while($row = mysqli_fetch_array($result)){

									  echo '"'.$row[ 'location' ].'",';	
								}
				
						  ?>]
				},
				"series": [{
				  "values": myData
				}]
			  }]
			};

			zingchart.render({
			  id: 'myChart2',
			  data: myConfig,
			  height: "100%",
			  width: "100%"
			});
				
			
  		</script>
	
		<script>
			
												
			var myData = [<?php
								$sql = "SELECT * FROM sector WHERE rid='$actsumid'";
								$result=mysqli_query($conn,$sql);

								while($row = mysqli_fetch_array($result)){

									  echo $row[ 'number' ].',';	
								}
				
						  ?>];

			var myConfig = {
			  "graphset": [{
				"type": "bar",
				  "plot":{
					  'background-color': "#3BA281", 'bar-width': "70%"
				  },
				"title": {
				  "text": "Sector of Participants","color": "#5A5C69"
				},
				"scale-x": {
				  "labels": [<?php
								$sql = "SELECT * FROM sector WHERE rid='$actsumid'";
								$result=mysqli_query($conn,$sql);

								while($row = mysqli_fetch_array($result)){

									  echo '"'.$row[ 'sector' ].'",';	
								}
				
						  ?>]
				},
				"series": [{
				  "values": myData
				}]
			  }]
			};

			zingchart.render({
			  id: 'myChart3',
			  data: myConfig,
			  height: "100%",
			  width: "100%"
			});
				
			
  		</script>
			  
</body>

<footer class="sticky-footer">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span class="font">Copyright &copy; Mzuzu E-Hub 2021</span>
                    </div>
                </div>
     </footer>

</html>	