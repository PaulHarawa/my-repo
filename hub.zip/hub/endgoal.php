<?php
	include"conn.php";
	session_start();
	$id = $_SESSION['deactivateidg'];
    $object = $_SESSION['deactivateobjectg'];

	$sql = "UPDATE $object SET state='0' WHERE id='$id'";

    $result=mysqli_query($conn,$sql);

    	if($result){
            echo"<script>window.close();</script>";
            	}
        else{
            echo"<br><br>
          		<div class='alert alert-danger text-center' role='alert'>
               	Failed to deactivate the program.
          		</div> "; 
            }

?>