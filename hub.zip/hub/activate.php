<?php
	include"conn.php";
	session_start();
	$id = $_SESSION['activateid'];
    $object = $_SESSION['activateobject'];

	$sql = "UPDATE $object SET status='1' WHERE id='$id'";

    $result=mysqli_query($conn,$sql);

    	if($result){
           echo"<script>window.close();</script>";
            	}
        else{
            echo"<br><br>
          		<div class='alert alert-danger text-center' role='alert'>
               	Failed to deactivate the program.
          		</div> "; 
            }

?>