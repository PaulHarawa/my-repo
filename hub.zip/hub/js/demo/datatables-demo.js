$(document).ready( function() {
     *      $('#dataTable').dataTable( {
     *        "order": []
     *      } );
     *    } );