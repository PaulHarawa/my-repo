<?php

    include"conn.php";
    session_start();
    $uname = $_SESSION['name'];
    $userid = $_SESSION['id'];

        $sqluser = "SELECT * FROM users WHERE id = '$userid'";
        $resultuser = mysqli_query($conn,$sqluser);
            $rowuser = mysqli_fetch_array($resultuser);
                $usernameID = $rowuser['firstname'];
                $lastnameID = $rowuser['lastname'];
 
    if(!$userid){
        header("Location: login.php");
    }

?>


<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>ME Manager</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <script src="Sweetalert/dist/sweetalert2.min.js"></script>
    <link rel="stylesheet" href="Sweetalert/dist/sweetalert2.min.css">


    <style>
        .color1{
            background-color: #1ABB81;
        }
        .color2{
            background-color: #C54A3B;
        }
        .autoi{
            margin: auto;
        }
        .new1{
            color:#1ABB81;
        }
        .new1:hover{
            text-decoration:none;

        }
        .new1:active{
            color: orange;
            text-decoration:none;

        }
        .hoverc:hover{
            transform:scale(1.1);
        }
        *{
          transition:0.5s;
        }
    </style>

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav color1 sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="managerme.php">
                <div class="sidebar-brand-icon rotate-n-15">
                    <img src="img/mzuzutrans.png" width="60px" height="60px" alt="">
                </div>
                <div class="sidebar-brand-text mx-3">M & E Manager <sup>&nbsp;</sup></div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="managerme.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-calendar-week"></i>
                    <span>Weekly Report</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="uploadweeklymme.php">Upload</a>
                        <a class="collapse-item" href="viewweeklymme.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseThree"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-swatchbook"></i>
                    <span>Activity Report</span>
                </a>
                <div id="collapseThree" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="uploadactivitymme.php">Upload</a>
                        <a class="collapse-item" href="viewactivitymme.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseFour"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-calendar-alt"></i>
                    <span>Monthly Project Report</span>
                </a>
                <div id="collapseFour" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="uploadMPmme.php">Upload</a>
                        <a class="collapse-item" href="viewMPmme.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseEleven"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-calendar-check"></i>
                    <span>Monthly Dept. Report</span>
                </a>
                <div id="collapseEleven" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="addmdptme.php">Add</a>
                        <a class="collapse-item" href="viewmdptme.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseMaluk"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-calendar-check"></i>
                    <span>Monthly Org. Report</span>
                </a>
                <div id="collapseMaluk" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="addmorgme.php">Add</a>
                        <a class="collapse-item" href="viewmorgme.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseThreeyears"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-dollar-sign"></i>
                    <span>Financial Report</span>
                </a>
                <div id="collapseThreeyears" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="viewfrmme.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTen"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-calendar-check"></i>
                    <span>Quatery Reports</span>
                </a>
                <div id="collapseTen" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="addquatery.php">Add</a>
                        <a class="collapse-item" href="viewquaterymme.php">View</a>
                    </div>
                </div>
            </li>


            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseFive"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-calendar-check"></i>
                    <span>Annual Report</span>
                </a>
                <div id="collapseFive" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="addannual.php">Add</a>
                        <a class="collapse-item" href="viewannualmme.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseSix"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-archive"></i>
                    <span>Programs</span>
                </a>
                <div id="collapseSix" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="viewpgme.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseSeven"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-project-diagram"></i>
                    <span>Projects</span>
                </a>
                <div id="collapseSeven" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="viewpjme.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseEight"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-user-friends"></i>
                    <span>Activities</span>
                </a>
                <div id="collapseEight" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="viewactme.php">View</a>
                        <a class="collapse-item" href="workplanmme.php">Workplan</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseNine"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-binoculars"></i>
                    <span>Goals</span>
                </a>
                <div id="collapseNine" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="addgoalsme.php">Add</a>
                        <a class="collapse-item" href="viewgoalsme.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseNineM"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-question"></i>
                    <span>Missing Reports</span>
                </a>
                <div id="collapseNineM" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="missingw.php">Weekly</a>
                        <a class="collapse-item" href="missinga.php">Activity</a>
                        <a class="collapse-item" href="missingmp.php">Monthly(Proj)</a>
                        <a class="collapse-item" href="missingmd.php">Monthly(Dept)</a>
                    </div>
                </div>
            </li>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light color1 topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>


                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                        <div class="text-white"><?php echo strtoupper("$usernameID $lastnameID");?></div>
                        <div class=""> <form action="managerme.php" method="post"><button class="btn btn-sm btn-warning" name="logout" type="submit">Log-Out</button></form></div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Content Row -->
                    <div class="row">

                        <!-- Total users -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2 hoverc">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-md font-weight-bold text-success text-uppercase mb-1">
                                                <a href="viewweeklymme.php" class="new1">Weekly Reports</a></div>
                                            <div class="h5 mb-0 font-weight-bold text-primary">
                                                <?php

                                                    $today = date("y-m-d");

                                                    $date=date_create("$today");

                                                    date_sub($date,date_interval_create_from_date_string("1 month"));

                                                    $adate = date_format($date,"y-m-d");

                                                    $sql = "SELECT * FROM weekly WHERE idate >= '$adate'";
                                                    $result = mysqli_query($conn,$sql);

                                                    $total = mysqli_num_rows($result);

                                                    echo"<span class='small' >Submitted: $total</span>";

                                                ?>
                                            </div>
                                            <div class="h5 mb-0 font-weight-bold text-warning">
                                                <?php

                                                $today = date("y-m-d");

                                                $date=date_create("$today");

                                                date_sub($date,date_interval_create_from_date_string("10 days"));

                                                $adate = date_format($date,"y-m-d");

                                                $sql = "SELECT * FROM weekly WHERE idate >= '$adate'";

                                                $result = mysqli_query($conn,$sql);

                                                $aou = array();

                                                while($row = mysqli_fetch_array($result)){
                                                    $ruser = $row['uid'];
                                                    array_push($aou,$ruser);
                                                }

                                                $sqlII = "SELECT * FROM users where status='1' AND position != 'Admin' AND position !='Managing-Director'";
                                                $resultII = mysqli_query($conn,$sqlII);

                                                $allusers = array();

                                                while($rowII = mysqli_fetch_array($resultII)){
                                                    $au = $rowII['id'];
                                                    array_push($allusers,$au);
                                                }

                                                $nloops = count($allusers);
                                                $notsub = array();
                                                $needle = '';

                                                for($i=0;$i<$nloops;$i++){

                                                    $needle = array_search($allusers[$i],$aou);

                                                    if( $needle === false ){
                                                        array_push($notsub,$allusers[$i]);
                                                    }
                                                }

                                                $nloops2 = count($notsub);
                                                $missingnor = '0';
                                                for($j=0;$j<$nloops2;$j++){
                                                    $sqlmad = "SELECT * FROM users WHERE id='$notsub[$j]'";
                                                    $resultmad = mysqli_query($conn,$sqlmad);

                                                    $rowmad = mysqli_fetch_array($resultmad);
                                                        $first = $rowmad['firstname'];
                                                        $last = $rowmad['lastname'];
                                                        $uxx = $rowmad['id'];

                                                        if($uxx == $userid){
                                                          $missingnor = $missingnor + '1';
                                                        }
                                                }

                                                echo"<span class='small' >Missing: $missingnor</span><br>";

                                                ?>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-calendar-week fa-2x text-success"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Active users -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2 hoverc">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-md font-weight-bold text-success text-uppercase mb-1">
                                                <a href="viewactivitymme.php" class="new1">Activity Reports</a></div>
                                            <div class="h5 mb-0 font-weight-bold text-primary">
                                                <?php

                                                    $today = date("y-m-d");

                                                    $date=date_create("$today");

                                                    date_sub($date,date_interval_create_from_date_string("1 month"));

                                                    $adate = date_format($date,"y-m-d");

                                                    $sql = "SELECT * FROM activity WHERE idate >= '$adate'";
                                                    $result = mysqli_query($conn,$sql);

                                                    $total = mysqli_num_rows($result);

                                                    echo"<span class='small' >Submitted: $total</span><br>";
                                                ?>
                                            </div>
                                            <div class="h5 mb-0 font-weight-bold text-warning">
                                                <?php

                                                    $active = array();
                                                    $all = array();

                                                    $sql = "SELECT * FROM activities WHERE status='1'";
                                                    $result = mysqli_query($conn,$sql);

                                                    while($row = mysqli_fetch_array($result)){

                                                        $edate = $row['edate'];

                                                        $actidas = $row['id'];

                                                        $date=date_create("$edate");

                                                        date_add($date,date_interval_create_from_date_string("2 days"));
                                                        $adate = date_format($date,"y-m-d");

                                                        $today = date("y-m-d");

                                                        if($adate <= $today){
                                                            array_push($active, $actidas);
                                                        }
                                                    }

                                                    $sql2 = "SELECT * FROM activity";
                                                    $result2 = mysqli_query($conn,$sql2);

                                                    while($row2 = mysqli_fetch_array($result2)){
                                                        $primaryid = $row2['actid'];
                                                        array_push($all, $primaryid);
                                                    }

                                                    $nloops = count($active);
                                                    $notsub = array();

                                                    for($i=0;$i<$nloops;$i++){

                                                        if (array_search($active[$i],$all) === false) {
                                                              array_push($notsub,$active[$i]);
                                                        }
                                                    }

                                                    $nloops2 = count($notsub);

                                                      $missingnor = '0';

                                                    for($j=0;$j<$nloops2;$j++){
                                                        $sqlmad = "SELECT * FROM activities WHERE id='$notsub[$j]'";
                                                        $resultmad = mysqli_query($conn,$sqlmad);

                                                        $rowmad = mysqli_fetch_array($resultmad);
                                                            $uzerid = $rowmad['uid'];

                                                            $rowmad2 = "SELECT * FROM users WHERE id='$uzerid'";
                                                            $rowmad2a = mysqli_query($conn,$rowmad2);

                                                              $rowmad2b = mysqli_fetch_array($rowmad2a);
                                                                  $first = $rowmad2b['firstname'];
                                                                  $last = $rowmad2b['lastname'];
                                                                  $uxy = $rowmad2b['id'];


                                                                  if($uxy == $userid){
                                                                    $missingnor = $missingnor + '1';
                                                                  }
                                                          }

                                                          echo"<span class='small' >Missing: $missingnor</span><br>";

                                                ?>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-swatchbook fa-2x text-success"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Inactive Users -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2 hoverc">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-md font-weight-bold text-success text-uppercase mb-1">
                                                <a href="viewMPmme.php" class="new1">Project Reports</a></div>
                                            <div class="h5 mb-0 font-weight-bold text-primary">
                                                <?php

                                                    $today = date("y-m-d");

                                                    $date=date_create("$today");

                                                    date_sub($date,date_interval_create_from_date_string("1 month"));

                                                    $adate = date_format($date,"y-m-d");

                                                    $sql = "SELECT * FROM monthlydpt WHERE idate >= '$adate'";
                                                    $result = mysqli_query($conn,$sql);

                                                    $total = mysqli_num_rows($result);

                                                    echo"<span class='small' >Submitted: $total</span><br>";
                                                ?>
                                            </div>
                                            <div class="h5 mb-0 font-weight-bold text-warning">

                                              <?php

                                              $allprojects = array();

                                              $sql = "SELECT * FROM projects WHERE status='1'";
                                              $result = mysqli_query($conn,$sql);

                                              while($row = mysqli_fetch_array($result)){

                                                  $projectid = $row['id'];

                                                  array_push($allprojects, $projectid);

                                                }



                                              $primaryid = array();

                                              $today = date("y-m-d");

                                              $date=date_create("$today");

                                              date_sub($date,date_interval_create_from_date_string("35 days"));

                                              $adate = date_format($date,"y-m-d");

                                              $sql2 = "SELECT * FROM monthlydpt WHERE idate >= '$adate'";
                                              $result2 = mysqli_query($conn,$sql2);

                                              while($row2 = mysqli_fetch_array($result2)){
                                                    $pjid = $row2['pjid'];
                                                    array_push($primaryid, $pjid);
                                                }



                                              $nloops = count($allprojects);
                                              $notsub = array();

                                              for($i=0;$i<$nloops;$i++){

                                                  if (array_search($allprojects[$i],$primaryid) === false) {
                                                        array_push($notsub,$allprojects[$i]);
                                                  }
                                                }



                                                $nloops2 = count($notsub);

                                                $missingnor = '0';

                                                    for($j=0;$j<$nloops2;$j++){
                                                        $sqlmad = "SELECT * FROM projects WHERE id='$notsub[$j]'";
                                                        $resultmad = mysqli_query($conn,$sqlmad);

                                                        $rowmad = mysqli_fetch_array($resultmad);
                                                            $uzerid = $rowmad['uid'];

                                                            $rowmad2 = "SELECT * FROM users WHERE id='$uzerid'";
                                                            $rowmad2a = mysqli_query($conn,$rowmad2);

                                                              $rowmad2b = mysqli_fetch_array($rowmad2a);
                                                                  $first = $rowmad2b['firstname'];
                                                                  $last = $rowmad2b['lastname'];
                                                                  $uxz = $rowmad2b['id'];

                                                                  if($uxz == $userid){
                                                                    $missingnor = $missingnor + '1';
                                                                  }
                                                          }

                                                          echo"<span class='small' >Missing: $missingnor</span><br>";


                                              ?>

                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-calendar-alt fa-2x text-success"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                         <!-- Inactive Users -->
                         <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2 hoverc">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-md font-weight-bold text-success text-uppercase mb-1">
                                                <a href="viewannualmme.php" class="new1">Annual Reports</a></div>
                                            <div class="h5 mb-0 font-weight-bold text-primary">
                                                <?php

                                                    $today = date("y-m-d");

                                                    $date=date_create("$today");

                                                    date_sub($date,date_interval_create_from_date_string("2 years"));

                                                    $adate = date_format($date,"y-m-d");

                                                    $sql = "SELECT * FROM annual WHERE idate >= '$adate'";
                                                    $result = mysqli_query($conn,$sql);

                                                    $total = mysqli_num_rows($result);

                                                    echo"<span class='small' >Submitted: $total</span><br>";
                                                ?>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-calendar-check fa-2x text-success"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Inactive Users -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2 hoverc">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-md font-weight-bold text-success text-uppercase mb-1">
                                                <a href="viewpgme.php" class="new1"> Programs</a></div>
                                            <div class="h5 mb-0 font-weight-bold text-primary">
                                                <?php

                                                    $sql = "SELECT * FROM programs";
                                                    $result = mysqli_query($conn,$sql);

                                                    $total = mysqli_num_rows($result);



                                                    $sql2 = "SELECT * FROM programs WHERE status='1'";
                                                    $result2 = mysqli_query($conn,$sql2);

                                                    $total2 = mysqli_num_rows($result2);

                                                    echo"<span class='text-success small'>Active: $total2</span> <br>";

                                                    $sql3 = "SELECT * FROM programs WHERE status='0'";
                                                    $result3 = mysqli_query($conn,$sql3);

                                                    $total3 = mysqli_num_rows($result3);

                                                    echo"<span class='text-warning small'>Inactive: $total3</span>";

                                                ?>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-archive fa-2x text-success"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Inactive Users -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2 hoverc">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-md font-weight-bold text-success text-uppercase mb-1">
                                                <a href="viewpjme.php" class="new1">Projects</a></div>
                                            <div class="h5 mb-0 font-weight-bold text-primary">

                                                <?php

                                                    $sql = "SELECT * FROM projects";
                                                    $result = mysqli_query($conn,$sql);

                                                    $total = mysqli_num_rows($result);




                                                    $sql2 = "SELECT * FROM projects WHERE status='1'";
                                                    $result2 = mysqli_query($conn,$sql2);

                                                    $total2 = mysqli_num_rows($result2);

                                                    echo"<span class='text-success small'> Active: $total2</span> <br>";

                                                    $sql3 = "SELECT * FROM projects WHERE status='0'";
                                                    $result3 = mysqli_query($conn,$sql3);

                                                    $total3 = mysqli_num_rows($result3);

                                                    echo"<span class='text-warning small'>Inactive: $total3</span>";

                                                ?>

                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-project-diagram fa-2x text-success"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Inactive Users -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2 hoverc">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-md font-weight-bold text-success text-uppercase mb-1">
                                                <a href="viewactme.php" class="new1">Activities</a></div>
                                            <div class="h5 mb-0 font-weight-bold text-primary">

                                                <?php

                                                    $sql = "SELECT * FROM activities";
                                                    $result = mysqli_query($conn,$sql);

                                                    $total = mysqli_num_rows($result);





                                                    $sql2 = "SELECT * FROM activities WHERE status='1'";
                                                    $result2 = mysqli_query($conn,$sql2);

                                                    $total2 = mysqli_num_rows($result2);

                                                    echo"<span class='text-success small'>Active: $total2</span><br>";



                                                    $sql3 = "SELECT * FROM activities WHERE status='0'";
                                                    $result3 = mysqli_query($conn,$sql3);

                                                    $total3 = mysqli_num_rows($result3);

                                                    echo"<span class='text-warning small'>Inactive: $total3</span>";

                                                ?>

                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-user-friends fa-2x text-success"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                         <!-- Inactive Users -->
                         <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2 hoverc">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-md font-weight-bold text-success text-uppercase mb-1">
                                                <a href="viewgoalsme.php" class="new1">Goals</a></div>
                                            <div class="h5 mb-0 font-weight-bold text-primary">
                                                <?php

                                                    $sql = "SELECT * FROM goals WHERE uid='$userid' or privacy='1'";
                                                    $result = mysqli_query($conn,$sql);

                                                    $total = mysqli_num_rows($result);





                                                    $sql2 = "SELECT * FROM goals WHERE (uid='$userid' or privacy='1') AND state='1'";
                                                    $result2 = mysqli_query($conn,$sql2);

                                                    $total2 = mysqli_num_rows($result2);

                                                    echo"<span class='text-success small'>Active: $total2</span><br>";



                                                    $sql3 = "SELECT * FROM goals WHERE (uid='$userid' or privacy='1') AND state='0'";
                                                    $result3 = mysqli_query($conn,$sql3);

                                                    $total3 = mysqli_num_rows($result3);

                                                    echo"<span class='text-warning small'>Inactive: $total3</span>";

                                                ?>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-binoculars fa-2x text-success"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>
                    <!-- /.container-fluid -->


                    <br>


                    <!-- Content Row -->
                    <div class="row">

                        <!-- Content Column -->
                        <div class="col-xs-12 col-sm-12 col-lg-6 col-xl-6">


                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Organizational Goals</h6>
                                </div>
                                <?php

                                    $sql = "SELECT * FROM goals WHERE privacy='1' AND state='1'";
                                    $result = mysqli_query($conn,$sql);
                                        while($row = mysqli_fetch_array($result)){
                                            $gname = $row['name'];
                                            $target = $row['target'];
                                            $progress = $row['progress'];

                                            echo"

                                        <div class='card-body'>
                                            <h4 class='small font-weight-bold'>$gname<span
                                                    class='float-right'>";$show = round(($progress/$target)*100); echo "$show%</span></h4>

                                            <div class='progress mb-4'>
                                                <div class='progress-bar bg-success' role='progressbar' style='width: $show%'
                                                    aria-valuenow='0' aria-valuemin='0' aria-valuemax='100'></div>
                                            </div>
                                        </div>


                                            ";
                                        }
                                ?>

                            </div>

                             <!-- Project Card Example -->


                        </div>

                        <div class="col-xs-12 col-sm-12 col-lg-6 col-xl-6">

                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Personal Goals</h6>
                                </div>
                                    <?php

                                    $sqla = "SELECT * FROM goals WHERE privacy='0' AND state='1' AND uid = '$userid'";
                                    $resulta = mysqli_query($conn,$sqla);
                                        while($rowa = mysqli_fetch_array($resulta)){
                                            $gnamea = $rowa['name'];
                                            $targeta = $rowa['target'];
                                            $progressa = $rowa['progress'];

                                            echo"

                                        <div class='card-body'>
                                            <h4 class='small font-weight-bold'>$gnamea<span
                                                    class='float-right'>";$showa = round(($progressa/$targeta)*100); echo "$showa%</span></h4>

                                            <div class='progress mb-4'>
                                                <div class='progress-bar bg-success' role='progressbar' style='width: $showa%'
                                                    aria-valuenow='0' aria-valuemin='0' aria-valuemax='100'></div>
                                            </div>
                                        </div>


                                            ";
                                        }
                                ?>
                            </div>

                        </div>
                    </div>

                </div>

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <br><br><br><br>
            <footer class="sticky-footer">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Mzuzu E-Hub 2021</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

            <?php
                if(isset($_POST['logout'])){
                     echo "<script>
                                                 Swal.fire({
                                                        title: 'LOGOUT',
                                                        text: 'Proceed to logout now?',
                                                        icon: 'warning',
                                                        showCancelButton: true,
                                                        confirmButtonText: 'Yes',
                                                        cancelButtonText: 'No',
                                                            }).then((result) => {
                                                        if (result.isConfirmed) {
                                                             window.location.href='logout.php';
                                                        }
                                                    })
                                                    </script>
                                                ";
                     }

            ?>

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-footer">
                    <form action="logout.php" method="post">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                        <button class="btn btn-primary" type="submit" name="logout">Logout</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-bar-demo.js"></script>

</body>

</html>
