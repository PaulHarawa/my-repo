<?php

    include"conn.php";
    session_start();
    $uid = $_SESSION['id'];

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Mzuzu Ehub Change Password</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <script src="js/jquery.m.js"></script>
    <script src="js/checkforce.min.js"></script>


    <style>
       .pic{
           width: 80%;
           margin: 17% 0% 0% 15%;
       }
       body{
           background-image: url(img/3.jpg);
           background-attachment: fixed;
           background-position: center;
           background-size: cover;
       }
    </style>

</head>

<body>

    <div class="container">

        <!-- Outer Row -->
        <div class="row justify-content-center">

            <div class="col-xl-10 col-lg-12 col-md-9">

                <div class="card o-hidden border-0 shadow-lg my-5 bg-light">
                    <div class="card-body p-0">
                        <!-- Nested Row within Card Body -->
                        <div class="row">
                            <div class="col-lg-6 d-none d-lg-block"><img src="img/mzuzu1.png" class="pic" alt=""></div>
                            <div class="col-lg-6">
                                <div class="p-5">
                                    <div class="text-center">
                                        <h1 class="h4 text-gray-900 mb-4">Change Your Login Password</h1>
                                    </div>
                                    <form class="user" method="POST" action="changepass.php">
                                        <div class="form-group">
                                            <input type="password" class="form-control form-control-user"
                                                id="password" placeholder="New Password" name="pass1" minlength= "8" required>
                                        </div>
                                        <div class="form-group">
                                            <input type="password" class="form-control form-control-user"
                                                id="exampleInputPassword" placeholder="Retype New Password" name="pass2" minlength= "8" required>
                                        </div>

                                        <div class="pwstrength_viewport_progress text-center text-warning text-uppercase"></div>
                                        <br>
                                        <input class="btn btn-primary bg-primary btn-user btn-block" value="Change" type="submit" name="change">
                                    </form>
                                    <br>
                                    <hr>
                                    <div class="text-dark text-center">
                                        <h6>Please make sure that the new password should have a <b>minimum of 8 characters</b> </h4>
                                    </div>
                                    <hr>
                                    <?php

                                        if(isset($_POST['change'])){
                                            $pass1 = $_POST['pass1'];
                                            $pass2 = $_POST['pass2'];

                                            if(empty($pass1) or empty($pass2)){
                                                echo"<br>
                                                            <div class='alert alert-danger text-center' role='alert'>
                                                                Please fill in all the missing detail(s)
                                                            </div> ";
                                            }
                                            else{
                                                if($pass1!=$pass2){
                                                    echo"<br>
                                                            <div class='alert alert-danger text-center' role='alert'>
                                                                Passwords do not match!
                                                            </div> ";
                                                }
                                                else{
                                                    $encpass = sha1($pass1);
                                                    $sql = "UPDATE users SET password='$encpass' WHERE id='$uid'";
                                                    $result = mysqli_query($conn,$sql);

                                                    if($result){
                                                        header("Location: login.php");
                                                    }
                                                    else{
                                                        echo "<script>alert('Failed to change password')</script>";
                                                    }
                                                }
                                            }
                                        }

                                    ?>
                                    <br><br><br><br><br>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <script>
    var render = document.querySelector('.pwstrength_viewport_progress');
    CheckForce('#password').checkPassword(function(response){
      render.innerHTML = '<strong>*** '+response.content+' ***</strong>';
    });
    </script>

</body>

</html>
