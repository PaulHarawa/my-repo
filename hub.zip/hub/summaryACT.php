<?php

	include "conn.php";

    session_start();
    $uname = $_SESSION['name'];
    $userid = $_SESSION['id'];

        $sqluser = "SELECT * FROM users WHERE id = '$userid'";
        $resultuser = mysqli_query($conn,$sqluser);
            $rowuser = mysqli_fetch_array($resultuser);
                $usernameID = $rowuser['firstname'];
                $lastnameID = $rowuser['lastname'];

		$actualactid = $_SESSION['actualactid'];

		$sqlx = "SELECT * FROM activity WHERE actid = '$actualactid'";
		$resultx = mysqli_query($conn,$sqlx);

		$actridArray = array();

			while($rowx = mysqli_fetch_array($resultx)){
				$actrid = $rowx['id'];

				array_push($actridArray, $actrid);
			}

			$count = count($actridArray);

    if(!$uname){
        header("Location: login.php");}
		
?>


<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
	<title>Summary of activity</title>

  <script src="graphs/zingchart.min.js"></script>
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/sb-admin-2.min.css" rel="stylesheet">


  	<link href="css/bootstrap.min.css" rel="stylesheet">
    <script src="ext/js/bootstrap.min.js"></script>
		<script src="ext/jquery-3.6.0.min.js"></script>
	
  <style>
  body{
	  height: 100vh;
		  width: 100%;
	  }
	  
    #myChart {
      height: 400px;
      min-width: 100px;
      max-width: 50%;
	  	margin: auto;
    }
	  #myChart1 {
      height: 400px;
      min-width: 100px;
      max-width: 50%;
	  	margin: auto;
    }
	  #myChart2 {
      height: 400px;
      min-width: 100px;
      max-width: 70%;
	  	margin: auto;
    }
	  #myChart3 {
      height: 400px;
      min-width: 100px;
      max-width: 70%;
	  	margin: auto;
    }
	  #summary {
      width: 100%;
	  margin: 10px;
      clear: both;
	  text-align: center;
	  color: black;
    }
	  .okr{
	  text-align: center;
	  color: black;
	  }
	  .bgr{
		  background-color: #EDEEF1;
	  }
	  .tbl{
		  font-size: 15px;
		  text-align: center;
		  margin: auto;
		  border: 1px solid #1ABB81;
		  
	  }
	  .bdr{
		  border-bottom: 1px solid #1ABB81;
		  padding: 8px;
	  }
	  .mini{
		  font-size: 18px;
	  }
	  .font{
	  	font-size: 13px;
	  	color: #797979;
	  }
	  .color1{
            background-color: #1ABB81;
        }

     .autoi{
     	margin: auto;
     }
  </style>
</head>

<body class="bgr">

	<nav class="navbar navbar-fixed-top okr text-white color1">
  <div class="container-fluid">
    <div class="navbar-header">
      <h1 class="mini"><b>SUMMARY AND GRAPHS FOR ACTIVITY</b>: 
					<?php $sql = "SELECT * FROM activities WHERE id='$actualactid'";
					$result=mysqli_query($conn,$sql);
					$row = mysqli_fetch_array($result);
					$mprname =  $row['name'];
					echo"<i> $mprname</i>";
					?>
			</h1>
    </div>
  </div>
</nav>

<div class="row">
		<div class="col-12">&nbsp;</div>
	</div>
	<div class="row">
		<div class="col-12">&nbsp;</div>
	</div>

	<br><br><br>
	
	<div class="row">

		<div class="col-12">
  		<div id='myChart' class="card shadow-lg col-5"></div>
  	</div>

  					<div class="col-12">
							<div class="col-12"><br><br></div>
						</div>

  	<div class="col-12">
  		<div id='myChart1' class="card shadow-lg col-6"></div>
  	</div>

  					<div class="col-12">
							<div class="col-12"><br><br></div>
						</div>

		<div id='myChart2' class="card shadow-lg col-12"></div>

						<div class="col-12">
							<div class="col-12"><br><br></div>
						</div>

		<div id='myChart3' class="card shadow-lg col-12"></div>
	</div>

	<div id='summary' class="text-dark">
		<br><br>
		<h1>N U M B E R S</h1>
		<br><br>
		
		<table class="tbl">
		
			<th class="bdr">Total participants</th>
			<th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
			<th class="bdr">
				<?php 
					$male = array();
					$female = array();


						for($i=0;$i<$count;$i++){

									$sql = "SELECT * FROM gender WHERE rid='$actridArray[$i]'";
								
									$result=mysqli_query($conn,$sql);
						
									while($row =mysqli_fetch_array($result)){
										$gender = $row['gender'];
										$number = $row['number'];

										if($gender=='male'){
											array_push($male,$number);

										}
										elseif($gender=='female'){
											array_push($female,$number);
										}
						 }

						}

						$malefinal = array_sum($male);
						$femalefinal = array_sum($female);

						$total = $malefinal + $femalefinal;

						echo "$total";
				
				?>

			</th>
			
			<tr>
				<td class="bdr">Male</td>
				<td>&nbsp;</td>
				<td class="bdr">
			<?php 
					$male = array();
					$female = array();


						for($i=0;$i<$count;$i++){

									$sql = "SELECT * FROM gender WHERE rid='$actridArray[$i]'";
								
									$result=mysqli_query($conn,$sql);
						
									while($row =mysqli_fetch_array($result)){
										$gender = $row['gender'];
										$number = $row['number'];

										if($gender=='male'){
											array_push($male,$number);

										}
										elseif($gender=='female'){
											array_push($female,$number);
										}
						 }

						}

						$malefinal = array_sum($male);
						$femalefinal = array_sum($female);

						$total = $malefinal + $femalefinal;

						echo "$malefinal";
				
				?>
				</td>
			</tr>
			
			<tr>
				<td class="bdr">Female</td>
				<td>&nbsp;</td>
				<td class="bdr">
	<?php 
					$male = array();
					$female = array();

						for($i=0;$i<$count;$i++){

									$sql = "SELECT * FROM gender WHERE rid='$actridArray[$i]'";
								
									$result=mysqli_query($conn,$sql);
						
									while($row =mysqli_fetch_array($result)){
										$gender = $row['gender'];
										$number = $row['number'];

										if($gender=='male'){
											array_push($male,$number);

										}
										elseif($gender=='female'){
											array_push($female,$number);
										}
						 }

						}

						$malefinal = array_sum($male);
						$femalefinal = array_sum($female);

						$total = $malefinal + $femalefinal;

						echo "$femalefinal";

							$totalgender = array();
							$namesgender = array();

							array_push($totalgender,$malefinal);
							array_push($totalgender,$femalefinal);
							array_push($namesgender,'male');
							array_push($namesgender,'female');

							$countnumb = count($totalgender);
									
				
				?>
				</td>
			</tr>
			
			<tr>
				<td class="bdr">Children</td>
				<td>&nbsp;</td>
				<td class="bdr">
									<?php 
												$child = array();
												$youth = array();


													for($i=0;$i<$count;$i++){

																$sql = "SELECT * FROM age WHERE rid='$actridArray[$i]'";
															
																$result=mysqli_query($conn,$sql);
													
																while($row =mysqli_fetch_array($result)){
																	$age = $row['age'];
																	$number = $row['number'];

																	if($age=='children'){
																		array_push($child,$number);

																	}
																	elseif($age=='youth'){
																		array_push($youth,$number);
																	}
													 }

													}

													$childfinal = array_sum($child);
													$youthfinal = array_sum($youth);

													$total = $childfinal + $youthfinal;

													echo "$childfinal";
																				
											?>
				</td>
			</tr>
			
			<tr>
				<td class="bdr">Youth</td>
				<td>&nbsp;</td>
				<td class="bdr">
														<?php 
																
																$child = array();
																$youth = array();



																	for($i=0;$i<$count;$i++){

																				$sql = "SELECT * FROM age WHERE rid='$actridArray[$i]'";
																			
																				$result=mysqli_query($conn,$sql);
																	
																				while($row =mysqli_fetch_array($result)){
																					$age = $row['age'];
																					$number = $row['number'];

																					if($age=='children'){
																						array_push($child,$number);

																					}
																					elseif($age=='youth'){
																						array_push($youth,$number);
																					}
																	 }

																	}

																	$childfinal = array_sum($child);
																	$youthfinal = array_sum($youth);

																	$total = $childfinal + $youthfinal;

															echo "$youthfinal";

																$totalnum = array();
																$namesnum = array();

																array_push($totalnum,$childfinal);
																array_push($totalnum,$youthfinal);
																array_push($namesnum,'children');
																array_push($namesnum,'youth');

																$countnum = count($totalnum);
									
												?>
				</td>
			</tr>
		
		</table>

	</div>

	<br><br><br><br><br>
                            <div class="row">
                            <form action="summaryACT.php" method="post" class="col-2 autoi">
                                <button type="submit" class="btn btn-danger col-12" name="close">Close Page</button>
                            </form>
                            </div>

                        

	<br><br><br><br><br><br>

	<?php


                if (isset($_POST['close'])) {
                    echo"<script>window.close();</script>";
                }


       ?>

	
		<script>

			var myData = [<?php
								
								for($j=0;$j<$countnum;$j++){

									  echo $totalnum[ $j ].',';	

									}

						  ?>];

			var myConfig = {
			  "graphset": [{
				"type": "bar",
				  "plot":{
					  'background-color': "#3BA281", 'bar-width': "70%"
				  },
				"title": {
				  "text": "Age of Participants","color": "#5A5C69"
				},
				"scale-x": {
				  "labels": [<?php

				  			for($j=0;$j<$countnum;$j++){

										  echo '"'.$namesnum[ $j ].'",';	
									}
					
						  ?>]
				},
				"series": [{
				  "values": myData
				}]
			  }]
			};

			zingchart.render({
			  id: 'myChart',
			  data: myConfig,
			  height: "100%",
			  width: "100%"
			});
				
	
  		</script>
	

	
		<script>
			
			for(var i=0; i<2; i++){
												
			var myData = [<?php
								for($j=0;$j<$countnumb;$j++){

									  echo $totalgender[ $j ].',';	

									}
				
						  ?>];

			var myConfig = {
			  "graphset": [{
				"type": "bar",
				  "plot":{
					  'background-color': "#3BA281", 'bar-width': "70%"
				  },
				"title": {
				  "text": "Gender of Participants","color": "#5A5C69"
				},
				"scale-x": {
				  "labels": [<?php
								for($j=0;$j<$countnumb;$j++){

										  echo '"'.$namesgender[ $j ].'",';	
									}
				
						  ?>]
				},
				"series": [{
				  "values": myData
				}]
			  }]
			};

			zingchart.render({
			  id: 'myChart1',
			  data: myConfig,
			  height: "100%",
			  width: "100%"
			});
				
			}
  		</script>
			
	
		<script>
			
												
			var myData = [<?php

														$total = array();

														$mzimba = array();
														$karonga = array();
														$nkhatabay = array();
														$chitipa = array();
														$rumphi = array();
														$mzuzu = array();
														$likoma = array();

														for($i=0;$i<$count;$i++){

																		$sql = "SELECT * FROM location WHERE rid='$actridArray[$i]'";
																	
																		$result=mysqli_query($conn,$sql);
															
																		while($row=mysqli_fetch_array($result)){

																			$location = $row['location'];
																			$number = $row['number'];

																			if($location=='Mzimba'){
																				array_push($mzimba,$number);
																			}
																			elseif($location=='Karonga'){
																				array_push($karonga,$number);
																			}
																			elseif($location=='Nkhatabay'){
																				array_push($nkhatabay,$number);
																			}
																			elseif($location=='Chitipa'){
																				array_push($chitipa,$number);
																			}
																			elseif($location=='Rumphi'){
																				array_push($rumphi,$number);
																			}
																			elseif($location=='Mzuzu'){
																				array_push($mzuzu,$number);
																			}
																			elseif($location=='Likoma'){
																				array_push($likoma,$number);
																			}
															 }

															}

															$mzimbaf = array_sum($mzimba);
															$karongaf = array_sum($karonga);
															$nkhatabayf = array_sum($nkhatabay);
															$chitipaf = array_sum($chitipa);
															$rumphif = array_sum($rumphi);
															$mzuzuf = array_sum($mzuzu);
															$likomaf = array_sum($likoma);

															$totalloc = array();
															$locnum = array();

															if ($mzimbaf!='0') {
																	array_push($totalloc,$mzimbaf);
																	array_push($locnum,'mzimba');												
															}
															if ($karongaf!='0') {
																	array_push($totalloc,$karongaf);
																	array_push($locnum,'karonga');												
															}
															if ($nkhatabayf!='0') {
																	array_push($totalloc,$nkhatabayf);
																	array_push($locnum,'nkhatabay');												
															}
															if ($chitipaf!='0') {
																	array_push($totalloc,$chitipaf);
																	array_push($locnum,'chitipa');												
															}
															if ($rumphif!='0') {
																	array_push($totalloc,$rumphif);
																	array_push($locnum,'rumphi');												
															}		
															if ($mzuzuf!='0') {
																	array_push($totalloc,$mzuzuf);
																	array_push($locnum,'mzuzu');												
															}				
															if ($likomaf!='0') {
																	array_push($totalloc,$likomaf);
																	array_push($locnum,'likoma');												
															}			

															
															$countnumbers = count($totalloc);
									
									for($j=0;$j<$countnumbers;$j++){

									  echo $totalloc[ $j ].',';	

									}
						  ?>];

			var myConfig = {
			  "graphset": [{
				"type": "bar",
				  "plot":{
					  'background-color': "#3BA281", 'bar-width': "70%"
				  },
				"title": {
				  "text": "Location of Participants","color": "#5A5C69"
				},
				"scale-x": {
				  "labels": [<?php
											for($j=0;$j<$countnumbers;$j++){

										  echo '"'.$locnum[ $j ].'",';	
									}
						  ?>]
				},
				"series": [{
				  "values": myData
				}]
			  }]
			};

			zingchart.render({
			  id: 'myChart2',
			  data: myConfig,
			  height: "100%",
			  width: "100%"
			});
				
  		</script>
	
		<script>

			var myData = [<?php
								$total = array();

														$agriculture = array();
														$education = array();
														$transport = array();
														$health = array();
														$hospitality = array();
														$ict = array();
														$student = array();
														$other = array();

														for($i=0;$i<$count;$i++){

																		$sql = "SELECT * FROM sector WHERE rid='$actridArray[$i]'";
																	
																		$result=mysqli_query($conn,$sql);
															
																		while($row=mysqli_fetch_array($result)){

																			$sector = $row['sector'];
																			$number = $row['number'];

																			if($sector=='Health'){
																				array_push($health,$number);
																			}
																			elseif($sector=='Agriculture'){
																				array_push($agriculture,$number);
																			}
																			elseif($sector=='Education'){
																				array_push($education,$number);
																			}
																			elseif($sector=='Transport'){
																				array_push($transport,$number);
																			}
																			elseif($sector=='Hospitality'){
																				array_push($hospitality,$number);
																			}
																			elseif($sector=='ICT'){
																				array_push($ict,$number);
																			}
																			elseif($sector=='Student'){
																				array_push($student,$number);
																			}
																			elseif($sector=='Other'){
																				array_push($other,$number);
																			}
															 }

															}

															$agriculturef = array_sum($agriculture);
															$educationf = array_sum($education);
															$transportf = array_sum($transport);
															$healthf = array_sum($health);
															$hospitalityf = array_sum($hospitality);
															$ictf = array_sum($ict);
															$studentf = array_sum($student);
															$otherf = array_sum($other);

															$totalsec = array();
															$secnum = array();

															if ($agriculturef!='0') {
																	array_push($totalsec,$agriculturef);
																	array_push($secnum,'Agriculture');												
															}
															if ($educationf!='0') {
																	array_push($totalsec,$educationf);
																	array_push($secnum,'Education');												
															}
															if ($transportf!='0') {
																	array_push($totalsec,$transportf);
																	array_push($secnum,'Transport');												
															}
															if ($healthf!='0') {
																	array_push($totalsec,$healthf);
																	array_push($secnum,'Health');												
															}
															if ($hospitalityf!='0') {
																	array_push($totalsec,$hospitalityf);
																	array_push($secnum,'Hospitality');												
															}		
															if ($ictf!='0') {
																	array_push($totalsec,$ictf);
																	array_push($secnum,'ICT');												
															}														
															if ($studentf!='0') {
																	array_push($totalsec,$studentf);
																	array_push($secnum,'Student');												
															}	
															if ($otherf!='0') {
																	array_push($totalsec,$otherf);
																	array_push($secnum,'Other');												
															}			

															
															$countnumbers1 = count($totalsec);
									
									for($j=0;$j<$countnumbers1;$j++){

									  echo $totalsec[ $j ].',';	

									}
						  ?>]		

						  var myConfig = {
							  "graphset": [{
								"type": "bar",
								  "plot":{
									  'background-color': "#3BA281", 'bar-width': "70%"
								  },
								"title": {
								  "text": "Sector of Participants","color": "#5A5C69"
								},
								"scale-x": {
								  "labels": [<?php
												for($j=0;$j<$countnumbers1;$j++){

										  echo '"'.$secnum[ $j ].'",';	
									}
								
										  ?>]
								},
								"series": [{
								  "values": myData
								}]
							  }]
							};

							zingchart.render({
							  id: 'myChart3',
							  data: myConfig,
							  height: "100%",
							  width: "100%"
							});
  		</script>

  		<footer class="sticky-footer">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span class="font">Copyright &copy; Mzuzu E-Hub 2021</span>
                    </div>
                </div>
     </footer>

			  
</body>

</html>	