<?php

    include "conn.php";

    session_start();
    $rid = $_SESSION['idx'];

    $sql = "SELECT * FROM weekly WHERE id='$rid'";
    $result = mysqli_query($conn,$sql);

    $row = mysqli_fetch_array($result);

    $rname = $row['file'];
   
   if(!empty($rname)){
        $filepath = "uploads/weekly/".$rname;
            if(!empty($filepath)){
                    header('Content-Description: File Transfer');
                    header('Content-Type: application/octet-stream');
                    header('Content-Disposition: attachment; filename='.basename($filepath));
                    header('Expires: 0');
                    header('Cache-Control: must-revalidate');
                    header('Pragma:public');
                    readfile($filepath);

                }
            else{
                    echo"file does not exists";

                }

                   



   }


   

    

?>