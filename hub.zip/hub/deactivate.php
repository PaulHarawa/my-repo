<?php
	include"conn.php";
	session_start();
	$id = $_SESSION['deactivateid'];
    $object = $_SESSION['deactivateobject'];

	$sql = "UPDATE $object SET status='0' WHERE id='$id'";


    $result=mysqli_query($conn,$sql);

    	if($result){
            echo"<script>window.close();</script>";
            	}
        else{
            echo"<br><br>
          		<div class='alert alert-danger text-center' role='alert'>
               	Failed to deactivate the program.
          		</div> "; 
            }

?>