<?php
	include"conn.php";
	session_start();

    $id = $_SESSION['resetid1'];
    $object = $_SESSION['resetobject1'];
    $objectb = $_SESSION['resetobject2'];

    $def = sha1('mzuzuehub');

	$sql = "UPDATE $object SET status='1',password='$def' WHERE id='$id'";
    $sql2 = "UPDATE $objectb SET status='0' WHERE uid='$id'";

    $result2 = mysqli_query($conn,$sql2);
    $result=mysqli_query($conn,$sql);

    	if($result){
            echo"<script>window.close();</script>";
            	}
        else{
            echo"<br><br>
          		<div class='alert alert-danger text-center' role='alert'>
               	Failed to deactivate the program.
          		</div> "; 
            }

?>