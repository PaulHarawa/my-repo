<?php

include "conn.php";

session_start();

$rname = $_SESSION['del'];
   
if(!empty($rname)){
    $filepath = "uploads/weekly/".$rname;
    unlink($filepath);
    
    header("Location: viewweeklympg.php");
}


?>