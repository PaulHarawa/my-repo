<?php

    include"conn.php";
    session_start();
    $uname = $_SESSION['name'];
    $userid = $_SESSION['id'];

        $sqluser = "SELECT * FROM users WHERE id = '$userid'";
        $resultuser = mysqli_query($conn,$sqluser);
            $rowuser = mysqli_fetch_array($resultuser);
                $usernameID = $rowuser['firstname'];
                $lastnameID = $rowuser['lastname'];

    if(!$uname){
        header("Location: login.php");
    }

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Missing activity Report</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <script src="js/jquery.m.js"></script>

    <script src="Sweetalert/dist/sweetalert2.min.js"></script>
    <link rel="stylesheet" href="Sweetalert/dist/sweetalert2.min.css">


    <style>
        .int{
        }
        .textt{
            width: 100%;
            height: 40px;
            border-radius: 10px;
        }
        .color1{
            background-color: #1ABB81;
        }
        .color2{
            background-color: #C54A3B;
        }
        .color3{
            background-color: #4E73B4;
        }
        .table1{
            margin: auto;
        }
        .tabledata1{
            padding: 20px;
        }
        .rborder{
            border: none;
            padding: 7px;
            border-radius: 10px;
            width: 100%;
        }
        .up{
            text-align: center;
        }
        .upb{
            width: 100%;
        }
    </style>

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav color1 sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="managerme.php">
                <div class="sidebar-brand-icon rotate-n-15">
                    <img src="img/mzuzutrans.png" width="60px" height="60px" alt="">
                </div>
                <div class="sidebar-brand-text mx-3">M & E Manager <sup>&nbsp;</sup></div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="managerme.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-calendar-week"></i>
                    <span>Weekly Report</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="uploadweeklymme.php">Upload</a>
                        <a class="collapse-item" href="viewweeklymme.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseThree"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-swatchbook"></i>
                    <span>Activity Report</span>
                </a>
                <div id="collapseThree" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="uploadactivitymme.php">Upload</a>
                        <a class="collapse-item" href="viewactivitymme.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseFour"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-calendar-alt"></i>
                    <span>Monthly Project Report</span>
                </a>
                <div id="collapseFour" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="uploadMPmme.php">Upload</a>
                        <a class="collapse-item" href="viewMPmme.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseEleven"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-calendar-check"></i>
                    <span>Monthly Dept. Report</span>
                </a>
                <div id="collapseEleven" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="addmdptme.php">Add</a>
                        <a class="collapse-item" href="viewmdptme.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseMaluk"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-calendar-check"></i>
                    <span>Monthly Org. Report</span>
                </a>
                <div id="collapseMaluk" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="addmorgme.php">Add</a>
                        <a class="collapse-item" href="viewmorgme.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseThreeyears"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-dollar-sign"></i>
                    <span>Financial Report</span>
                </a>
                <div id="collapseThreeyears" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="viewfrmme.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTen"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-calendar-check"></i>
                    <span>Quatery Reports</span>
                </a>
                <div id="collapseTen" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="addquatery.php">Add</a>
                        <a class="collapse-item" href="viewquaterymme.php">View</a>
                    </div>
                </div>
            </li>


            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseFive"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-calendar-check"></i>
                    <span>Annual Report</span>
                </a>
                <div id="collapseFive" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="addannual.php">Add</a>
                        <a class="collapse-item" href="viewannualmme.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseSix"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-archive"></i>
                    <span>Programs</span>
                </a>
                <div id="collapseSix" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="viewpgme.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseSeven"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-project-diagram"></i>
                    <span>Projects</span>
                </a>
                <div id="collapseSeven" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="viewpjme.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseEight"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-user-friends"></i>
                    <span>Activities</span>
                </a>
                <div id="collapseEight" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="viewactme.php">View</a>
                        <a class="collapse-item" href="workplanmme.php">Workplan</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseNine"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-binoculars"></i>
                    <span>Goals</span>
                </a>
                <div id="collapseNine" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="addgoalsme.php">Add</a>
                        <a class="collapse-item" href="viewgoalsme.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseNineM"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-question"></i>
                    <span>Missing Reports</span>
                </a>
                <div id="collapseNineM" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="missingw.php">Weekly</a>
                        <a class="collapse-item bg-success" href="missinga.php">Activity</a>
                        <a class="collapse-item" href="missingmp.php">Monthly(Proj)</a>
                        <a class="collapse-item" href="missingmd.php">Monthly(Dept)</a>
                    </div>
                </div>
            </li>

        </ul>

        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light color1 topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>


                    <!-- Topbar Navbar -->
                   <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                        <div class="text-white"><?php echo strtoupper("$usernameID $lastnameID");?></div>
                        <div class=""> <form action="missinga.php" method="post"><button class="btn btn-sm btn-warning" name="logout" type="submit">Log-Out</button></form></div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="h5 m-0 font-weight-bold text-primary text-center ">MISSING ACTIVITY REPORTS</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped" id="dataTable1" width="100%" cellspacing="0">
                                    <thead>
                                        <tr class="text-center color3 text-white table-borderless">
                                            <th>Staff&nbsp;Name</th>
                                            <th>Send&nbsp;Notification</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php

                                            $active = array();
                                            $all = array();

                                            $sql = "SELECT * FROM activities WHERE status='1'";
                                            $result = mysqli_query($conn,$sql);

                                            while($row = mysqli_fetch_array($result)){

                                                $edate = $row['edate'];

                                                $actidas = $row['id'];

                                                $date=date_create("$edate");

                                                date_add($date,date_interval_create_from_date_string("2 days"));
                                                $adate = date_format($date,"y-m-d");

                                                $today = date("y-m-d");

                                                if($adate <= $today){
                                                    array_push($active, $actidas);
                                                }
                                            }

                                            $sql2 = "SELECT * FROM activity";
                                            $result2 = mysqli_query($conn,$sql2);

                                            while($row2 = mysqli_fetch_array($result2)){
                                                $primaryid = $row2['actid'];
                                                array_push($all, $primaryid);
                                            }

                                            $nloops = count($active);
                                            $notsub = array();

                                            for($i=0;$i<$nloops;$i++){

                                                if (array_search($active[$i],$all) === false) {
                                                      array_push($notsub,$active[$i]);
                                                }
                                            }

                                            $nloops2 = count($notsub);

                                        if ($nloops2 <= 0) {
                                            echo "<tr class='text-center text-danger'>

                                                    <td colspan='2'>No missing activity reports exists</td>

                                            </tr>
                                            ";

                                        } else {

                                            for($j=0;$j<$nloops2;$j++){
                                                $sqlmad = "SELECT * FROM activities WHERE id='$notsub[$j]'";
                                                $resultmad = mysqli_query($conn,$sqlmad);

                                                $rowmad = mysqli_fetch_array($resultmad);
                                                    $uzerid = $rowmad['uid'];

                                                    $rowmad2 = "SELECT * FROM users WHERE id='$uzerid'";
                                                    $rowmad2a = mysqli_query($conn,$rowmad2);

                                                      $rowmad2b = mysqli_fetch_array($rowmad2a);
                                                          $first = $rowmad2b['firstname'];
                                                          $last = $rowmad2b['lastname'];
                                                          $uxx = $rowmad2b['id'];

                                                    echo"

                                                        <tr class='text-center'>

                                                            <td>$first $last</td>
                                                            <td><form action='missinga.php' method='post' enctype='multipart/form-data'>
                                                            <button class='btn btn-sm btn-danger' type='submit' name='notify'><i>notify</i></button>
                                                            <input type='radio' value='$uxx' name='uxx' checked hidden>
                                                            </form></td>

                                                        </tr>

                                                    ";
                                            }
                                          }

                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>


                    <br><br>
                    <!-- Content Row -->
                </div>

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Mzuzu E-Hub 2021</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

              <?php
                if(isset($_POST['logout'])){
                     echo "<script>
                                                 Swal.fire({
                                                        title: 'LOGOUT',
                                                        text: 'Proceed to logout now?',
                                                        icon: 'warning',
                                                        showCancelButton: true,
                                                        confirmButtonText: 'Yes',
                                                        cancelButtonText: 'No',
                                                            }).then((result) => {
                                                        if (result.isConfirmed) {
                                                             window.location.href='logout.php';
                                                        }
                                                    })
                                                    </script>
                                                ";
                     }

            ?>

            <?php

                     if(isset($_POST['notify'])){

                        $todayc = date("y-m-d");

                         $message = "This is a reminder that you have not yet submitted your activity report, please do so as soon as possible.";

                         $st = $_POST['uxx'];

                         $sqlL = "INSERT INTO notea(uid,message,date,cuid,state) VALUES('$st','$message','$todayc','$userid','1')";
                         $resultL = mysqli_query($conn,$sqlL);

                         if($resultL){
                            echo "<script>
                            Swal.fire({
                                        title: 'missing report',
                                        text: 'Notification sent successfully',
                                        icon: 'success',
                                        confirmButtonText: 'OK',
                                            }).then((result) => {
                                        if (result.isConfirmed) {

                                            window.location.href='missinga.php';
                                        }
                                    })
                                    </script>
                            </script>";
                         }
                     }

            ?>

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-footer">
                    <form action="logout.php" method="post">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                        <button class="btn btn-primary" type="submit" name="logout">Logout</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        $(document).ready(function(){
            $('#dataTable1').DataTable({
                "order": [[0,"desc"]]
            });
            $('.dataTables_length').addClass('bs-select');

        });
    </script>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-bar-demo.js"></script>

    <!-- Page level plugins -->
<script src="vendor/datatables/jquery.dataTables.min.js"></script>
<script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

<!-- Page level custom scripts -->
<script src="js/demo/datatables-demo.js"></script>

</body>

</html>
