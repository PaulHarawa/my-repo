<?php

    include"conn.php";
    session_start();
    $uname = $_SESSION['name'];
    $uid = $_SESSION['id'];

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>View Weekly Report</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">


    <style>
        .stay-open{
            display: block !important;
        }
        .int{
            background-color:darkgrey;
            padding:8px 10px 8px 10px;
            color: white;
            border-radius: 10%;
        }
    </style>

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-success sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="managerpg.php">
                <div class="sidebar-brand-icon rotate-n-15">
                    <img src="img/mzuzutrans.png" width="60px" height="60px" alt="">
                </div>
                <div class="sidebar-brand-text mx-3">Programs Manager <sup>&nbsp;</sup></div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="managerpg.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-calendar-week"></i>
                    <span>Weekly Report</span>
                </a>
                <div id="collapseTwo" class="collapse stay-open" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="uploadweeklympg.php">Upload</a>
                        <a class="collapse-item bg-gradient-light" href="viewweeklympg.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseThree"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-swatchbook"></i>
                    <span>Activity Report</span>
                </a>
                <div id="collapseThree" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="uploadactivitympg.php">Upload</a>
                        <a class="collapse-item" href="viewactivitympg.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseFour"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-calendar-alt"></i>
                    <span>Monthly Project Report</span>
                </a>
                <div id="collapseFour" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="uploadMPmpg.html">Upload</a>
                        <a class="collapse-item" href="viewMPmpg.html">View</a>
                    </div>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseEleven"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-calendar-check"></i>
                    <span>Monthly Dept. Report</span>
                </a>
                <div id="collapseEleven" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="addmdpt.html">Add</a>
                        <a class="collapse-item" href="viewmdpt.html">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#gome"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-calendar-check"></i>
                    <span>Monthly Org. Report</span>

                </a>
                <div id="gome" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="viewmorgpg.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTen"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-calendar-check"></i>
                    <span>Quatery Reports</span>
                </a>
                <div id="collapseTen" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="viewquaterympg.html">View</a>
                    </div>
                </div>
            </li>


            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseFive"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-calendar-check"></i>
                    <span>Annual Report</span>
                </a>
                <div id="collapseFive" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="viewannualmpg.html">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseThreeyears"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-dollar-sign"></i>
                    <span>Financial Report</span>
                </a>
                <div id="collapseThreeyears" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="viewfrmpg.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseSix"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-archive"></i>
                    <span>Programs</span>
                </a>
                <div id="collapseSix" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="addpg.html">Add</a>
                        <a class="collapse-item" href="viewpg.html">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseSeven"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-project-diagram"></i>
                    <span>Projects</span>
                </a>
                <div id="collapseSeven" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="addpj.html">Add</a>
                        <a class="collapse-item" href="viewpj.html">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseEight"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-user-friends"></i>
                    <span>Activities</span>
                </a>
                <div id="collapseEight" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="addact.html">Add</a>
                        <a class="collapse-item" href="viewact.html">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseNine"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-binoculars"></i>
                    <span>Goals</span>
                </a>
                <div id="collapseNine" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="addgoals.html">Add</a>
                        <a class="collapse-item" href="viewgoals.html">View</a>
                    </div>
                </div>
            </li>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-gradient-light topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>


                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - Messages -->
                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-dark small"><?php echo"$uname";?></span>
                                <i class="rounded-circle fa fa-user fa-lg text-success"></i>

                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-dark"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">View Reports</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr class="text-center">
                                            <th>Submission Date</th>
                                            <th>Report Name</th>
                                            <th>Intended Date</th>
                                            <th>Comments</th>
                                            <th>Edit</th>
                                            <th>Download</th>
                                            <th>Owner</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php

                                            $sql = "SELECT * FROM trial";
                                            $result = mysqli_query($conn,$sql);

                                            if($result){
                                                if(mysqli_num_rows($result)>0){
                                                    while($row=mysqli_fetch_array($result)){
                                                        $id = $row['id'];
                                                        $rname = $row['rname'];
                                                        $sdate = $row['sdate'];
                                                        $idate = $row['idate'];
                                                        $uid = $row['uid'];

                                                        $sql2 = "SELECT * FROM users WHERE id='$uid'";
                                                        $result2 = mysqli_query($conn,$sql2);

                                                        $row2=mysqli_fetch_array($result2);
                                                        $username = $row2['username'];

                                                        $edit="";

                                                        $sql3 = "SELECT * FROM comments WHERE rid='$id'";
                                                        $result3 = mysqli_query($conn,$sql3);

                                                        $totalcom = mysqli_num_rows($result3);

                                                        if($uname==$username){
                                                            $edit = "<form action='viewweeklympg.php' method='post' enctype='multipart/form-data'>

                                                            <button class='btn btn-circle btn-sm btn-success' type='submit' name='edit'><i class='fa fa-edit'></i></button>
                                                            <input type='radio' value='$id' name='id' checked hidden>

                                                            </form>";
                                                        }
                                                        else{
                                                            $edit = "<i>No permission</i>";
                                                        }

                                                        echo"

                                                            <tr class='text-center'>
                                                                <td>$sdate</td>
                                                                <td>$rname</td>



                                                                <td>$idate</td>

                                                                <td> <form action='viewweeklympg.php' method='post' enctype='multipart/form-data'>
                                                                <button class='btn btn-circle btn-success btn-sm' type='submit' name='comment'>$totalcom</button>
                                                                <input type='radio' value='$id' name='id' checked hidden>
                                                                </form>
                                                                </td>

                                                                <td>$edit</td>

                                                                <td>
                                                                    <form action='viewweeklympg.php' method='post' enctype='multipart/form-data'>
                                                                    <button class='btn btn-circle btn-sm btn-success' type='submit' name='download'><i class='fa fa-download'></i></button>
                                                                    <input type='radio' value='$id' name='id' checked hidden>
                                                                    </form>
                                                                </td>

                                                                <td>$username</td>
                                                            </tr>

                                                        ";
                                                    }
                                                }
                                                else{
                                                    echo"<br><br>
                                                     <div class='alert alert-danger text-center' role='alert'>
                                                     No weekly reports available for you.
                                                     </div> ";
                                                }
                                            }
                                            else{
                                                echo"<br><br>
                                              <div class='alert alert-danger text-center' role='alert'>
                                                   Failed to view weekly reports.
                                              </div> ";
                                            }

                                        ?>

                                        <?php

                                            if(isset($_POST['download'])){
                                                $rid = $_POST['id'];
                                                $_SESSION['idx'] = $rid;

                                                echo"<script>window.open('downloadw.php','_blank')</script>";
                                            }

                                        ?>

                                        <?php

                                            if(isset($_POST['edit'])){
                                                $rid=$_POST['id'];
                                                $_SESSION['ida'] = $rid;

                                                echo"<script>window.location.href='editweeklympg.php'</script>";
                                            }

                                        ?>

                                        <?php

                                            if(isset($_POST['comment'])){
                                                $rid=$_POST['id'];
                                                $_SESSION['ida'] = $rid;

                                                echo"<script>window.location.href='commentweeklympg.php'</script>";
                                            }

                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>


                    <br><br>
                    <!-- Content Row -->
                </div>

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Mzuzu E-Hub 2021</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-footer">
                    <form action="logout.php" method="post">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                        <button class="btn btn-primary" type="submit" name="logout">Logout</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-bar-demo.js"></script>

    <!-- Page level plugins -->
<script src="vendor/datatables/jquery.dataTables.min.js"></script>
<script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

<!-- Page level custom scripts -->
<script src="js/demo/datatables-demo.js"></script>

</body>

</html>
