-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 25, 2021 at 06:43 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hub`
--

-- --------------------------------------------------------

--
-- Table structure for table `activities`
--

CREATE TABLE `activities` (
  `id` int(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `cdate` varchar(200) NOT NULL,
  `sdate` varchar(200) NOT NULL,
  `edate` varchar(200) NOT NULL,
  `duration` varchar(200) NOT NULL,
  `pjid` int(200) NOT NULL,
  `uid` int(200) NOT NULL,
  `location` varchar(200) NOT NULL,
  `cuid` int(200) NOT NULL,
  `status` int(200) NOT NULL,
  `workplan` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `activity`
--

CREATE TABLE `activity` (
  `id` int(200) NOT NULL,
  `rname` varchar(200) NOT NULL,
  `file` varchar(200) NOT NULL,
  `sdate` varchar(200) NOT NULL,
  `idate` varchar(200) NOT NULL,
  `actid` int(200) NOT NULL,
  `uid` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `age`
--

CREATE TABLE `age` (
  `id` int(200) NOT NULL,
  `age` varchar(200) NOT NULL,
  `number` int(200) NOT NULL,
  `rid` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `annual`
--

CREATE TABLE `annual` (
  `id` int(200) NOT NULL,
  `rname` varchar(200) NOT NULL,
  `file` varchar(200) NOT NULL,
  `sdate` varchar(200) NOT NULL,
  `idate` varchar(200) NOT NULL,
  `uid` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(200) NOT NULL,
  `rid` int(200) NOT NULL,
  `comment` varchar(2000) NOT NULL,
  `date` varchar(200) NOT NULL,
  `uid` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `commentsa`
--

CREATE TABLE `commentsa` (
  `id` int(200) NOT NULL,
  `rid` int(200) NOT NULL,
  `comment` varchar(2000) NOT NULL,
  `date` varchar(200) NOT NULL,
  `uid` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `commentsact`
--

CREATE TABLE `commentsact` (
  `id` int(200) NOT NULL,
  `rid` int(200) NOT NULL,
  `comment` varchar(2000) NOT NULL,
  `date` varchar(200) NOT NULL,
  `uid` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `commentsfr`
--

CREATE TABLE `commentsfr` (
  `id` int(200) NOT NULL,
  `rid` int(200) NOT NULL,
  `comment` varchar(200) NOT NULL,
  `date` varchar(200) NOT NULL,
  `uid` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `commentsmdpt`
--

CREATE TABLE `commentsmdpt` (
  `id` int(200) NOT NULL,
  `rid` int(200) NOT NULL,
  `comment` varchar(2000) NOT NULL,
  `date` varchar(200) NOT NULL,
  `uid` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `commentsmorg`
--

CREATE TABLE `commentsmorg` (
  `id` int(200) NOT NULL,
  `rid` int(200) NOT NULL,
  `comment` varchar(2000) NOT NULL,
  `date` varchar(200) NOT NULL,
  `uid` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `commentsmp`
--

CREATE TABLE `commentsmp` (
  `id` int(200) NOT NULL,
  `rid` int(200) NOT NULL,
  `comment` varchar(2000) NOT NULL,
  `date` varchar(200) NOT NULL,
  `uid` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT=' ';

-- --------------------------------------------------------

--
-- Table structure for table `commentsq`
--

CREATE TABLE `commentsq` (
  `id` int(200) NOT NULL,
  `rid` int(200) NOT NULL,
  `comment` varchar(2000) NOT NULL,
  `date` varchar(200) NOT NULL,
  `uid` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `commentwp`
--

CREATE TABLE `commentwp` (
  `id` int(200) NOT NULL,
  `rid` int(200) NOT NULL,
  `comment` varchar(2000) NOT NULL,
  `date` varchar(200) NOT NULL,
  `uid` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `departmental`
--

CREATE TABLE `departmental` (
  `id` int(200) NOT NULL,
  `rname` varchar(200) NOT NULL,
  `file` varchar(200) NOT NULL,
  `sdate` varchar(200) NOT NULL,
  `idate` varchar(200) NOT NULL,
  `uid` int(200) NOT NULL,
  `dept` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `fin`
--

CREATE TABLE `fin` (
  `id` int(200) NOT NULL,
  `rname` varchar(200) NOT NULL,
  `file` varchar(200) NOT NULL,
  `sdate` varchar(200) NOT NULL,
  `idate` varchar(200) NOT NULL,
  `uid` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `finother`
--

CREATE TABLE `finother` (
  `id` int(200) NOT NULL,
  `rid` int(200) NOT NULL,
  `uid` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `gender`
--

CREATE TABLE `gender` (
  `id` int(200) NOT NULL,
  `gender` varchar(200) NOT NULL,
  `number` int(200) NOT NULL,
  `rid` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `goals`
--

CREATE TABLE `goals` (
  `id` int(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `date` varchar(200) NOT NULL,
  `target` int(200) NOT NULL,
  `edate` varchar(200) NOT NULL,
  `duration` varchar(200) NOT NULL,
  `privacy` int(200) NOT NULL,
  `uid` int(200) NOT NULL,
  `progress` int(200) NOT NULL,
  `state` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='(,,,,,,';

-- --------------------------------------------------------

--
-- Table structure for table `goalsprog`
--

CREATE TABLE `goalsprog` (
  `id` int(200) NOT NULL,
  `gid` int(200) NOT NULL,
  `date` varchar(200) NOT NULL,
  `value` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `id` int(200) NOT NULL,
  `location` varchar(200) NOT NULL,
  `number` int(200) NOT NULL,
  `rid` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `monthlydpt`
--

CREATE TABLE `monthlydpt` (
  `id` int(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `file` varchar(200) NOT NULL,
  `sdate` varchar(200) NOT NULL,
  `idate` varchar(200) NOT NULL,
  `pjid` int(200) NOT NULL,
  `uid` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `monthlyorg`
--

CREATE TABLE `monthlyorg` (
  `id` int(200) NOT NULL,
  `rname` varchar(200) NOT NULL,
  `file` varchar(200) NOT NULL,
  `sdate` varchar(200) NOT NULL,
  `idate` varchar(200) NOT NULL,
  `uid` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `notea`
--

CREATE TABLE `notea` (
  `id` int(200) NOT NULL,
  `uid` int(200) NOT NULL,
  `message` varchar(200) NOT NULL,
  `date` varchar(200) NOT NULL,
  `cuid` int(200) NOT NULL,
  `state` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `notemd`
--

CREATE TABLE `notemd` (
  `id` int(200) NOT NULL,
  `uid` int(200) NOT NULL,
  `message` varchar(200) NOT NULL,
  `date` varchar(200) NOT NULL,
  `cuid` int(200) NOT NULL,
  `state` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `notemp`
--

CREATE TABLE `notemp` (
  `id` int(200) NOT NULL,
  `uid` int(200) NOT NULL,
  `message` varchar(200) NOT NULL,
  `date` varchar(200) NOT NULL,
  `cuid` int(200) NOT NULL,
  `state` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `notew`
--

CREATE TABLE `notew` (
  `id` int(200) NOT NULL,
  `uid` int(200) NOT NULL,
  `message` varchar(2000) NOT NULL,
  `date` varchar(200) NOT NULL,
  `cuid` int(200) NOT NULL,
  `state` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `programs`
--

CREATE TABLE `programs` (
  `id` int(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `sdate` varchar(200) NOT NULL,
  `cdate` varchar(200) NOT NULL,
  `uid` int(200) NOT NULL,
  `status` int(200) NOT NULL,
  `officer` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `cdate` varchar(200) NOT NULL,
  `sdate` varchar(200) NOT NULL,
  `edate` varchar(200) NOT NULL,
  `duration` varchar(200) NOT NULL,
  `donor` varchar(200) NOT NULL,
  `pgid` int(200) NOT NULL,
  `uid` int(200) NOT NULL,
  `cuid` int(200) NOT NULL,
  `status` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `quatery`
--

CREATE TABLE `quatery` (
  `id` int(200) NOT NULL,
  `rname` varchar(200) NOT NULL,
  `file` varchar(200) NOT NULL,
  `sdate` varchar(200) NOT NULL,
  `idate` varchar(200) NOT NULL,
  `uid` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `reset`
--

CREATE TABLE `reset` (
  `id` int(200) NOT NULL,
  `uid` int(200) NOT NULL,
  `status` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `sdoc`
--

CREATE TABLE `sdoc` (
  `id` int(200) NOT NULL,
  `actrid` int(200) NOT NULL,
  `mprid` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `sector`
--

CREATE TABLE `sector` (
  `id` int(200) NOT NULL,
  `sector` varchar(200) NOT NULL,
  `number` int(200) NOT NULL,
  `rid` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `trial`
--

CREATE TABLE `trial` (
  `id` int(200) NOT NULL,
  `rname` varchar(200) NOT NULL,
  `sdate` varchar(200) NOT NULL,
  `idate` varchar(200) NOT NULL,
  `uid` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(200) NOT NULL,
  `firstname` varchar(200) NOT NULL,
  `lastname` varchar(200) NOT NULL,
  `mail` varchar(200) NOT NULL,
  `pnumber` varchar(200) NOT NULL,
  `position` varchar(200) NOT NULL,
  `department` varchar(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `status` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `mail`, `pnumber`, `position`, `department`, `username`, `password`, `status`) VALUES
(1, 'admin', 'admin', 'admin@mzuzuehub.org', '0999358339', 'Admin', 'Information-Technology', 'admin', '9b248b3c1308cf3f57f4220ec2aea2c0e9545921', 1);

-- --------------------------------------------------------

--
-- Table structure for table `weekly`
--

CREATE TABLE `weekly` (
  `id` int(200) NOT NULL,
  `rname` varchar(200) NOT NULL,
  `file` varchar(300) NOT NULL,
  `sdate` varchar(200) NOT NULL,
  `idate` varchar(200) NOT NULL,
  `uid` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `workplan`
--

CREATE TABLE `workplan` (
  `id` int(200) NOT NULL,
  `rname` varchar(200) NOT NULL,
  `file` varchar(200) NOT NULL,
  `sdate` varchar(200) NOT NULL,
  `idate` varchar(200) NOT NULL,
  `uid` int(200) NOT NULL,
  `actid` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activities`
--
ALTER TABLE `activities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `activity`
--
ALTER TABLE `activity`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `age`
--
ALTER TABLE `age`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `annual`
--
ALTER TABLE `annual`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `commentsa`
--
ALTER TABLE `commentsa`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `commentsact`
--
ALTER TABLE `commentsact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `commentsfr`
--
ALTER TABLE `commentsfr`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `commentsmdpt`
--
ALTER TABLE `commentsmdpt`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `commentsmorg`
--
ALTER TABLE `commentsmorg`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `commentsmp`
--
ALTER TABLE `commentsmp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `commentsq`
--
ALTER TABLE `commentsq`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `commentwp`
--
ALTER TABLE `commentwp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `departmental`
--
ALTER TABLE `departmental`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fin`
--
ALTER TABLE `fin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `finother`
--
ALTER TABLE `finother`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gender`
--
ALTER TABLE `gender`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `goals`
--
ALTER TABLE `goals`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `goalsprog`
--
ALTER TABLE `goalsprog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `monthlydpt`
--
ALTER TABLE `monthlydpt`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `monthlyorg`
--
ALTER TABLE `monthlyorg`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notea`
--
ALTER TABLE `notea`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notemd`
--
ALTER TABLE `notemd`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notemp`
--
ALTER TABLE `notemp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notew`
--
ALTER TABLE `notew`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `programs`
--
ALTER TABLE `programs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quatery`
--
ALTER TABLE `quatery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reset`
--
ALTER TABLE `reset`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sdoc`
--
ALTER TABLE `sdoc`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sector`
--
ALTER TABLE `sector`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trial`
--
ALTER TABLE `trial`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `weekly`
--
ALTER TABLE `weekly`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `workplan`
--
ALTER TABLE `workplan`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activities`
--
ALTER TABLE `activities`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `activity`
--
ALTER TABLE `activity`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT for table `age`
--
ALTER TABLE `age`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=139;

--
-- AUTO_INCREMENT for table `annual`
--
ALTER TABLE `annual`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `commentsa`
--
ALTER TABLE `commentsa`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `commentsact`
--
ALTER TABLE `commentsact`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `commentsfr`
--
ALTER TABLE `commentsfr`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `commentsmdpt`
--
ALTER TABLE `commentsmdpt`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `commentsmorg`
--
ALTER TABLE `commentsmorg`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `commentsmp`
--
ALTER TABLE `commentsmp`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `commentsq`
--
ALTER TABLE `commentsq`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `commentwp`
--
ALTER TABLE `commentwp`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `departmental`
--
ALTER TABLE `departmental`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `fin`
--
ALTER TABLE `fin`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `finother`
--
ALTER TABLE `finother`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `gender`
--
ALTER TABLE `gender`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=140;

--
-- AUTO_INCREMENT for table `goals`
--
ALTER TABLE `goals`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `goalsprog`
--
ALTER TABLE `goalsprog`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `location`
--
ALTER TABLE `location`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=144;

--
-- AUTO_INCREMENT for table `monthlydpt`
--
ALTER TABLE `monthlydpt`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `monthlyorg`
--
ALTER TABLE `monthlyorg`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `notea`
--
ALTER TABLE `notea`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `notemd`
--
ALTER TABLE `notemd`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `notemp`
--
ALTER TABLE `notemp`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `notew`
--
ALTER TABLE `notew`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `programs`
--
ALTER TABLE `programs`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `quatery`
--
ALTER TABLE `quatery`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `reset`
--
ALTER TABLE `reset`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `sdoc`
--
ALTER TABLE `sdoc`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `sector`
--
ALTER TABLE `sector`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT for table `trial`
--
ALTER TABLE `trial`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `weekly`
--
ALTER TABLE `weekly`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `workplan`
--
ALTER TABLE `workplan`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
