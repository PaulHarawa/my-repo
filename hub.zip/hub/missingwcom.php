<?php

    include"conn.php";
    session_start();
    $uname = $_SESSION['name'];
    $userid = $_SESSION['id'];

        $sqluser = "SELECT * FROM users WHERE id = '$userid'";
        $resultuser = mysqli_query($conn,$sqluser);
            $rowuser = mysqli_fetch_array($resultuser);
                $usernameID = $rowuser['firstname'];
                $lastnameID = $rowuser['lastname'];

    if(!$uname){
        header("Location: login.php");
    }

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Missing Weekly Report</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <script src="js/jquery.m.js"></script>

    <script src="Sweetalert/dist/sweetalert2.min.js"></script>
    <link rel="stylesheet" href="Sweetalert/dist/sweetalert2.min.css">


    <style>
        .int{
        }
        .textt{
            width: 100%;
            height: 40px;
            border-radius: 10px;
        }
        .color1{
            background-color: #1ABB81;
        }
        .color2{
            background-color: #C54A3B;
        }
        .color3{
            background-color: #4E73B4;
        }
        .table1{
            margin: auto;
        }
        .tabledata1{
            padding: 20px;
        }
        .rborder{
            border: none;
            padding: 7px;
            border-radius: 10px;
            width: 100%;
        }
        .up{
            text-align: center;
        }
        .upb{
            width: 100%;
        }
    </style>

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav color1 sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="managercom.php">
                <div class="sidebar-brand-icon rotate-n-15">
                    <img src="img/mzuzutrans.png" width="60px" height="60px" alt="">
                </div>
                <div class="sidebar-brand-text mx-3">Comm. Manager <sup>&nbsp;</sup></div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="managercom.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-calendar-week"></i>
                    <span>Weekly Report</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="uploadweeklycom.php">Upload</a>
                        <a class="collapse-item" href="viewweeklycom.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseThree"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-swatchbook"></i>
                    <span>Activity Report</span>
                </a>
                <div id="collapseThree" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="uploadactivitycom.php">Upload</a>
                        <a class="collapse-item" href="viewactivitycom.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseFour"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-calendar-alt"></i>
                    <span>Monthly Project Report</span>
                </a>
                <div id="collapseFour" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="uploadMPcom.php">Upload</a>
                        <a class="collapse-item" href="viewMPcom.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseEleven"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-calendar-check"></i>
                    <span>Monthly Dept. Report</span>
                </a>
                <div id="collapseEleven" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="addmdpcom.php">Add</a>
                        <a class="collapse-item" href="viewmdpcom.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseMaluk"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-calendar-check"></i>
                    <span>Monthly Org. Report</span>
                </a>
                <div id="collapseMaluk" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="viewmorgcom.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseThreeyears"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-dollar-sign"></i>
                    <span>Financial Report</span>
                </a>
                <div id="collapseThreeyears" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="viewfrcom.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTen"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-calendar-check"></i>
                    <span>Quatery Reports</span>
                </a>
                <div id="collapseTen" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="viewquaterycom.php">View</a>
                    </div>
                </div>
            </li>


            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseFive"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-calendar-check"></i>
                    <span>Annual Report</span>
                </a>
                <div id="collapseFive" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="viewannualcom.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseSix"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-archive"></i>
                    <span>Programs</span>
                </a>
                <div id="collapseSix" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="viewpgcom.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseSeven"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-project-diagram"></i>
                    <span>Projects</span>
                </a>
                <div id="collapseSeven" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="viewpjcom.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseEight"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-user-friends"></i>
                    <span>Activities</span>
                </a>
                <div id="collapseEight" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="viewactcom.php">View</a>
                        <a class="collapse-item" href="workplancom.php">Workplan</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseNine"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-binoculars"></i>
                    <span>Goals</span>
                </a>
                <div id="collapseNine" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="addgoalscom.php">Add</a>
                        <a class="collapse-item" href="viewgoalscom.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseNineM"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-question"></i>
                    <span>Missing Reports</span>
                </a>
                <div id="collapseNineM" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item border border-success" href="missingwcom.php">
                            <?php

                                $sqlw = "SELECT * FROM notew WHERE uid='$userid' AND state='1'";
                                $resultw = mysqli_query($conn,$sqlw);

                                $nomr = mysqli_num_rows($resultw);

                                if($nomr>0){
                                    echo"<span class='text-danger font-weight-bold'>Weekly &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$nomr</span>";
                                }
                                else{
                                    echo"Weekly";
                                }

                            ?>
                        </a>
                        <a class="collapse-item" href="missingacom.php">
                          <?php

                            $sqla = "SELECT * FROM notea WHERE uid='$userid' AND state='1'";
                            $resulta = mysqli_query($conn,$sqla);

                            $noma = mysqli_num_rows($resulta);

                            if($noma>0){
                                echo"<span class='text-danger font-weight-bold'>Activity &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$nomr</span>";
                            }
                            else{
                                echo"Activity";
                            }

                        ?>
                      </a>
                        <a class="collapse-item" href="missingmpcom.php">
                          <?php

                              $sqlw = "SELECT * FROM notemp WHERE uid='$userid' AND state='1'";
                              $resultw = mysqli_query($conn,$sqlw);

                              $nomr = mysqli_num_rows($resultw);

                              if($nomr>0){
                                  echo"<span class='text-danger font-weight-bold'>Monthly(Project)&nbsp;&nbsp;&nbsp; $nomr</span>";
                              }
                              else{
                                  echo"Monthly(Project)";
                              }

                          ?>
                        </a>
                        <a class="collapse-item" href="missingmdcom.php">
                          <?php

                              $sqlw = "SELECT * FROM notemd WHERE uid='$userid' AND state='1'";
                              $resultw = mysqli_query($conn,$sqlw);

                              $nomr = mysqli_num_rows($resultw);

                              if($nomr>0){
                                  echo"<span class='text-danger font-weight-bold'>Monthly(Dept.)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; $nomr</span>";
                              }
                              else{
                                  echo"Monthly(Dept.)";
                              }

                          ?>
                        </a>
                    </div>
                </div>
            </li>

        </ul>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light color1 topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>


                    <!-- Topbar Navbar -->
                   <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                        <div class="text-white"><?php echo strtoupper("$usernameID $lastnameID");?></div>
                        <div class=""> <form action="missingwcom.php" method="post"><button class="btn btn-sm btn-warning" name="logout" type="submit">Log-Out</button></form></div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="h5 m-0 font-weight-bold text-primary text-center ">MISSING WEEKLY REPORTS NOTIFICATIONS</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped" id="dataTable1" width="100%" cellspacing="0">
                                    <thead>
                                        <tr class="text-center color3 text-white table-borderless">
                                            <th hidden>sort</th>
                                            <th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Date&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                                            <th>Message</th>
                                            <th>Action</th>
                                            <th>Sender</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php

                                            $sqlA = "SELECT * FROM notew WHERE uid='$userid'";
                                            $resultA = mysqli_query($conn,$sqlA);

                                            while($rowA = mysqli_fetch_array($resultA)){
                                                $id = $rowA['id'];
                                                $message= $rowA['message'];
                                                $date = $rowA['date'];
                                                $cuid = $rowA['cuid'];
                                                $state = $rowA['state'];

                                                $halfdate = strtotime($date);
                                                $fulldate = date('jS F Y', $halfdate);

                                                $seen = '';

                                                if($state == '1'){
                                                    $datef = "<b>$fulldate</b>";
                                                    $seen = "<form action='missingwcom.php' method='post' enctype='multipart/form-data'>
                                                    <button class='btn btn-sm btn-primary' type='submit' name='seen'><i>seen</i></button>
                                                    <input type='radio' value='$id' name='id' checked hidden>
                                                    </form>";
                                                    $nm = "<b>$message</b>";
                                                }
                                                else{
                                                    $seen = "None";
                                                    $nm = "$message";
                                                    $datef = "$fulldate";
                                                }

                                                $sqlse = "SELECT * FROM users WHERE id ='$cuid'";
                                                $resultse = mysqli_query($conn,$sqlse);

                                                $rowse = mysqli_fetch_array($resultse);

                                                    $fnamese = $rowse['firstname'];
                                                    $lnamese = $rowse['lastname'];
                                                echo"

                                                    <tr>

                                                        <td hidden>$date</td>
                                                        <td>$datef</td>
                                                        <td>$nm</td>
                                                        <td>$seen</td>
                                                        <td>$fnamese $lnamese</td>

                                                    </tr>

                                                ";
                                            }

                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>


                    <br><br>
                    <!-- Content Row -->
                </div>

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Mzuzu E-Hub 2021</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

              <?php
                if(isset($_POST['logout'])){
                     echo "<script>
                                                 Swal.fire({
                                                        title: 'LOGOUT',
                                                        text: 'Proceed to logout now?',
                                                        icon: 'warning',
                                                        showCancelButton: true,
                                                        confirmButtonText: 'Yes',
                                                        cancelButtonText: 'No',
                                                            }).then((result) => {
                                                        if (result.isConfirmed) {
                                                             window.location.href='logout.php';
                                                        }
                                                    })
                                                    </script>
                                                ";
                     }

            ?>

            <?php

                     if(isset($_POST['seen'])){
                         $noteid = $_POST['id'];

                         $sqlnote = "UPDATE notew SET state = '0' WHERE id='$noteid'";
                         $resultnote = mysqli_query($conn,$sqlnote);

                         if($resultnote){
                            echo "<script>
                            Swal.fire({
                                        title: 'missing report',
                                        text: 'Notification viewed',
                                        icon: 'success',
                                        confirmButtonText: 'OK',
                                            }).then((result) => {
                                        if (result.isConfirmed) {

                                            window.location.href='missingwcom.php';
                                        }
                                    })
                                    </script>
                            </script>";
                         }
                     }

            ?>

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-footer">
                    <form action="logout.php" method="post">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                        <button class="btn btn-primary" type="submit" name="logout">Logout</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        $(document).ready(function(){
            $('#dataTable1').DataTable({
                "order": [[0,"desc"]]
            });
            $('.dataTables_length').addClass('bs-select');

        });
    </script>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-bar-demo.js"></script>

    <!-- Page level plugins -->
<script src="vendor/datatables/jquery.dataTables.min.js"></script>
<script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

<!-- Page level custom scripts -->
<script src="js/demo/datatables-demo.js"></script>

</body>

</html>
