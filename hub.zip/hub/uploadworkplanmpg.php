<?php

    include"conn.php";
    session_start();
    $uname = $_SESSION['name'];
    $userid = $_SESSION['id'];

        $sqluser = "SELECT * FROM users WHERE id = '$userid'";
        $resultuser = mysqli_query($conn,$sqluser);
            $rowuser = mysqli_fetch_array($resultuser);
                $usernameID = $rowuser['firstname'];
                $lastnameID = $rowuser['lastname'];

    if(!$uname){
        header("Location: login.php");
    }

?>


<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Upload Workplan Document</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">


    <script src="Sweetalert/dist/sweetalert2.min.js"></script>
    <link rel="stylesheet" href="Sweetalert/dist/sweetalert2.min.css">

    <script src="js/jquery-3.6.0.min.js"></script>

    <link href="js/jquery-ui.css" rel="stylesheet" />

    <script src="js/jquery-ui.js"></script>


    <style>
        .int{
        }
        .textt{
            width: 100%;
            height: 40px;
            border-radius: 10px;
        }
        .color1{
            background-color: #1ABB81;
        }
        .color2{
            background-color: #C54A3B;
        }
        .table1{
            margin: auto;
        }
        .tabledata1{
            padding: 20px;
        }
        .rborder{
            border: none;
            padding: 7px;
            border-radius: 10px;
            width: 100%;
        }
        .up{
            text-align: center;
        }
        .upb{
            width: 100%;
        }
        .subbtn{
            margin: auto;
        }
        .big{
            padding: 5px;
        }
        .ui-datepicker {
        background: #4D8081;
        color: #EEE;
        border: 1px solid #4D8081;
      }

        .ui-datepicker-header {
            background-color: #4D8081;
            border:none;
        }
        .ui-datepicker-prev{
              cursor: pointer;
            }
        .ui-datepicker-next{
              cursor: pointer;
            }
        .ui-datepicker thead{
            color: white;
        }
    </style>

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav color1 sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="managerpg.php">
                <div class="sidebar-brand-icon rotate-n-15">
                    <img src="img/mzuzutrans.png" width="60px" height="60px" alt="">
                </div>
                <div class="sidebar-brand-text mx-3">Programs Manager <sup>&nbsp;</sup></div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="managerpg.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-calendar-week"></i>
                    <span>Weekly Report</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="uploadweeklympg.php">Upload</a>
                        <a class="collapse-item" href="viewweeklympg.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseThree"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-swatchbook"></i>
                    <span>Activity Report</span>
                </a>
                <div id="collapseThree" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="uploadactivitympg.php">Upload</a>
                        <a class="collapse-item" href="viewactivitympg.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseFour"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-calendar-alt"></i>
                    <span>Monthly Project Report</span>
                </a>
                <div id="collapseFour" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="uploadMPmpg.php">Upload</a>
                        <a class="collapse-item" href="viewMPmpg.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseEleven"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-calendar-check"></i>
                    <span>Monthly Dept. Report</span>
                </a>
                <div id="collapseEleven" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="addmdpt.php">Add</a>
                        <a class="collapse-item" href="viewmdpt.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#gome"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-calendar-check"></i>
                    <span>Monthly Org. Report</span>

                </a>
                <div id="gome" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="viewmorgpg.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTen"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-calendar-check"></i>
                    <span>Quatery Reports</span>
                </a>
                <div id="collapseTen" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="viewquaterympg.php">View</a>
                    </div>
                </div>
            </li>


            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseFive"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-calendar-check"></i>
                    <span>Annual Report</span>
                </a>
                <div id="collapseFive" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="viewannualmpg.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseThreeyears"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-dollar-sign"></i>
                    <span>Financial Report</span>
                </a>
                <div id="collapseThreeyears" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="viewfrmpg.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseSix"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-archive"></i>
                    <span>Programs</span>
                </a>
                <div id="collapseSix" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="addpg.php">Add</a>
                        <a class="collapse-item" href="viewpg.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseSeven"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-project-diagram"></i>
                    <span>Projects</span>
                </a>
                <div id="collapseSeven" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="addpj.php">Add</a>
                        <a class="collapse-item" href="viewpj.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseEight"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-user-friends"></i>
                    <span>Activities</span>
                </a>
                <div id="collapseEight" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="addact.php">Add</a>
                        <a class="collapse-item" href="viewact.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseNine"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-binoculars"></i>
                    <span>Goals</span>
                </a>
                <div id="collapseNine" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="addgoals.php">Add</a>
                        <a class="collapse-item" href="viewgoals.php">View</a>
                    </div>
                </div>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseNineM"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-question"></i>
                    <span>Missing Reports</span>
                </a>
                <div id="collapseNineM" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <a class="collapse-item" href="missingwpg.php">
                            <?php

                                $sqlw = "SELECT * FROM notew WHERE uid='$userid' AND state='1'";
                                $resultw = mysqli_query($conn,$sqlw);

                                $nomr = mysqli_num_rows($resultw);

                                if($nomr>0){
                                    echo"<span class='text-danger font-weight-bold'>Weekly &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$nomr</span>";
                                }
                                else{
                                    echo"Weekly";
                                }

                            ?>
                        </a>
                        <a class="collapse-item" href="missingapg.php">
                          <?php

                            $sqla = "SELECT * FROM notea WHERE uid='$userid' AND state='1'";
                            $resulta = mysqli_query($conn,$sqla);

                            $noma = mysqli_num_rows($resulta);

                            if($noma>0){
                                echo"<span class='text-danger font-weight-bold'>Activity &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;$nomr</span>";
                            }
                            else{
                                echo"Activity";
                            }

                        ?>
                      </a>
                        <a class="collapse-item" href="missingmppg.php">
                          <?php

                              $sqlw = "SELECT * FROM notemp WHERE uid='$userid' AND state='1'";
                              $resultw = mysqli_query($conn,$sqlw);

                              $nomr = mysqli_num_rows($resultw);

                              if($nomr>0){
                                  echo"<span class='text-danger font-weight-bold'>Monthly(Project)&nbsp;&nbsp;&nbsp; $nomr</span>";
                              }
                              else{
                                  echo"Monthly(Project)";
                              }

                          ?>
                        </a>
                        <a class="collapse-item" href="missingmdpg.php">
                          <?php

                              $sqlw = "SELECT * FROM notemd WHERE uid='$userid' AND state='1'";
                              $resultw = mysqli_query($conn,$sqlw);

                              $nomr = mysqli_num_rows($resultw);

                              if($nomr>0){
                                  echo"<span class='text-danger font-weight-bold'>Monthly(Dept.)&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; $nomr</span>";
                              }
                              else{
                                  echo"Monthly(Dept.)";
                              }

                          ?>
                        </a>
                    </div>
                </div>
            </li>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light color1 topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>


                    <!-- Topbar Navbar -->
                   <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                        <div class="text-white"><?php echo strtoupper("$usernameID $lastnameID");?></div>
                        <div class=""> <form action="uploadworkplanmpg.php" method="post"><button class="btn btn-sm btn-warning" name="logout" type="submit">Log-Out</button></form></div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                       <h1 class="h4 mb-0 text-primary col-12 text-center font-weight-bold">UPLOAD WORKPLAN DOCUMENT</h1>
                    </div>

                    <!-- Content Row -->

                    <div class="row">


                        <form class="col-12" method="post" action="uploadworkplanmpg.php" enctype="multipart/form-data">


                            <table class="table1 text-primary col-5">
                                    <tr>
                                        <td class="tabledata1"><label class="int">Name </label></td>
                                        <td class="tabledata1" colspan="2"><input class="text-dark border border-primary textt bg-white" type="text" name="name" required>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tabledata1"><label class="int">File </label></td>
                                        <td class="tabledata1" colspan="2">
                                            <div class="custom-file">
                                            <input type="file" class="custom-file-input" id="customFile" name="file" required>
                                            <label class="custom-file-label border border-primary" for="customFile">Choose file</label>
                                          </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="tabledata1"><label class="int">Date </label></td>
                                        <td class="tabledata1" colspan="2"><input id="datepicker" class="text-dark border border-primary textt bg-white" name="date" required/></td>

                                        <script>
                                            $('#datepicker').datepicker({
                                                fontAwesome: true,
                                                uiLibrary: 'bootstrap4',maxDate: new Date(),changeMonth: true,changeYear: true
                                            });
                                        </script>
                                    </tr>
                                    <tr>
                                        <td>&nbsp;</td>
                                        <td>&nbsp;</td>
                                    </tr>

                                </table>

							<div class="form-group input-group mb-3 col-5 table1">
                                <div class="input-group-prepend">
                                    <label class="input-group-text text-primary border border-primary" for="inputGroupSelect0i">Activity</label>
                                </div>
                             <select class="custom-select form-control border border-primary" id="inputGroupSelect0i" name="activity" required>
                                <?php

                                    $sql = "SELECT * FROM activities WHERE uid='$userid' AND status='1' AND workplan='0'";
                                    $result = mysqli_query($conn,$sql);

                                    if(mysqli_num_rows($result)>0){
                                        while($row=mysqli_fetch_array($result)){
                                            $actid = $row['id'];
                                            $actname = $row['name'];

                                            echo"<option value='$actid'>$actname</option>";
                                        }
                                    }
                                    else{
                                        echo"<option value=''>No activities exists for you</option>";
                                    }

                                ?>
                             </select>
                            </div>
                            <br><br>
                            <div class="col-5 table1">
                                <button type="submit" class="btn btn-success col-12 subbtn" name="upload">Upload</button>
                            </div>

                        </form>

						<?php

							if(isset($_POST['upload'])){

								$filename = $_FILES['file']['name'];
								$tempname = $_FILES['file']['tmp_name'];
								$destination = "uploads/workplan/".$filename;

								$rname = $_POST['name'];
								$rfile = $filename;
								$dat = $_POST['date'];
								$date = date("y-m-d", strtotime($dat));
								$today = date("y-m-d");

								$activity =	$_POST['activity'];

								if(empty($rname) or empty($rfile) or empty($date) or empty($activity)){
									echo"<br><br>
										<div class='alert alert-danger text-center col-6' role='alert'>
											Please fill in the missing fiedl(s).
										</div> ";
        							}
								else{
									$sql = "INSERT INTO workplan(rname,file,sdate,idate,uid,actid) VALUES('$rname','$rfile','$today','$date','$userid','$activity')";
									$result = mysqli_query($conn,$sql);

									if($result){

                    $sql2 = "UPDATE activities SET workplan='1' WHERE id='$activity'";
                    $result2 = mysqli_query($conn,$sql2);

                                            move_uploaded_file($tempname, $destination);

                                             echo "<script>
                                                        Swal.fire({
                                                            title: 'workplan document',
                                                            text: 'Workplan documentt uploaded successfully',
                                                            icon: 'success',
                                                            confirmButtonText: 'OK',
                                                            }).then((result) => {
                                                            if (result.isConfirmed) {

                                                                    window.location.href='workplanmpg.php';
                                                                        }
                                                                    })
                                                </script>";
                                        }
                                        else{
                                            echo"<br><br>
                                              <div class='alert alert-danger text-center' role='alert'>
                                                   Failed to upload report.
                                              </div> ";
                                        }

								}
							}

						?>

                    </div>
                </div>

            </div>
            <!-- End of Main Content -->
            <br>
            <!-- Footer -->
            <footer class="sticky-footer">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Mzuzu E-Hub 2021</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

            <?php
                if(isset($_POST['logout'])){
                     echo "<script>
                                                 Swal.fire({
                                                        title: 'LOGOUT',
                                                        text: 'Proceed to logout now?',
                                                        icon: 'warning',
                                                        showCancelButton: true,
                                                        confirmButtonText: 'Yes',
                                                        cancelButtonText: 'No',
                                                            }).then((result) => {
                                                        if (result.isConfirmed) {
                                                             window.location.href='logout.php';
                                                        }
                                                    })
                                                    </script>
                                                ";
                     }

            ?>

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-bar-demo.js"></script>
        <script>
       $(".custom-file-input").on("change", function() {
              var fileName = $(this).val().split("\\").pop();
                $(this).siblings(".custom-file-label").addClass("ected").html(fileName);
                 });
    </script>

</body>

</html>
